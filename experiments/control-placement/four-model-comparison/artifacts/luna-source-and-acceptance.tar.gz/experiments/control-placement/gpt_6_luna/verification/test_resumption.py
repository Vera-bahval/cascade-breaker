import json
from pathlib import Path
import tempfile
import unittest

from resumption import AuthorizedLedger, unknown_bound, write_json
from support import Ledger, RunStopped, digest


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        ledger = Ledger(self.root/'budget.db')
        context = {'phase':'main','episode':'funnel/X-r1'}
        with ledger.request_lease('old'):
            ledger.reserve('old','main',.07,context)
        ledger.unknown('old','timeout')
        self.policy = {'root':str(self.root),'authorized_unknowns':{'old':{
            'reserved':.07,'context_sha256':digest(context),'budget_bound_usd':.2}}}
        write_json(self.root/'recovery-policy.json',self.policy)

    # Только разрешённый старый unknown не блокирует новую попытку.
    def test_exact_allowance(self):
        ledger = AuthorizedLedger(self.root/'budget.db')
        with ledger.request_lease('new'):
            ledger.reserve('new','main',.1,{'episode':'new'})
        self.assertEqual(ledger.state()['authorized_unknowns'], ['old'])
        self.assertIn('old',ledger.state()['unresolved_all'])
        self.assertIsNone(ledger.state()['total_api_equivalent_usd'])

    # Новый неизвестный исход вновь закрывает генерации.
    def test_new_unknown_stops(self):
        ledger = AuthorizedLedger(self.root/'budget.db')
        with ledger.request_lease('new'):
            ledger.reserve('new','main',.1,{})
        ledger.unknown('new','timeout')
        with self.assertRaises(RunStopped):ledger.reserve('again','main',.1,{})

    # Резерв старого запроса включается в проверку полного бюджета.
    def test_budget_includes_old_unknown(self):
        ledger = AuthorizedLedger(self.root/'budget.db',cap=.25)
        with self.assertRaises(RunStopped):ledger.reserve('new','main',.1,{})

    # Правка контекста разрешённого запроса не расширяет исключение.
    def test_context_change_stops(self):
        self.policy['authorized_unknowns']['old']['context_sha256']='wrong'
        write_json(self.root/'recovery-policy.json',self.policy)
        with self.assertRaises(RunStopped):AuthorizedLedger(self.root/'budget.db').state()

    # Неизвестный старый расход нельзя отметить завершённым через обычный API.
    def test_unknown_cannot_be_completed(self):
        with self.assertRaises(RunStopped):
            AuthorizedLedger(self.root/'budget.db').complete('old',{'lower_usd':0,'upper_usd':0},{})

    # Плановый резерв больше прежнего байтового резерва и включает максимум output.
    def test_bound_is_conservative(self):
        bound=unknown_bound({'input':'abc'})
        self.assertGreater(bound['budget_bound_usd'],.064)
        self.assertEqual(bound['output_tokens_ceiling'],128000)


if __name__=='__main__':unittest.main()
