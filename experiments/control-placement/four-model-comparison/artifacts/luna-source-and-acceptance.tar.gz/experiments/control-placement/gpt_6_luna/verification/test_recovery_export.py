import unittest

from recovery_export import reconcile_states, accounting


class RecoveryExportTests(unittest.TestCase):
    # Старые неизвестные остаются null, а плановый резерв учитывается отдельно.
    def test_unknown_is_not_measured_cost(self):
        rows = [dict(attempt_id='ok', accounting_state='complete', estimate_upper_usd=1.2,
                     input_tokens=10, output_tokens=2, reasoning_tokens=1),
                dict(attempt_id='old', accounting_state='unknown', estimate_upper_usd=None,
                     input_tokens=None, output_tokens=None, reasoning_tokens=None)]
        result = accounting(rows, {'old': {'budget_bound_usd': .3}})
        self.assertEqual(result['known_api_equivalent_usd'], 1.2)
        self.assertIsNone(result['total_api_equivalent_usd'])
        self.assertEqual(result['planning_upper_including_unknown_usd'], 1.5)
        self.assertEqual(result['output_tokens_known_sum'], 2)

    # Новый unknown нельзя принять как часть старого разрешения.
    def test_new_unknown_rejected(self):
        with self.assertRaises(ValueError):
            reconcile_states([{'id': 'new', 'state': 'unknown'}], {'new': []}, {'old': {}})

    # Завершённый запрос без raw-журнала не проходит сверку ledger.
    def test_missing_journal_rejected(self):
        with self.assertRaises(ValueError):
            reconcile_states([{'id': 'ok', 'state': 'complete'}], {}, {})

    # Повторная копия intent не удваивает расходы молча.
    def test_duplicate_ledger_rejected(self):
        row = {'id': 'ok', 'state': 'complete'}
        with self.assertRaises(ValueError):
            reconcile_states([row, row], {'ok': []}, {})


if __name__ == '__main__':
    unittest.main()
