# FinBot на GPT-6 Luna: принятый протокол

Поручение: повторить основной эксперимент DeepSeek через личную подписку Codex.
Исходный handoff: `/Users/proskurin-dmi/Documents/hw-itmo/cascades/handoffs/GPT-6-LUNA-CODEX.md`.
Точные определения метрик, исходные ревизии и требования к восстановлению — в handoff.

## Согласованная редакция протокола 2

25 октября 2026 пользователь ответил «Согласую» на предложение изменить подписочный
протокол. Разрешено исключить неподдерживаемые `max_output_tokens` и `temperature`,
преобразовать system role в developer с сохранением содержимого/порядка и обернуть
исходные функции в namespace `finbot_tools`. Orchestrator и исполнение tools остаются
в FinBot. Wire route — публичный Responses API с отдельным OAuth plan-usage grant,
`store=false`, `stream=true`. Это подписочный протокол 2 с явными ограничениями
сравнения с DeepSeek; лимит 5000 не заменяется вымышленным клиентским эквивалентом.
Остальные пункты ниже сохраняются; пункт 3 описывает исходные requested настройки,
которые больше не считаются effective. Timeout 60/1800 секунд сохраняется.

1. Отдельная локальная ветка и пакет Luna; прежние код, результаты, ledger и caches DeepSeek не менять.
2. До пилотов доказать поддержанный подписочный маршрут, точную передачу ролей,
   истории, instructions, tools и результатов исходному FinBot SDK. Orchestrator — FinBot.
   При недоказанной сопоставимости остановиться до пилотов с конкретным отчетом.
3. Оба экспериментальных участника — `gpt-6-luna`. Пилоты Medium и High,
   `temperature=0` requested, max output 5000 including reasoning, request timeout 60 s,
   worker timeout 1800 s. Unsupported параметры не игнорировать; fallback запрещен.
4. Fault mocks, затем изолированный offline replay 297; firewall до импорта FinBot.
   Далее smoke каждого режима: text, strict guard JSON, function call/result/completion.
5. По восемь пилотных эпизодов каждого режима: fpr/TH601, fpr/TH608,
   funnel/H1, funnel/TA501, funnel/FD57-none, funnel/FD53-none, vera7/V2, vera7/V5.
   Repeat 1, последовательное исполнение, чередование порядка Medium/High по сценарию.
   Pilot/main и режимы имеют отдельные cache identities; pilot исключен из main.
6. Forecast executor: средние по наборам с весами 150/77/70; три входных guard votes
   на 150/77/7 уникальных входов; остальные views — до десяти проверок на каждый
   эпизод по максимальной измеренной стоимости такого view. К сумме добавить 25%.
7. Выбрать High при forecast <= $5.30 API-equivalent; иначе Medium при том же
   условии; если оба выше или стоимость неизвестна — остановиться после пилотов.
   Выбор по расходу, а не по outcome quality. Smoke/pilots учитывать отдельно.
8. Freeze источников, конфигурации, runtime, моделей, SDK и данных. Main 297,
   без изменения промптов и бизнес-логики; seed и matrix взять из DeepSeek manifest.
   Пакеты 62/59/59/59/58, checkpoints 62/121/180/239/297; concurrency <=4.
9. На checkpoint — аудит полноты, JSON/SQLite, платежей, модели, usage, лимитов,
   parameters и forecast; unknown outcome или forecast >$5.30 останавливает новые
   запросы. Нельзя менять reasoning или повторять совершенные действия при resume.
10. Сохранять raw events и все доступные requested/effective/unavailable поля,
    токены, timestamps, активное и полное время, API estimates и общий расход лимитов.
    Reasoning — подмножество output, не прибавлять второй раз. Не приравнивать
    API-equivalent к списанию по подписке и не выдумывать inference cost $0.
11. Три входных голоса, все 22 сочетания правил и posthoc nature guard сохраняются.
    Проверить все 297; экспортировать JSON/CSV и сравнение с DeepSeek. Локальный commit,
    без публикации. Heartbeat текущего чата 30 минут только при длительном запуске;
    удалить после завершения. Покупки, смена плана и платный Platform API исключены.
