import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))


class ExperimentTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / 'experiment.py').is_file(), 'Missing Luna controller')
        spec = importlib.util.spec_from_file_location('luna_experiment_test', HERE / 'experiment.py')
        self.e = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.e)

    # Матрица и порядок копируются из сохраненной серии без повторной рандомизации.
    def test_exact_original_matrix(self):
        expected = json.loads((HERE.parent / 'deepseek_flash/results/paid/manifest.json').read_text())['matrix']
        self.assertEqual(self.e.matrix(), expected)
        self.assertEqual([sum(j['batch'] == b for j in expected) for b in range(1, 6)], [62,59,59,59,58])

    # В пилотах меняется порядок Medium/High, все сценарии остаются парными.
    def test_pilot_alternates_and_is_serial(self):
        jobs = self.e.pilot_jobs()
        self.assertEqual(len(jobs), 16)
        self.assertEqual([j['scenario']['id'] for j in jobs[::2]], ['TH601','TH608','H1','TA501','FD57-none','FD53-none','V2','V5'])
        for n in range(8):
            self.assertEqual([j['effort'] for j in jobs[2*n:2*n+2]], ['medium','high'] if n%2 == 0 else ['high','medium'])

    # Журнал начатого исполнителя запрещает повторное создание счета.
    def test_partial_executor_never_restarts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); job = dict(self.e.matrix()[0], phase='pilot-medium', effort='medium')
            dest = root / job['phase'] / 'episodes' / job['episode']; dest.mkdir(parents=True)
            (dest/'calls.jsonl.gz').touch()
            with self.assertRaises(self.e.RunStopped): self.e.preflight_job(job, root)

    # Прогноз считает средние внутри трех страт и три входных голоса отдельно.
    def test_weighted_forecast_and_choice(self):
        rows = []
        for dataset, cost in [('fpr',.001),('fpr',.003),('funnel',.002),('funnel',.004),('funnel',.002),('funnel',.004),('vera7',.001),('vera7',.003)]:
            rows.append({'dataset':dataset,'executor_cost_upper_usd':cost,'valid':True})
        guards = [{'view':'input','estimate':{'upper_usd':.000001}}] + [
                  {'view':'v1:final','estimate':{'upper_usd':.000002}}]
        value = self.e.project_mode(rows, guards)
        expected = (150*.002 + 77*.003 + 70*.002 + (150+77+7)*3*.000001 + 297*10*.000002)*1.25
        self.assertAlmostEqual(value['with_reserve_usd'], expected)
        self.assertEqual(self.e.choose({'medium':value,'high':value}), 'high')
        self.assertIsNone(self.e.choose({'medium':{'with_reserve_usd':6},'high':{'with_reserve_usd':7}}))

    # Без измеренной цены прочих представлений порог не считается проверенным.
    def test_forecast_missing_view_cost_fails(self):
        with self.assertRaises(self.e.RunStopped): self.e.project_mode([], [])

    # Второй контроллер не может войти, пока первый держит kernel lock.
    def test_duplicate_controller_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.e.controller_lock(Path(directory)):
                with self.assertRaises(self.e.RunStopped):
                    with self.e.controller_lock(Path(directory)):pass

    # Исчерпанный лимит нельзя заменить кредитами или неизвестным окном.
    def test_quota_gate_rejects_credit_fallback_and_stale(self):
        from datetime import UTC,datetime
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            snapshot={'source':'Codex app get_usage_limits','observed_at':datetime.now(UTC).isoformat(),
                      'ordinaryUsageAllowed':True,'buckets':{'codex':{'primary':{'usedPercent':5}}}}
            (root/'usage-latest.json').write_text(json.dumps(snapshot))
            self.assertEqual(self.e.quota_snapshot(root)['ordinaryUsageAllowed'],True)
            snapshot['ordinaryUsageAllowed']=False
            (root/'usage-latest.json').write_text(json.dumps(snapshot))
            with self.assertRaises(self.e.RunStopped):self.e.quota_snapshot(root)
            snapshot.update(ordinaryUsageAllowed=True,observed_at='2020-01-01T00:00:00Z')
            (root/'usage-latest.json').write_text(json.dumps(snapshot))
            with self.assertRaises(self.e.RunStopped):self.e.quota_snapshot(root)

    # Import worker не импортирует FinBot; firewall блокирует внешний socket до его SDK.
    def test_offline_firewall_precedes_finbot_import(self):
        import subprocess
        code="import sys,socket;sys.path.insert(0,sys.argv[1]);import worker;assert not any(n=='finbot' or n.startswith('finbot.') for n in sys.modules);worker.install_offline_firewall();s=socket.socket();s.connect(('203.0.113.1',443))"
        cp=subprocess.run([sys.executable,'-c',code,str(HERE)],capture_output=True)
        self.assertNotEqual(cp.returncode,0)
        self.assertIn(b'Offline network firewall blocked',cp.stderr)


if __name__ == '__main__': unittest.main()
