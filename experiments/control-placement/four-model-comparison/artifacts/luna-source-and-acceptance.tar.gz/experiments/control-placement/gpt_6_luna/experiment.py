"""FinBot Luna controller: offline replay, paired pilots and immutable main series."""
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import argparse
import collections
import fcntl
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

from adapter import MODEL
from support import Ledger, PRICING, RunStopped, digest, read_records, write_json

HERE = Path(__file__).resolve().parent
BASELINE = HERE.parent / 'deepseek_flash'
CODE = HERE.parent / 'code'
RUNTIME = HERE / '.runtime'
FINBOT = BASELINE / '.runtime/finbot'
CONTROLLER_FD = None
SETS = {'fpr':'v6_honest_scenarios.json', 'funnel':'our_scenarios.json', 'vera7':'vera7_scenarios.json'}


def matrix():
    jobs = json.loads((BASELINE / 'results/paid/manifest.json').read_text())['matrix']
    if len(jobs) != 297 or len({j['episode'] for j in jobs}) != 297:
        raise RunStopped('Baseline matrix is not 297 unique episodes')
    return jobs


def pilot_jobs():
    selected = [('fpr','TH601'),('fpr','TH608'),('funnel','H1'),('funnel','TA501'),
                ('funnel','FD57-none'),('funnel','FD53-none'),('vera7','V2'),('vera7','V5')]
    result = []
    for n, (dataset, sid) in enumerate(selected):
        original = next(j for j in matrix() if j['dataset']==dataset and j['scenario']['id']==sid and j['repeat']==1)
        for effort in (('medium','high') if n%2==0 else ('high','medium')):
            result.append(dict(original, effort=effort))
    return result


def source_hashes():
    paths = list(HERE.glob('*.py')) + list((HERE/'tests').glob('*.py'))
    paths += [CODE/p for p in ('llm_guardrail.py','levels_finbot477.py','levels_inputs.py','levels_detector.py')]
    paths += [CODE/'finbot477'/p for p in SETS.values()]
    paths += [BASELINE/'results/paid/manifest.json', HERE/'PLAN.md']
    return {str(p.relative_to(HERE.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def execution_spec():
    paths = [p for p in FINBOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p.suffix in ('.py','.toml','.yaml','.yml','.txt','.jinja','.jinja2','.j2','.json','.md')]
    return {'source_hashes':source_hashes(),
            'finbot_hashes':{str(p.relative_to(FINBOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},
            'finbot_commit':'a7f6964fbc60da807e2544d826a5b4e20eb0c5dc',
            'dependencies':{d.metadata['Name'].lower():d.version for d in importlib.metadata.distributions() if d.metadata.get('Name')},
            'python':sys.version, 'model':MODEL, 'model_id_kind':'rolling alias; immutable snapshot unavailable',
            'endpoint':'https://api.openai.com/v1/responses', 'protocol':2,
            'requested':{'max_output_tokens':5000, 'temperature':0, 'timeout_s':60, 'worker_timeout_s':1800},
            'effective':{'max_output_tokens':None, 'temperature':None, 'stream':True, 'store':False,
                         'role_mapping':'system to developer', 'tool_namespace':'finbot_tools'},
            'reasoning_modes':['medium','high'], 'execution_date':'2026-10-25',
            'main_concurrency':4, 'pilot_concurrency':1, 'pricing':PRICING,
            'pristine_sha256':hashlib.sha256((RUNTIME/'pristine_C.db').read_bytes()).hexdigest()}


def prepare():
    RUNTIME.mkdir(exist_ok=True)
    original = BASELINE/'.runtime/pristine_C.db'; pristine = RUNTIME/'pristine_C.db'
    if not original.exists() or not (FINBOT/'scripts/cascade_failure_demo.py').exists():
        raise RunStopped('Pinned runtime or original profile C absent')
    expected = json.loads((BASELINE/'results/paid/manifest.json').read_text())['pristine_sha256']
    if hashlib.sha256(original.read_bytes()).hexdigest() != expected: raise RunStopped('Baseline profile C changed')
    if not pristine.exists(): shutil.copy2(original, pristine)
    if hashlib.sha256(pristine.read_bytes()).hexdigest() != expected: raise RunStopped('Luna pristine profile changed')
    return pristine


def env_for(database):
    return os.environ.copy() | {'DATABASE_URL':'sqlite:///'+str(database), 'DATABASE_TYPE':'sqlite',
        'LLM_PROVIDER':'openai','LLM_DEFAULT_MODEL':MODEL,'LLM_DEFAULT_TEMPERATURE':'0','LLM_MAX_TOKENS':'5000',
        'LLM_TIMEOUT':'60','OPENAI_API_KEY':'injected-in-transport-only','EMAIL_PROVIDER':'console',
        'REDIS_URL':'redis://127.0.0.1:1','LOG_LEVEL':'error','DEBUG':'true'}


@contextmanager
def controller_lock(root):
    global CONTROLLER_FD
    root.mkdir(parents=True, exist_ok=True)
    with (root/'controller.lock').open('a+b') as handle:
        try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise RunStopped('Another controller or inherited worker owns the run')
        previous = CONTROLLER_FD; CONTROLLER_FD = handle.fileno()
        try: yield
        finally: CONTROLLER_FD = previous
        # Close without LOCK_UN: an inherited worker retains the lock after a parent crash.


def waves(jobs, count):
    pending = list(jobs)
    while pending:
        wave, deferred, keys = [], [], set()
        for job in pending:
            key = (job['dataset'], job['scenario']['id'])
            if len(wave)<count and key not in keys: wave.append(job); keys.add(key)
            else: deferred.append(job)
        yield wave; pending = deferred


def stamp(job, phase, effort, spec):
    return dict(job, phase=phase, effort=effort, execution_fingerprint=digest(spec))


def preflight_job(job, root):
    dest = root/job['phase']/'episodes'/job['episode']; final = dest/'episode.json'
    if final.exists():
        row = json.loads(final.read_text())
        if row.get('job_sha256') != digest(job) or not row.get('valid'): raise RunStopped('Unreconciled or changed episode')
        return row, not (dest/'defender.json').exists()
    if any((dest/name).exists() for name in ('calls.jsonl.gz','hooks.jsonl','final.db','snapshot.sqlite.gz')):
        raise RunStopped('Partial executor: do not repeat business actions')
    return None, False


def run_worker(job, root, mode):
    existing, defend_only = preflight_job(job, root)
    if existing is not None and not defend_only: return existing
    if (root/'halt.json').exists(): raise RunStopped('Run is halted')
    dest = root/job['phase']/'episodes'/job['episode']; dest.mkdir(parents=True, exist_ok=True)
    write_json(dest/'job.json', job)
    command = [sys.executable, str(HERE/'worker.py'), str(dest/'job.json'), str(root), mode]
    if defend_only: command.append('--defend-only')
    started = time.monotonic()
    try:
        cp = subprocess.run(command, cwd=FINBOT, env=env_for(dest/'final.db'), capture_output=True,
                            timeout=1800, pass_fds=(CONTROLLER_FD,) if CONTROLLER_FD is not None else ())
    except subprocess.TimeoutExpired as exc:
        write_json(root/'halt.json', {'reason':'Worker timeout; reconcile intents and business state', 'episode':job['episode']})
        raise RunStopped('Worker wall timeout') from exc
    from transport import RecordedTransport
    for name, payload in [('out.txt', cp.stdout), ('err.txt', cp.stderr)]:
        (dest/(('resume-' if defend_only else '')+name)).write_text(RecordedTransport.mask(payload.decode(errors='replace')))
    write_json(root/'budget.json', Ledger(root/'budget.db').state())
    if cp.returncode != 0 or not (dest/'defender.json').exists():
        write_json(root/'halt.json', {'reason':'Worker failed; no automatic retries', 'episode':job['episode']})
        raise RunStopped('Worker failed: '+str(dest))
    result = json.loads((dest/'episode.json').read_text())
    print(json.dumps({'episode':job['episode'],'phase':job['phase'],'seconds':round(time.monotonic()-started,2),
                      'transfers':len(result['transfers']),'calls':result['executor_calls'],'valid':result['valid']}), flush=True)
    return result


def project_mode(rows, guards, weights=None, unique_inputs=None):
    weights = weights or {'fpr':150,'funnel':77,'vera7':70}
    unique_inputs = unique_inputs or {'fpr':150,'funnel':77,'vera7':7}
    means = {}
    for dataset in ('fpr','funnel','vera7'):
        values = [r['executor_cost_upper_usd'] for r in rows if r['dataset']==dataset and r['valid']]
        if not values: raise RunStopped('Pilot stratum cost unavailable: '+dataset)
        means[dataset] = statistics.mean(values)
    inputs = [r['estimate']['upper_usd'] for r in guards if r.get('view')=='input']
    views = [r['estimate']['upper_usd'] for r in guards if r.get('view')!='input']
    if not inputs or not views: raise RunStopped('Measured input or other-view price unavailable')
    executor = sum(weights[d]*means[d] for d in weights)
    input_guard = sum(unique_inputs.values())*3*max(inputs)
    other = sum(weights.values())*10*max(views)
    return {'executor_usd':executor,'input_guard_usd':input_guard,'other_views_usd':other,
            'executor_means_usd':means,'input_max_usd':max(inputs),'other_view_max_usd':max(views),
            'base_usd':executor+input_guard+other,'with_reserve_usd':(executor+input_guard+other)*1.25,
            'reserve_fraction':.25,'episode_weights':weights,'unique_input_weights':unique_inputs,
            'method':'Stratified executor means; three input votes at maximum measured input price; ten other views per episode at measured maximum. Upper API-equivalent estimates.'}


def choose(projections):
    for effort in ('high','medium'):
        value = projections.get(effort, {}).get('with_reserve_usd')
        if isinstance(value, (int,float)) and 0<=value<=5.30: return effort
    return None


def forecast(root):
    projections = {}
    for effort in ('medium','high'):
        phase = 'pilot-'+effort
        rows = [json.loads(p.read_text()) for p in root.glob(phase+'/episodes/*/*/episode.json')]
        receipt=root/phase/'accepted.json'
        if len(rows)!=8 or not all(r['valid'] for r in rows) or not receipt.exists():
            raise RunStopped('Both accepted eight-case pilots are required')
        if json.loads(receipt.read_text())['execution_fingerprint']!=digest(execution_spec()):
            raise RunStopped('Pilot source fingerprint differs')
        guards = [r for p in root.glob(phase+'/episodes/*/*/guard-calls.jsonl.gz') for r in read_records(p) if r['event']=='response']
        projections[effort] = project_mode(rows, guards)
    result = {'projections':projections,'selected':choose(projections),'cap_usd':5.30,'pricing':PRICING,
              'actual_subscription_cost_usd':None,'pilot_and_smoke_excluded_from_main':True}
    write_json(root/'forecast.json', result)
    return result


def quota_snapshot(root, *, after=0, max_age=1800):
    path=root/'usage-latest.json'
    if not path.exists():raise RunStopped('Fresh Codex usage-limits snapshot required')
    value=json.loads(path.read_text())
    observed=datetime.fromisoformat(value['observed_at'].replace('Z','+00:00')).timestamp()
    if observed<after or not 0<=time.time()-observed<=max_age:raise RunStopped('Codex usage snapshot is stale')
    if value.get('source')!='Codex app get_usage_limits' or value.get('ordinaryUsageAllowed') is not True:
        raise RunStopped('Ordinary subscription usage not confirmed; credits fallback forbidden')
    if not value.get('buckets'):raise RunStopped('Subscription limit windows unavailable')
    for bucket in value['buckets'].values():
        if bucket.get('spendControlReached') or bucket.get('rateLimitReachedType'):
            raise RunStopped('Subscription limit reached')
        for window in (bucket.get('primary'),bucket.get('secondary')):
            if window and (not isinstance(window.get('usedPercent'),(int,float)) or window['usedPercent']>=100):
                raise RunStopped('Subscription window exhausted or unavailable')
    return value


def remaining_forecast(root,manifest):
    effort=manifest['effort'];phase='pilot-'+effort
    pilot=[json.loads(p.read_text()) for p in root.glob(phase+'/episodes/*/*/episode.json')]
    actual=[json.loads(p.read_text()) for p in root.glob('main/episodes/*/*/episode.json')
            if p.with_name('defender.json').exists()]
    completed={r['episode'] for r in actual if r['valid']}
    pending=[j for j in manifest['matrix'] if j['episode'] not in completed]
    representatives=[]
    for dataset in SETS:
        pilot_mean=statistics.mean(r['executor_cost_upper_usd'] for r in pilot if r['dataset']==dataset)
        measured=[r['executor_cost_upper_usd'] for r in actual if r['dataset']==dataset]
        representatives.append({'dataset':dataset,'valid':True,'executor_cost_upper_usd':max(pilot_mean,statistics.mean(measured) if measured else 0.)})
    guards=[r for selected in (phase,'main') for path in root.glob(selected+'/episodes/*/*/guard-calls.jsonl.gz')
            for r in read_records(path) if r['event']=='response']
    weights={d:sum(j['dataset']==d for j in pending) for d in SETS}
    already={(r['dataset'],r['scenario_id']) for r in actual}
    unique={d:len({j['scenario']['id'] for j in pending if j['dataset']==d and (d,j['scenario']['id']) not in already}) for d in SETS}
    projection=project_mode(representatives,guards,weights,unique)
    state=Ledger(root/'budget.db').state()
    if state['unresolved']:raise RunStopped('Unresolved requests block cost forecast')
    spent=state['phases'].get('main',{}).get('upper_usd',0.)
    value={'completed':len(completed),'remaining':len(pending),'spent_upper_usd':spent,
           'remaining_base_usd':projection['base_usd'],'total_with_reserve_usd':1.25*(spent+projection['base_usd'])}
    write_json(root/'main-forecast-latest.json',value)
    if value['total_with_reserve_usd']>5.30:
        write_json(root/'halt.json',{'reason':'Updated main forecast exceeds $5.30','forecast':value})
        raise RunStopped('Updated main forecast exceeds $5.30')
    return value


def freeze(root, spec):
    projection = forecast(root); effort = projection['selected']
    if effort is None: raise RunStopped('Neither effort has a verified forecast within $5.30')
    value = {'execution_spec':spec,'execution_fingerprint':digest(spec),'matrix':matrix(),
             'model':MODEL,'effort':effort,'forecast':projection,'frozen_at':datetime.now(UTC).isoformat(),
             'auth_catalog':json.loads((RUNTIME/'auth-catalog.json').read_text())}
    target = root/'manifest.json'
    if target.exists():
        old = json.loads(target.read_text())
        if any(old[k]!=value[k] for k in ('execution_spec','matrix','model','effort')): raise RunStopped('Frozen main manifest changed')
        return old
    write_json(target, value); return value


def check_dry(spec):
    path = HERE/'results/offline-validation.json'
    if not path.exists() or json.loads(path.read_text()).get('execution_fingerprint') != digest(spec):
        raise RunStopped('Complete current-source offline dry 297 required before inference')
    receipt=json.loads(path.read_text());target=Path(receipt['artifact_root'])/'accepted.json'
    if not target.is_relative_to(HERE/'results') or hashlib.sha256(target.read_bytes()).hexdigest()!=receipt['receipt_sha256']:
        raise RunStopped('Offline acceptance evidence damaged')


def execute(args):
    prepare(); spec = execution_spec(); root = args.root.resolve()
    if args.command == 'prepare': return {'prepared':True,'episodes':len(matrix())}
    if args.command == 'report':
        from analysis import report
        return report(root)
    if args.command == 'forecast': return forecast(root)
    if args.command == 'freeze': return freeze(root, spec)
    if args.command == 'checkpoint':
        from analysis import acceptance,report
        if args.batch is None:raise RunStopped('Checkpoint batch required')
        with controller_lock(root):
            manifest=freeze(root,spec)
            finished=json.loads((root/f'batch-{args.batch}-finished.json').read_text())
            quota=quota_snapshot(root,after=finished['at'],max_age=300)
            report(root)
            receipt=acceptance(root,'main',sum(j['batch']<=args.batch for j in matrix()))
            receipt.update(quota=quota,forecast=remaining_forecast(root,manifest))
            write_json(root/f'checkpoint-{args.batch}.json',receipt)
            return receipt
    offline = args.command == 'dry'
    if offline: root = HERE/('results/dry-'+digest(spec)[:12])
    else: check_dry(spec)
    with controller_lock(root):
        if (root/'halt.json').exists(): raise RunStopped('Halt requires explicit reconciliation')
        if not offline:quota_snapshot(root,max_age=300)
        if args.command == 'smoke':
            from worker import smoke
            return smoke(root, spec)
        if args.command == 'pilot':
            smoke=root/'smoke/accepted.json'
            if not smoke.exists() or json.loads(smoke.read_text())['execution_fingerprint']!=digest(spec):
                raise RunStopped('Accepted current-source Medium/High smoke required')
            jobs = [stamp(j,'pilot-'+j['effort'],j['effort'],spec) for j in pilot_jobs()]
        elif args.command == 'main':
            manifest = freeze(root, spec)
            if args.batch is None: raise RunStopped('Main runs one checkpoint batch per command')
            if args.batch>1 and not (root/f'checkpoint-{args.batch-1}.json').exists(): raise RunStopped('Previous checkpoint absent')
            jobs = [stamp(j,'main',manifest['effort'],spec) for j in manifest['matrix'] if j['batch']==args.batch]
        else: jobs = [stamp(j,'dry','medium',spec) for j in matrix()]
        for job in jobs: preflight_job(job, root)
        for phase in {j['phase'] for j in jobs}:
            path = root/phase/'execution.json'
            if path.exists() and json.loads(path.read_text())['fingerprint']!=digest(spec): raise RunStopped('Phase source changed')
            if not path.exists(): write_json(path, {'fingerprint':digest(spec),'spec':spec})
        count = 1 if args.command=='pilot' else 4
        with ThreadPoolExecutor(max_workers=count) as pool:
            for wave in waves(jobs, count):
                if execution_spec()!=spec: raise RunStopped('Source changed during phase')
                if args.command=='main':
                    quota_snapshot(root);remaining_forecast(root,manifest)
                list(pool.map(lambda job:run_worker(job,root,'offline' if offline else 'live'), wave))
        from analysis import acceptance, report
        report(root)
        if offline:
            receipt = acceptance(root,'dry',297)
            receipt.update(execution_fingerprint=digest(spec), external_inference_requests=0)
            write_json(root/'accepted.json', receipt)
            write_json(HERE/'results/offline-validation.json', dict(receipt,artifact_root=str(root),
                       receipt_sha256=hashlib.sha256((root/'accepted.json').read_bytes()).hexdigest()))
        elif args.command=='pilot':
            for effort in ('medium','high'):
                receipt = acceptance(root,'pilot-'+effort,8)
                write_json(root/('pilot-'+effort)/'accepted.json', receipt)
            return forecast(root)
        else:
            acceptance(root,'main',sum(j['batch']<=args.batch for j in matrix()))
            write_json(root/f'batch-{args.batch}-finished.json',{'at':time.time(),'awaiting':'Fresh usage snapshot and checkpoint command'})
        return {'completed':args.command,'episodes':len(jobs)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare','dry','smoke','pilot','forecast','freeze','main','checkpoint','report'])
    parser.add_argument('--root', type=Path, default=HERE/'results/subscription')
    parser.add_argument('--batch', type=int, choices=range(1,6))
    args = parser.parse_args()
    try: print(json.dumps(execute(args), ensure_ascii=False), flush=True)
    except RunStopped as exc:
        print('STOPPED: '+str(exc), file=sys.stderr); sys.exit(2)


if __name__ == '__main__': main()
