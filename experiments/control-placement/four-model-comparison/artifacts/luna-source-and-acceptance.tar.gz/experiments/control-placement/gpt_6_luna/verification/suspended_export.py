"""Offline evidence and complete attempt accounting for a suspended run. No inference."""
import argparse
from collections import Counter
from contextlib import closing
from datetime import UTC, datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from export import csv_export, request_row
from support import digest, read_records, write_json


def summarize_attempts(rows):
    if len({r['attempt_id'] for r in rows}) != len(rows):
        raise ValueError('Duplicate attempt')
    unknown = [r for r in rows if r['accounting_state'] != 'complete']
    known = sum(r['estimate_upper_usd'] for r in rows if r['accounting_state'] == 'complete')
    return dict(attempts=len(rows), known_api_equivalent_usd=known,
                unknown_attempts=len(unknown), unresolved_reservation_usd=sum(r['reservation_usd'] for r in unknown),
                total_api_equivalent_usd=None if unknown else known,
                actual_subscription_charge_usd=None)


def export_suspended(root, output):
    if not (root/'halt.json').exists():
        raise ValueError('Suspended-run export requires halt evidence')
    output.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((root/'manifest.json').read_text())
    from experiment import execution_spec, stamp
    assert digest(execution_spec()) == manifest['execution_fingerprint']
    journals = sorted(set(root.glob('*/episodes/*/*/*calls.jsonl.gz')) | set(root.glob('smoke-*/calls.jsonl.gz')))
    events = {}
    for path in journals:
        for row in read_records(path):
            events.setdefault(row['attempt_id'], []).append((path, row))
    with closing(sqlite3.connect('file:'+str((root/'budget.db').resolve())+'?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        assert db.execute('pragma integrity_check').fetchone()[0] == 'ok'
        ledger = [dict(r) for r in db.execute('select * from intents order by created')]
        assert set(events) == {r['id'] for r in ledger}
        with tempfile.TemporaryDirectory() as work:
            backup = Path(work)/'budget.sqlite'
            with closing(sqlite3.connect(backup)) as target:
                db.backup(target)
                assert target.execute('pragma integrity_check').fetchone()[0] == 'ok'
            (output/'budget.snapshot.sqlite.gz').write_bytes(gzip.compress(backup.read_bytes(), mtime=0))
    requests = []
    unknowns = []
    response_index = {}
    for entry in ledger:
        rows = events[entry['id']]
        intents = [(p, r) for p, r in rows if r['event'] == 'intent']
        responses = [(p, r) for p, r in rows if r['event'] == 'response']
        assert len(intents) == 1
        path, intent = intents[0]
        if entry['state'] == 'complete':
            assert len(responses) == 1
            row = request_row(responses[0][1], intent, path)
            assert abs(row['estimate_upper_usd']-entry['upper']) < 1e-12
            assert row['model'] == 'gpt-6-luna' and row['effective_reasoning'] == row['effort']
            if row['phase'] == 'main':
                assert row['effort'] == manifest['effort'] == 'high'
            response_index[entry['id']] = responses[0][1]
        else:
            assert not responses and entry['state'] == 'unknown'
            raw = [json.loads(r['raw']) for _, r in rows if r['event'] == 'raw_event']
            assert not any(r.get('type') in ('response.completed', 'response.failed', 'response.incomplete') for r in raw)
            created = next((r['response'] for r in raw if r.get('type') == 'response.created'), {})
            headers = next((r for _, r in rows if r['event'] == 'headers'), {})
            stopped = next(r for _, r in rows if r['event'] == 'stopped')
            row = {k:intent.get(k) for k in ('attempt_id', 'phase', 'episode', 'role', 'effort', 'agent', 'view')}
            row.update(response_id=created.get('id'), model=created.get('model'),
                       requested_reasoning=intent['effort'], effective_reasoning=None,
                       observed_created_reasoning=created.get('reasoning'), response_status='unknown',
                       usage_unavailable=['all counters: no terminal response'], native_usage=None,
                       input_tokens=None, output_tokens=None, reasoning_tokens=None, cached_tokens=None, cache_write_tokens=None,
                       estimate_lower_usd=None, estimate_upper_usd=None, actual_subscription_charge_usd=None,
                       requested_temperature=intent['sdk_request'].get('temperature'), effective_temperature=None,
                       requested_max_output_tokens=intent['sdk_request'].get('max_output_tokens'), effective_max_output_tokens=None,
                       intent_at=intent['at'], response_at=None, stopped_at=stopped['at'],
                       latency_s=stopped['at']-intent['at'], error=stopped['reason'],
                       http_status=headers.get('http_status'), request_id=headers.get('headers', {}).get('x-request-id'),
                       raw_event_types=dict(Counter(r.get('type') for r in raw)), raw_journal=str(path),
                       wire_request_sha256=intent['request_sha256'], mapping=intent['mapping'])
            unknowns.append(dict(row))
            source = path.parent
            target = output/'episodes'/intent['episode']
            target.mkdir(parents=True)
            for source_file in source.iterdir():
                if source_file.is_file() and not source_file.name.endswith(('.db', '.db-wal', '.db-shm', '.lock')):
                    shutil.copyfile(source_file, target/source_file.name)
        row.update(accounting_state=entry['state'], reservation_usd=entry['reserved'])
        requests.append(row)
    episodes = json.loads((root/'episodes.json').read_text())
    main = [r for r in episodes if r['phase'] == 'main']
    expected = {r['episode']:stamp(r, 'main', manifest['effort'], manifest['execution_spec']) for r in manifest['matrix']}
    assert len({r['episode'] for r in main}) == len(main)
    for episode in main:
        folder = root/'main/episodes'/episode['episode']
        job = json.loads((folder/'job.json').read_text())
        assert job == expected[episode['episode']]
        assert digest(job) == episode['job_sha256'] and episode['execution_fingerprint'] == manifest['execution_fingerprint']
        snapshot = json.loads((folder/'database.json').read_text())
        with tempfile.TemporaryDirectory() as work:
            backup = Path(work)/'episode.sqlite'
            backup.write_bytes(gzip.decompress((folder/'snapshot.sqlite.gz').read_bytes()))
            with closing(sqlite3.connect(backup)) as db:
                db.row_factory = sqlite3.Row
                assert db.execute('pragma integrity_check').fetchone()[0] == 'ok'
                actual = {name:[dict(r) for r in db.execute('select * from "'+name+'"')] for name in snapshot}
                assert actual == snapshot and len(actual['invoices']) == 6
        completed = Counter(p['invoice_id'] for p in episode['payment_transactions'] if p.get('status') == 'completed')
        assert max(completed.values(), default=0) <= 1
        if episode['valid']:
            guard = json.loads((folder/'defender.json').read_text())
            assert len(guard['votes']) == 3
            for answer in guard['votes']+list(guard['views'].values()):
                assert digest(answer['identity']) == answer['query_id']
                assert answer['identity']['phase'] == 'main'
                assert answer['identity']['execution_fingerprint'] == manifest['execution_fingerprint']
                assert response_index[answer['attempt_id']]['estimate']['upper_usd'] == answer['cost_usd']
    phases = {phase:summarize_attempts([r for r in requests if r['phase'] == phase]) for phase in sorted({r['phase'] for r in requests})}
    result = dict(status='suspended_unresolved_provider_outcomes', generated_at=datetime.now(UTC).isoformat(),
                  main_completed=sum(r['valid'] for r in main), main_failed=sum(not r['valid'] for r in main),
                  main_unstarted=297-len(main), main_required=297, accepted_checkpoints=[1, 2, 3],
                  accounting=phases, all_phases=summarize_attempts(requests), unknowns=unknowns,
                  last_preincident_forecast=json.loads((root/'main-forecast-latest.json').read_text()),
                  last_forecast_is_not_postincident_verified=True,
                  core_execution_fingerprint=manifest['execution_fingerprint'], new_inference_requests=0,
                  business_databases_checked=len(main), guard_completed_episodes=sum(r['valid'] for r in main),
                  limitation='No completed terminal or usage for four sent requests; unknown counters are null. Reservation is not measured cost. No retry or business action replay.')
    write_json(output/'requests.json', requests)
    csv_export(output/'requests.csv', requests)
    write_json(output/'episodes.json', episodes)
    csv_export(output/'episodes.csv', episodes)
    write_json(output/'incident.json', result)
    for name in ('halt.json', 'summary.json', 'main-forecast-latest.json', 'usage-latest.json'):
        shutil.copyfile(root/name, output/name)
    files = [p for p in (root/'main').rglob('*') if p.is_file() and not p.name.endswith(('.db', '.db-wal', '.db-shm', '.lock'))]
    files += [p for p in output.rglob('*') if p.is_file()]
    write_json(output/'inventory.json', {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
    write_json(output/'audit.json', dict(main_records=len(main), model_parameters_verified_completed_requests=len(response_index),
               unknown_requests=len(unknowns), complete_attempts_reconcile_with_ledger=True,
               business_db_checks=len(main), unique_completed_payments=True, completed_guard_provenance=True,
               export_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), network_calls=0))
    return {k:result[k] for k in ('status', 'main_completed', 'main_failed', 'main_unstarted', 'all_phases')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE/'results/subscription')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(export_suspended(args.root.resolve(), args.output.resolve())))
