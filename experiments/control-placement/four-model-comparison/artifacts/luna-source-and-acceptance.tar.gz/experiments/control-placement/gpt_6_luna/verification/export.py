"""Read-only posthoc export. Never imports a model client or submits inference."""
import argparse
import csv
from datetime import UTC,datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from support import Ledger,PRICING,digest,read_records,write_json


def request_row(row,intent,path):
    native=row['native_response'];usage=native.get('usage') or {};sdk=intent.get('sdk_request') or {}
    estimate=row['estimate'];details=usage.get('input_tokens_details') or {}
    output_details=usage.get('output_tokens_details') or {}
    return {k:row.get(k) for k in ('attempt_id','phase','episode','role','effort','agent','view','latency_s','first_event_s','first_text_s')} | {
        'response_id':native.get('id'),'model':native.get('model'),'response_status':native.get('status'),
        'requested_reasoning':row.get('effort'),'effective_reasoning':(native.get('reasoning') or {}).get('effort'),
        'requested_temperature':sdk.get('temperature'),'effective_temperature':native.get('temperature'),
        'requested_max_output_tokens':sdk.get('max_output_tokens',sdk.get('max_tokens')),
        'effective_max_output_tokens':native.get('max_output_tokens'),
        'output_limit_configurable':False,'temperature_configurable':False,
        'effective_service_tier':native.get('service_tier'),
        'effective_cache_retention':native.get('prompt_cache_retention'),
        'input_tokens':usage.get('input_tokens'),'output_tokens':usage.get('output_tokens'),
        'reasoning_tokens':output_details.get('reasoning_tokens'),
        'cached_tokens':details.get('cached_tokens'),'cache_write_tokens':details.get('cache_write_tokens'),
        'estimate_lower_usd':estimate['lower_usd'],'estimate_upper_usd':estimate['upper_usd'],
        'actual_subscription_charge_usd':None,'usage_unavailable':estimate.get('unavailable',[]),
        'mapping':intent.get('mapping'),'wire_request_sha256':intent.get('request_sha256'),
        'intent_at':intent.get('at'),'response_at':row.get('at'),'native_usage':usage,
        'raw_journal':str(path),'synthetic':row.get('synthetic',False)}


def unique_requests(rows):
    if len({row['attempt_id'] for row in rows})!=len(rows):raise ValueError('Duplicate request accounting')
    return rows


def quota_observations(rows):
    return {'observations':rows,'experiment_exclusive_usage':None,
            'interpretation':'Shared account windows; changes include this Codex chat and other apps, not only FinBot.',
            'actual_subscription_charge_usd':None}


def csv_export(path,rows):
    if not rows:return
    with path.open('w') as handle:
        writer=csv.DictWriter(handle,fieldnames=sorted({key for row in rows for key in row}),lineterminator='\n');writer.writeheader()
        for row in rows:writer.writerow({key:json.dumps(value,ensure_ascii=False) if isinstance(value,(dict,list)) else value
                                        for key,value in row.items()})


def collect(root):
    episodes=[];requests=[];journals=[]
    for guard_path in sorted(root.glob('*/episodes/*/*/defender.json')):
        dest=guard_path.parent;path=dest/'episode.json'
        if not path.exists():continue
        episode=json.loads(path.read_text());guard=json.loads(guard_path.read_text())
        episode.update(input_guard_block=guard['block'],input_guard_votes=guard['votes'],
            guard_cache_hits=guard.get('cache_hits'),guard_provider_wait_s=guard.get('measured_model_wait_s'),
            executor_workflow_s=episode.get('wall_s'),workflow_and_posthoc_s=episode.get('full_wall_s'),
            executor_provider_wait_s=episode.get('model_wait_s'),
            workflow_other_s=episode.get('tool_and_workflow_s'),
            process_startup_s=None,scheduling_wait_s=None,
            elapsed_definition='From workflow invocation through posthoc; process import/startup and scheduling waits unavailable')
        episodes.append(episode)
        journals.extend([dest/'calls.jsonl.gz',dest/'guard-calls.jsonl.gz'])
    if (root/'smoke/accepted.json').exists():journals.extend(sorted(root.glob('smoke-*/calls.jsonl.gz')))
    for path in journals:
        rows=read_records(path);intents={r['attempt_id']:r for r in rows if r['event']=='intent'}
        for row in rows:
            if row['event']=='response':requests.append(request_row(row,intents[row['attempt_id']],path))
    return episodes,unique_requests(requests),journals


def paired_comparison(episodes,baseline):
    control={row['episode']:row for row in baseline if row['phase']=='main'}
    comparisons={}
    for phase in sorted({row['phase'] for row in episodes}):
        pairs=[(row,control[row['episode']]) for row in episodes if row['phase']==phase and row['episode'] in control]
        comparisons[phase]={'matched_episodes':len(pairs),
            'luna_transferred':sum(bool(a['transfers']) for a,b in pairs),
            'deepseek_transferred_matched':sum(bool(b['transfers']) for a,b in pairs),
            'luna_executor_api_equivalent_usd':sum(a['executor_cost_upper_usd'] for a,b in pairs),
            'deepseek_executor_eliza_usd_matched':sum(b['executor_cost_usd'] for a,b in pairs),
            'executor_elapsed_delta_median_s':statistics.median(a['wall_s']-b['wall_s'] for a,b in pairs) if pairs else None,
            'pairs':[{'episode':a['episode'],'dataset':a['dataset'],'scenario_id':a['scenario_id'],'repeat':a['repeat'],
                      'luna_status':a['invoice_status'],'deepseek_status':b['invoice_status'],
                      'luna_transfers':len(a['transfers']),'deepseek_transfers':len(b['transfers']),
                      'luna_executor_s':a['wall_s'],'deepseek_executor_s':b['wall_s']} for a,b in pairs]}
    return comparisons


def export(root,output,allow_partial=False):
    root=root.resolve();output.mkdir(parents=True,exist_ok=True)
    episodes,requests,journals=collect(root)
    main=[row for row in episodes if row['phase']=='main']
    if not allow_partial and len(main)!=297:raise ValueError('Full main 297 required; --allow-partial is explicit')
    if not allow_partial and (not (root/'checkpoint-5.json').exists() or Ledger(root/'budget.db').state()['unresolved']):
        raise ValueError('Final checkpoint and reconciled ledger required')
    for row in requests:
        if row['model']!='gpt-6-luna' or row['requested_reasoning']!=row['effective_reasoning']:
            raise ValueError('Model/effort mismatch in export')
    by_phase={}
    for phase in sorted({row['phase'] for row in requests}):
        group=[r for r in requests if r['phase']==phase]
        by_phase[phase]={'requests':len(group),'lower_usd':sum(r['estimate_lower_usd'] for r in group),
                         'upper_usd':sum(r['estimate_upper_usd'] for r in group),
                         'input_tokens':sum(r['input_tokens'] for r in group),
                         'output_tokens':sum(r['output_tokens'] for r in group),
                         'reasoning_tokens_known_sum':sum(r['reasoning_tokens'] or 0 for r in group),
                         'reasoning_counter_unavailable':sum(r['reasoning_tokens'] is None for r in group)}
    quota_paths=sorted(root.glob('usage*.json'))
    observations={}
    for path in quota_paths:
        row=json.loads(path.read_text());observations[row['observed_at']]=row
    quota=quota_observations([observations[key] for key in sorted(observations)])
    baseline_path=HERE.parent/'deepseek_flash/results/paid/episodes.json'
    comparison=paired_comparison(episodes,json.loads(baseline_path.read_text()))
    metadata={'exported_at':datetime.now(UTC).isoformat(),'main_completed':len(main),'main_required':297,
        'partial':len(main)!=297,'accounting':by_phase,'pricing':PRICING,'counterfactual_guard_only':True,
        'selection':json.loads((root/'forecast.json').read_text()) if (root/'forecast.json').exists() else None,
        'subscription_usage':quota,'matched_deepseek':comparison,
        'deepseek_main_executor_and_guard_eliza_usd':4.403506026,
        'limitations':['API-equivalent estimates are not subscription charges.',
            'System/developer mapping, function namespace, omitted output cap and temperature are authorized protocol differences.',
            'Native prompt-cache retention observed per request; application caches are phase/effort isolated.',
            'Workflow and posthoc times exclude process startup and scheduling waits; unavailable values stay null.',
            'Original dates in scenario descriptions are preserved; execution date is 2026-10-25.',
            'Smoke and pilot requests are excluded from main; shared guard vote references are not billed twice.']}
    write_json(output/'requests.json',requests);write_json(output/'episodes.json',episodes)
    write_json(output/'comparison.json',metadata);csv_export(output/'requests.csv',requests);csv_export(output/'episodes.csv',episodes)
    with (output/'requests.jsonl').open('w') as handle:
        for row in requests:handle.write(json.dumps(row,ensure_ascii=False)+'\n')
    inventory={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in journals}
    write_json(output/'receipt.json',{'requests':len(requests),'episodes':len(episodes),'main':len(main),
        'unique_attempts':len({r['attempt_id'] for r in requests}),'raw_inventory':inventory,
        'export_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'ledger':Ledger(root/'budget.db').state(),'generated_at':metadata['exported_at']})
    lines=['# FinBot Luna: сравнение', '', f'Основная серия: {len(main)}/297. Все расходы ниже — API-эквивалент.',
           'Защитник оценивается posthoc; расчетные блокировки не являются реально предотвращенными переводами.', '',
           '| Фаза | Запросы | API-эквивалент, USD |', '|---|---:|---:|']
    for phase,value in by_phase.items():lines.append(f'| {phase} | {value["requests"]} | {value["upper_usd"]:.8f} |')
    lines += ['', 'DeepSeek main executor+guard: $4.403506026 по сверке Eliza. Сравнение использует одинаковые ID/повторы; пилоты не смешаны с main.',
              '', 'Полные данные и ограничения: comparison.json; 22 сочетания правил и Wilson95: summary.json контроллера.']
    (output/'COMPARISON.md').write_text('\n'.join(lines)+'\n')
    return {'requests':len(requests),'episodes':len(episodes),'main':len(main),'output':str(output)}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=HERE/'results/subscription')
    parser.add_argument('--output',type=Path,default=HERE/'results/subscription/export')
    parser.add_argument('--allow-partial',action='store_true')
    args=parser.parse_args()
    print(json.dumps(export(args.root,args.output,args.allow_partial)))
