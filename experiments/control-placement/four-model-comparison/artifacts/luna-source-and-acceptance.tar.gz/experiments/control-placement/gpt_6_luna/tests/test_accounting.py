import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))


class AccountingTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "support.py").is_file(), "Missing Luna accounting")
        spec = importlib.util.spec_from_file_location("luna_support", HERE / "support.py")
        self.s = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.s)

    # Reasoning — часть output; второй раз не начисляется.
    def test_reasoning_not_double_charged(self):
        usage = {"input_tokens": 1000, "output_tokens": 100,
                 "input_tokens_details": {"cached_tokens": 0, "cache_write_tokens": 0},
                 "output_tokens_details": {"reasoning_tokens": 80}}
        estimate = self.s.estimate_usage(usage)
        self.assertAlmostEqual(estimate["lower_usd"], .00015)
        self.assertAlmostEqual(estimate["upper_usd"], .00015)
        self.assertEqual(estimate["reasoning_tokens"], 80)

    # Отсутствующие cache-write counters дают диапазон, а не вымышленный ноль.
    def test_missing_cache_writes_are_bounded_explicitly(self):
        estimate = self.s.estimate_usage({"input_tokens": 1000, "output_tokens": 100,
                                          "input_tokens_details": {"cached_tokens": 500}})
        self.assertAlmostEqual(estimate["lower_usd"], .000105)
        self.assertAlmostEqual(estimate["upper_usd"], .00018)
        self.assertIn("cache_write_tokens", estimate["unavailable"])
        self.assertIsNone(estimate["actual_charge_usd"])

    # Некорректные счетчики не превращаются в дешевый запрос.
    def test_invalid_counters_rejected(self):
        for usage in [{}, {"input_tokens": True, "output_tokens": 2},
                      {"input_tokens": 10, "output_tokens": 2, "input_tokens_details": {"cached_tokens": 11}}]:
            with self.assertRaises(self.s.RunStopped):
                self.s.estimate_usage(usage)

    # Завершенный запрос нельзя завершить или зарезервировать повторно.
    def test_ledger_completes_once(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = self.s.Ledger(Path(directory) / "ledger.db")
            with ledger.request_lease("one"):
                ledger.reserve("one", "main", .1, {"role": "executor"})
                ledger.complete("one", {"upper_usd": .01, "lower_usd": .01}, {"response_id": "r1"})
                with self.assertRaises(self.s.RunStopped):
                    ledger.complete("one", {"upper_usd": .01}, {})
            self.assertAlmostEqual(ledger.state()["estimate_upper_usd"], .01)
            with self.assertRaises(self.s.RunStopped):
                ledger.reserve("one", "main", .1, {})

    # Неопределенный результат блокирует новые генерации.
    def test_unknown_outcome_blocks_next_request(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = self.s.Ledger(Path(directory) / "ledger.db")
            with ledger.request_lease("one"):
                ledger.reserve("one", "pilot-medium", .1, {})
                ledger.unknown("one", "stream interrupted")
            with ledger.request_lease("two"):
                with self.assertRaises(self.s.RunStopped):
                    ledger.reserve("two", "pilot-high", .1, {})

    # Main budget не включает пилоты; активные резервы входят в main exposure.
    def test_main_cap_and_pilot_separation(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = self.s.Ledger(Path(directory) / "ledger.db", cap=.15)
            with ledger.request_lease("pilot"):
                ledger.reserve("pilot", "pilot-medium", .3, {})
                ledger.complete("pilot", {"upper_usd": .2, "lower_usd": .1}, {})
            with ledger.request_lease("one"), ledger.request_lease("two"):
                ledger.reserve("one", "main", .1, {})
                with self.assertRaises(self.s.RunStopped):
                    ledger.reserve("two", "main", .1, {})

    # Потерянный процесс освобождает lease, но его незавершенный intent блокирует следующий.
    def test_stale_process_intent_blocks_resume(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger=self.s.Ledger(Path(directory)/'ledger.db')
            with ledger.request_lease('crashed'):
                ledger.reserve('crashed','pilot-medium',.1,{})
            with ledger.request_lease('next'):
                with self.assertRaises(self.s.RunStopped):ledger.reserve('next','pilot-medium',.1,{})

    # Поврежденный gzip не принимается как пустой завершенный журнал.
    def test_damaged_journal_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'calls.jsonl.gz';path.write_bytes(b'broken')
            with self.assertRaises(self.s.RunStopped):self.s.read_records(path)


if __name__ == "__main__":
    unittest.main()
