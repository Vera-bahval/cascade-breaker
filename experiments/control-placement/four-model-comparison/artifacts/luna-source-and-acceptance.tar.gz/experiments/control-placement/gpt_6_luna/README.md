# FinBot на GPT-6 Luna через подписку

Пользователь согласовал протокол 2: убрать неподдерживаемые серверный лимит output
и temperature, отображать system→developer и группировать функции в `finbot_tools`.
Исходное содержимое, схемы инструментов и оркестрация FinBot сохраняются.
Сопоставление с DeepSeek имеет эти явные ограничения. Условие 5000 больше не effective.

Реализованы OAuth/OIDC flow с PKCE, локальный broker токенов в RAM, записывающий SSE
transport, ledger намерений, изоляция SQLite/кэшей, парные пилоты и расчет API-эквивалента.
FinBot SDK не сохраняет native reasoning items; transport восстанавливает их только
при точном совпадении прежней истории того же агента в том же эпизоде. Оригинальные
reasoning items и encrypted_content остаются в журнале. Harness Codex не добавляется.

**Серия завершена и принята: 297/297, обе роли High.**
Итог: [сравнение с DeepSeek](results/subscription-resume-1/export/COMPARISON.md),
[297 канонических эпизодов CSV](results/subscription-resume-1/export/episodes.csv),
[6847 намерений запросов CSV](results/subscription-resume-1/export/requests.csv),
[машинный отчёт JSON](results/subscription-resume-1/export/comparison.json).

High выбран по прогнозу пилотов $3.53498233125 с запасом 25% против Medium
$3.26966986875, оба ниже $5.30. Main: известный API-эквивалент $1.63539998 плюс
неизвестный usage четырёх исходных запросов. Резерв этих неизвестных $0.9317792 —
плановое допущение, не измеренный расход; итог с резервом и 25% $3.208973975.
Smoke $0.0001814 и пилоты $0.10984318 отдельно. Подписочный weekly used 6%→21%
относится ко всему аккаунту, не только FinBot. Покупок/платного API не было.

FPR Luna/DeepSeek: 0/150 и 0/150. Честные переводы: 44/150 и 113/150;
плохие funnel-переводы: 3/43 и 6/43. Эквивалентность качества не установлена.
Защитник posthoc, 702 уникальных входных голоса и 22 сочетания сохранены.

200 готовых workflow не повторялись. Пользователь разрешил 93 новых и четыре
свежих повтора после технического сбоя; все они завершены. Четыре исходных
неизвестных остались unknown/null, их попытки включены в 301 main workflow attempts.
Подробности — RECOVERY.md, история исходного инцидента —
results/subscription/incidents/stream-timeouts-20261025T1413/SUSPENDED.md.
Исходный subscription root и DeepSeek сохранены. Полный аудит — export/receipt.json
в активном root results/subscription-resume-1; backup/inventory — checkpoints/batch-5/.
RAM helper закрыт с exit 0; heartbeat finbot-luna-97 удалён. Remote OAuth revocation
не выполнялась. Все изменения сохраняются локально без push/PR.

Текущий статус — STATUS.md; CONTINUATION.md запрещает повторный запуск завершённой
серии. PLAN.md — согласованный протокол, PROGRESS.md — исторический журнал.
Наличие CLI login не заменяет отдельный OAuth grant.
`PLAN.md` — согласованный протокол; `PROGRESS.md` — журнал выполнения.

Команды из checkout, через Python существующего `.venv-finbot`:

```sh
python experiments/control-placement/gpt_6_luna/experiment.py dry
python experiments/control-placement/gpt_6_luna/subscription_auth.py
```

После интерактивного входа auth helper принимает в stdin JSON с `action=run` и `argv`
только для локального `experiment.py`. В argv и файлы секреты не передаются. Команды:
`smoke`, `pilot`, `forecast`, `freeze`, `main --batch N`, `report`. Токены действуют
только пока жив auth helper; `action=close` уничтожает broker. Ошибки и неизвестные
исходы останавливают генерации; частичный executor автоматически не перезапускается.
Восстановление готового executor может продолжить только posthoc защитника.

Ниже — историческое обоснование изменения протокола. Receipts preflight v1/v2
не переписаны и не являются разрешением на текущий live запуск.

## Что проверено

- Установлен `codex-cli 0.163.0`; штатный `codex login status` подтвердил вход через ChatGPT.
  Креды не извлекались; наличие входа не доказывает право отдельного OAuth-клиента.
- JSON Schema экспортирована самим установленным CLI с `--experimental`.
- Проверены исходные SHA256 трех наборов, matrix 297 и пакеты 62/59/59/59/58.
  Матрица скопирована без старых model/financial/acceptance полей.
- Сохранен настоящий исходный SDK-запрос TH601 с system/user/assistant messages,
  function calls, function outputs и оригинальными tool schemas.
- Выполнены offline unit tests аудита. Это **не** полный offline replay 297 через FinBot.
- Диагностическая команда не импортирует FinBot, не читает credential store
  и не отправляет запросы к модели. Нулевое число генераций не объявляется
  измеренной стоимостью inference `$0`: стоимость и расход лимитов здесь недоступны.

## Ограничение текущего app-server

`turn/start.input` ссылается на `UserInput`: text/image/audio/skill/mention и локальные
медиа. Он не принимает исходный stateless Responses input FinBot с ролями сообщений
и историей function_call/function_call_output.

У `thread/resume.history` действительно есть тип `ResponseItem[]`, однако описание
самой установленной схемы помечает его: `[UNSTABLE] FOR CODEX CLOUD - DO NOT USE.`
Этот внутренний интерфейс не использовался.

`baseInstructions`, `developerInstructions`, `dynamicTools`, `effort` и `outputSchema`
присутствуют. Их наличие не доказывает эквивалентность FinBot: передача всей истории
одним пользовательским текстом меняет роли, а обработка tools внутри Codex переносит
часть управления в другой harness. Промпт «реши этот счет» не является адаптером.

В публичных ThreadStart/TurnStart/Config schema не установлен mapping для исходного
`max_output_tokens=5000` и `temperature=0`. Это ограничение проверенного публичного
контракта, а не доказательство отсутствия любых возможных config extensions.
Непроверенные config overrides не использовались.

Поле `effort` присутствует, но `ReasoningEffort` в этой версии схемы — непустая
строка, без enum поддержанных значений. Пустой `reasoning_efforts_in_schema` в отчете
означает отсутствие перечисления в схеме. Это не утверждение об отсутствии reasoning
у Luna. Runtime модели и effective settings не проверены: генераций до прохождения
route gate не выполняли.

## Проверка второго официального маршрута

Есть отдельный официальный OAuth plan-usage flow с публичным Responses endpoint.
Он позволяет передавать stateless context без Codex harness, но имеет собственные
ограничения, препятствующие исполнению текущего протокола. Доступ аккаунта к этому
отдельному flow не проверен; для установления документированных ограничений вход не нужен.

Для этого требуется зарегистрировать отдельный клиент, провести интерактивный вход,
проверить OIDC identity/nonce/signature и выданный scope `chatgpt.tokens.use.direct`.
Обычный CLI login и cached model catalog не заменяют этот grant. CLI access token
не извлекался и не переиспользовался для самодельного HTTP proxy.

В этом flow документированы `POST https://api.openai.com/v1/responses`, `store=false`
и `stream=true`. Однако preview contract исключает `max_output_tokens` и `temperature`;
system messages нужно отображать в instructions/developer, а функции группировать
в namespaces либо передавать через additional_tools. Поэтому новый OAuth-вход сам
по себе не позволит сохранить обязательный лимит 5000 токенов и исходный payload.
Документированные ограничения проверены до регистрации и генераций. Ошибку HTTP
мы не провоцировали и runtime-отказ не заявляем.

Дополнительно текущая GPT-6 guidance требует исключить `temperature` при reasoning
Medium/High. Эффективное `temperature=0` в этих режимах обещать нельзя. Перед
продолжением нужно изменить протокол: отдельно определить условия без серверного
лимита 5000, отображение system role и tools и недоступность temperature. Это выходит
за принятую реализацию с обязательной проверкой сопоставимости. Авторизация и адаптер
не заявлены готовыми; до inference остаются fault tests и полный offline replay 297.

Источники, проверены 25 октября 2026:

- [Codex app-server](https://learn.chatgpt.com/docs/app-server).
- [Регистрация и вход OAuth-клиента](https://developers.openai.com/siwc/token-sharing-open-source/sign-in).
- [Inference через лимит подписки](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).
- [Ограничения подписочного Responses API](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations).
- [Совместимость параметров GPT-6](https://developers.openai.com/api/docs/guides/latest-model).

## Воспроизведение

Из корня этого checkout:

```sh
/opt/homebrew/bin/codex app-server generate-json-schema --experimental --out /private/tmp/luna-schema-new
python3 experiments/control-placement/gpt_6_luna/preflight.py \
  --schema-dir /private/tmp/luna-schema-new \
  --baseline experiments/control-placement/deepseek_flash \
  --output experiments/control-placement/gpt_6_luna/results/preflight-new
/Users/proskurin-dmi/arcadia/ya tool rtk python3 -m unittest discover \
  -s experiments/control-placement/gpt_6_luna/tests -v
```

Использовать новый output directory: команда откажется перезаписывать старые доказательства.
Код возврата preflight **2** означает отсутствие допуска к inference, включая случай,
когда статическая схема не нашла блокеров, но runtime proof еще отсутствует.

`results/preflight-20261025-v2/report.json` содержит итог двух маршрутов, ограничения,
provenance и SHA256 кода и артефактов. Первая native-only проверка сохранена отдельно
в `results/preflight-20261025/`, без изменения ее receipt.
`schemas/` — точные файлы CLI; `finbot-sdk-request.reference.json` и `matrix.reference.json`
— доказательства из DeepSeek, **не** Luna output и **не** разрешение на запуск.
`requested-series.json` — незамороженный draft параметров без accepted receipts,
финансового ledger или кэша прошлой серии. Отдельные чаты и таймеры не создавались:
длительный эксперимент пока не запущен.
