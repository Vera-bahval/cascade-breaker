# Execution ledger — PLAN.md

- FINAL: checkpoint 5 accepted, 297/297 canonical episodes, 301 main business
  databases audited. All 6847 intent IDs reconciled with full ledger: 6843 complete
  and four original unknown with null usage; no new unknown and pending 0.
  Canonical main $1.62619236, old failed known steps $0.00920762, main known
  $1.63539998 plus unknown four. Planning bound $0.9317792, with 25% $3.208973975.
  Full CSV/JSON/JSONL export, 702 unique input votes, 22 combinations, matched
  DeepSeek and native-counter recalculation audited offline; 15 verification tests.
  FPR 0/150 both, honest transferred Luna 44/150 vs DeepSeek 113/150, bad 3/43 vs 6/43.
  Weekly shared account usage 6%->21%, ordinary available at final observation.
  Helper 66225 closed exit 0; native heartbeat finbot-luna-97 deletion confirmed.
  No remote revocation, purchases, paid API, push or PR. Final results remain local.

- Recovery checkpoint 4 accepted: 239/297, 5177 main intents, pending 0; four
  original unknown states remain explicit, no new unknowns. All business DBs,
  unique payments, raw accounting and guard provenance audited. Known main
  API-equivalent $1.32290806 plus unknown four; planning bound $0.9317792, combined
  forecast with 25% $3.6159952625. Stable read-only ledger backup and inventory
  saved in resume root checkpoints/batch-4/. Shared Pro weekly 19%, ordinary
  available, 17:38:07 UTC. Main batch 5 launched in helper 66225, last 58 episodes.

- User authorized 93 remaining new episodes and fresh retries of four failed ones.
  Recovery overlay isolated in auth_catalog.py / verification/resumption.py, with
  its own hash; frozen model/FinBot/transport/prompt source bytes unchanged.
  New root subscription-resume-1 preserves 200 completed workflows (1400 files
  byte-identical), rebases only cache journal paths, archives four failed attempts,
  and copies the ledger with four unknown states intact. Budget allowance is exact
  ID/context/reservation scoped; all new unknowns block. Six tests RED->GREEN;
  11 verification tests pass, dry all 97/97 external inference 0. Exact first wire
  requests match except original FinBot GLOBAL_CONTEXT runtime clock. Conservative
  old-unknown budget bound $0.9317792; combined forecast including 25% $3.8489522242.
  New current-chat heartbeat finbot-luna-97. Operational details: RECOVERY.md.
- Main halted in batch 4: 200 completed, 4 incomplete technical outcomes, 93 unstarted.
  Four sent HTTP200 streams hit 60-second timeout without terminal or usage; root
  cause unconfirmed. Four unknown ledger entries and halt retained. No transfers
  in those four business databases. Known main API equivalent $1.08306886 plus
  unknown usage, reservation $0.285596 is not measured cost. No generation/retry
  during investigation. Offline suspended exporter audited all 204 DBs, 4674
  attempts, 4670 known responses, guard provenance and unchanged online fingerprint;
  all-phase/unknown CSV/JSON and original copies preserved under incidents/stream-
  timeouts-20261025T1413/. New exporter tests RED then GREEN, all 5 verification
  tests pass. Last accepted checkpoint remains 3/180. Helper 66225 idle, credentials
  retained in RAM for a possible authorized recovery; no invalidation claimed.
- Checkpoint 3 accepted: 180/297, 3806 main requests, pending/unknown 0, unchanged
  fingerprint. Main API equivalent $0.96038538; forecast with reserve $2.7926212479166663.
  SQLite/payment/raw usage audit passed; ledger backup and raw inventory preserved
  in checkpoints/batch-3/. Shared Pro weekly usage 14%, ordinary available, observed
  13:55:42 UTC. Main batch 4 started, target 239, both roles High, concurrency 4.
- Checkpoint 2 accepted: 121/297, 2592 main requests, pending/unknown 0, unchanged
  fingerprint. Main API equivalent $0.64804270; forecast with reserve $3.1186868875.
  SQLite/payment/raw usage audit passed; ledger backup and raw inventory preserved
  in checkpoints/batch-2/. Shared Pro weekly usage 12%, ordinary available, observed
  12:55:43 UTC. Main batch 3 started, target 180, both roles High, concurrency 4.
- Checkpoint 1 accepted: 62/297, 1285 main requests, pending/unknown 0, SQLite and
  unique simulated payments audited, model/effort/usage/fingerprint verified.
  Main API equivalent $0.32761642; remaining projection with reserve totals
  $3.26896341875. Shared subscription snapshot 11:55:59 UTC: ordinary available,
  Pro weekly 10% used. Ledger backup/inventory preserved in checkpoints/batch-1/;
  derived CSV newline normalization proved parsed-value equality. Main batch 2
  started in the same RAM OAuth helper, cumulative target 121, concurrency 4.
- Main batch 1 is running in session 66225 with both roles High. Snapshot around
  11:23 UTC: 20 accepted episodes, unknown 0, no halt; active provider intents are
  still pending normally. Updated total forecast with reserve: $3.45959318125.
  Shared Pro weekly snapshot at 11:22:30 UTC: 9% used, ordinary usage allowed.
  Checkpoint 1 still outstanding. Background continuation: CONTINUATION.md.
- Live continuation, 2026-10-25: OAuth completed and identity/scopes verified;
  Luna is listed. RAM-only helper active in exec session 66225. No credentials
  in this ledger, source control, argv or provider journals.
- First plain smoke completed on gpt-6-luna, effective medium, service_tier default,
  input 11/output 5/reasoning 0, cached 0/cache-write 0; API-equivalent $0.0000036.
  The terminal envelope omitted output items already delivered in output_item.done.
  Initial decoder stopped before SDK delivery; no unknown cost or business actions.
- Systematic debugging: two regression tests first failed, then passed after
  assembling authoritative completed items by output index. Conflicts/gaps fail
  closed. Native terminal remains unchanged beside assembled_response in logs.
  Full suite 59/59. Actual saved SSE recovered OK offline, ledger unchanged,
  no repeated inference. Incident receipts: results/subscription/incidents/sse-assembly-20261025/.
- New full dry exercises this same split-SSE envelope; artifact root is versioned
  by execution fingerprint. Current acceptance index updates only after 297 pass.
- Heartbeat created: finbot-luna-30, current thread, every 30 minutes. Remove on
  completion or definitive stop. OAuth broker is idle while offline replay runs.
- SSE fix full replay accepted: 297/297, 59/59 unit/fault tests; fingerprint
  b45d9be5087824ca1aa6be68a2945250529d44fc90d9d93f3fb7485801f095fb.
- Both live smoke modes accepted, eight completed requests total including the
  recovered first plain response (not repeated). Model/effort/default tier verified;
  strict guard JSON and actual echo tool/result/completion passed. All usage present,
  no unknown/pending. Smoke API-equivalent $0.0001814, separate from main/pilots.
  Runtime audit: results/subscription/smoke/runtime-audit.json.
- Paired pilots launched through existing RAM OAuth helper, sequential order from
  pilot_jobs; current-source caches isolated by phase and effort. Main unselected.
- Pilots completed and accepted 16/16; all original IDs/order/repeats/job hashes
  checked, 377 unique completed requests, every usage counter present, unknown 0.
  Pilot API-equivalent $0.10984318; smoke $0.0001814 separately. Runtime audit:
  results/subscription/pilot-runtime-audit.json; rich CSV/JSON: pilot-export/.
- Forecast including 25% reserve: Medium $3.26966986875, High $3.53498233125.
  Rule selects High because <=$5.30. No quality criterion was used. Frozen manifest
  keeps both roles High and fingerprint b45d9be5087824ca1aa6be68a2945250529d44fc90d9d93f3fb7485801f095fb.
- Subscription snapshot after pilots: ordinary usage allowed, Pro weekly 9% used;
  shared-account observation, not an exclusive FinBot delta. Main batch 1 next.

- Protocol 2 authorized: user «Согласую», 2026-10-25. Omit max_output_tokens and
  temperature; preserve text and order while mapping system→developer and grouping
  functions under finbot_tools. Original preflight receipts remain immutable history.
- Resume: implement supported direct OAuth route; native app-server remains excluded.
  New auth scope must be granted by the user; credentials stay in RAM, not files.

- Protocol 2 implementation: separate OAuth/OIDC registration, PKCE/state/nonce and
  signed identity validation; RAM-only token broker with Unix socket permissions.
  Existing Codex credential store was neither read nor reused. First interactive
  authorization expired before sign-in; zero inference requests occurred.
- Adapter preserves original prompt contents/order, function schemas, arguments,
  call IDs and tool outputs. Authorized changes are logged per request. The pinned
  FinBot SDK drops reasoning items; the transport restores native encrypted items
  only after an exact same-agent history-prefix match within the episode.
- Fault/unit suite: 57 tests pass through RTK (OAuth, mapping, SSE, usage, price
  bounds, unknown/stale intents, damaged journals, controller lock, quota gate,
  timeout, failed/rerouted/compacted responses and offline import firewall).
- First full offline integration: 297/297, all valid, SQLite and journal audit
  passed. Synthetic TH601 response replay is explicitly not Luna quality evidence.
  Artifacts remain under results/dry/ as preliminary evidence.
- Self-review found checkpoint gaps; fixed main forecast checks between waves and
  mandatory fresh subscription-window snapshots. A batch completes only after a
  separate checkpoint audit; a completed executor is never automatically rerun.
- Current-source full replay completed under results/dry-protocol2/: 297/297 valid,
  acceptance passed, 22 rule combinations, 307 FinBot source files match baseline.
  results/offline-validation.json binds the exact current execution fingerprint;
  results/VALIDATION.json summarizes verification. The first receipt remains historical.
- Live smoke, Medium/High pilots, mode selection and main 297 remain outstanding.
  No generation has been sent; subscription snapshots are shared-account readings.

- Baseline: DeepSeek worktree clean at `025128e23a646b3b38e48272c726c754e067ecf0`.
- Branch: `codex/gpt-6-luna-control-placement`; reused the existing isolated worktree.
- Pre-flight: transport compatibility precedes fault replay, smoke, pilots and main.
  A schema catalog cannot establish entitlement or equivalent model requests.
- Task 1: RED — ten offline preflight tests fail because the preflight is absent.
- Task 1: implementation — inspect CLI-generated schemas and a real frozen SDK request;
  never import FinBot, access credentials or submit inference during this step.
- Task 1: GREEN — `python3 -m unittest discover -s experiments/control-placement/gpt_6_luna/tests -v`
  through RTK: 10 tests, no failures. Actual CLI export + real baseline audit returned
  `blocked_before_inference` (expected exit 2). Seven evidence-file SHA256 values checked.
- Self-review: the real ReasoningEffort schema is a free-form nonempty string,
  not an enum. README corrected to avoid claiming model support from schema fixtures.
  The report's empty enum list stays unchanged and does not claim absent model support.
- Final review: self-review; no other agents were messaged, respecting the handoff.
  No critical/important defects found in the diagnostic scope; no deferred minors.
- Ruling: stop before pilots if the native public route fails the compatibility gate,
  as explicitly required by PLAN.md; do not substitute a Codex agent for FinBot.
  The consequence is an unfinished experimental series, explicitly reported as such.
- Direct OAuth is a documented alternative requiring a separately registered client
  and interactive user sign-in. Existing CLI ChatGPT login does not establish that grant.
- Parameter discrepancy: current GPT-6 documentation requires temperature to be omitted
  for Medium/High. Requested zero cannot be reported as effective zero.
- Task 2: RED — four additional tests fail because the direct-plan-route checker is absent.
- Further route exploration: the official plan-usage preview limitations explicitly exclude
  max_output_tokens and temperature, and require system-role and tool grouping changes.
  Therefore a new OAuth grant alone would not satisfy the agreed 5000-token protocol.
  No interactive sign-in or inference is necessary to establish those documented limits.
- Ruling clarification: the native failure does not establish that every route fails.
  The second documented route was independently checked; it also cannot preserve the
  agreed request unchanged. Stop applies to the experimental series, not to exploration.
- Task 2: GREEN — the full diagnostic suite passes 14/14 through RTK. The actual
  v2 receipt contains both native schema evidence and the documentation-based direct
  OAuth assessment; both routes fail the required unchanged-request conditions.
- The v1 receipt and its 10-test verification remain historical, untouched. The v2
  receipt binds the current preflight source by SHA256. No experiment transport,
  controller, OAuth login flow or model requests were implemented or run after this gate.
- Final review: diagnostic code and evidence checked against PLAN.md. The required
  stop is supported independently for both routes; no deferred code-review findings.
- Remaining: supported route/authentication and explicit parameter mapping; offline 297
  integration replay; fault tests for the actual adapter; smoke; paired pilots; forecast;
  model setting selection; main 297 and final comparison. None are claimed complete.
