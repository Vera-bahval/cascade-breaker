"""Audit the installed Codex protocol without submitting model requests.

This command records necessary compatibility checks, not an inference permit.
An experimental or internal history field is never used to bypass the public API.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


SCHEMAS = {
    "start": "ThreadStartParams.json",
    "turn": "TurnStartParams.json",
    "resume": "ThreadResumeParams.json",
    "config": "ConfigReadResponse.json",
}
DATA_HASHES = {
    "v6_honest_scenarios.json": "b3467b507001b155df0c899542aff857f1f7a661628de4313d7327c863031f5c",
    "vera7_scenarios.json": "2adbdfa18c2a513c9532dfd6b4ed6d65a3719f9f9e013a0dccb8257261a86b7b",
    "our_scenarios.json": "07bac1c3a4809121808461be4b30fc0d4adcc221c3391679f43d76650fe85ef2",
}
PUBLIC_HISTORY_WARNINGS = ("do not use", "internal use only", "for codex cloud", "unstable")
PLAN_USAGE_UNSUPPORTED_FIELDS = {
    "background", "conversation", "max_output_tokens", "max_tool_calls", "metadata",
    "moderation", "multi_agent", "prompt", "prompt_cache_retention", "safety_identifier",
    "temperature", "top_logprobs", "top_p", "truncation", "user",
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def inspect_route(schemas):
    """Inspect necessary public fields; never claim runtime equivalence from a schema."""
    start = schemas["start"]["properties"]
    turn = schemas["turn"]["properties"]
    resume = schemas["resume"]["properties"]
    config = schemas["config"]["definitions"]["Config"]["properties"]
    definitions = schemas["turn"].get("definitions", {})
    user_input = definitions.get("UserInput")
    if not isinstance(user_input, dict) or not isinstance(user_input.get("oneOf"), list):
        raise ValueError("Unsupported or missing UserInput definition")
    input_types = sorted({
        name for variant in user_input["oneOf"]
        for name in variant.get("properties", {}).get("type", {}).get("enum", [])
    })
    history = resume.get("history")
    description = history.get("description", "") if isinstance(history, dict) else ""
    # Поле без описания не считается документированным публичным контрактом.
    public_history = bool(history and description) and not any(
        warning in description.lower() for warning in PUBLIC_HISTORY_WARNINGS
    )
    output_limit = any(
        name in fields for fields in (start, turn, config)
        for name in ("max_output_tokens", "maxOutputTokens", "model_max_output_tokens")
    )
    temperature = any("temperature" in fields for fields in (start, turn, config))
    blockers = []
    if not public_history:
        blockers.append("raw_history_not_public")
    if not output_limit:
        blockers.append("output_limit_not_established")
    if not temperature:
        blockers.append("temperature_not_established")
    return {
        "status": "blocked_before_inference" if blockers else "runtime_verification_required",
        "inference_authorized_by_audit": False,
        "blockers": blockers,
        "user_input_types": input_types,
        "history_description": description,
        "raw_history_public": public_history,
        "base_instructions_field": "baseInstructions" in start,
        "dynamic_tools_field": "dynamicTools" in start,
        "output_limit_public_field": output_limit,
        "temperature_public_field": temperature,
        "reasoning_efforts_in_schema": sorted(definitions.get("ReasoningEffort", {}).get("enum", [])),
        "effective_model": None,
        "effective_reasoning": None,
        "scope_of_conclusion": "Public app-server schema only; config extensions are not a runtime proof.",
    }


def inspect_plan_usage(body):
    """Apply documented preview constraints without rewriting the original request.

    Source checked 2026-10-25:
    https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations
    This is a documentation-based audit, not a live endpoint test.
    """
    unsupported = sorted(PLAN_USAGE_UNSUPPORTED_FIELDS.intersection(body))
    items = body.get("input", [])
    if not isinstance(items, list):
        raise ValueError("Plan usage requires input as a list")
    blockers = ["unsupported_requested_field:" + name for name in unsupported]
    if any(item.get("role") == "system" for item in items):
        blockers.append("system_role_mapping_required")
    if any(tool.get("type") in ("function", "custom") for tool in body.get("tools", [])):
        blockers.append("tool_grouping_required")
    return {
        "status": "blocked_before_inference" if blockers else "runtime_verification_required",
        "inference_authorized_by_audit": False,
        "evidence_type": "official_documentation_not_live_inference",
        "source": "https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations",
        "checked_on": "2026-10-25",
        "unsupported_requested_fields": unsupported,
        "blockers": blockers,
        "required_wire_settings": {"store": False, "stream": True},
        "existing_cli_login_establishes_direct_oauth_grant": False,
    }


def request_shape(body):
    items = body.get("input")
    if not isinstance(items, list) or not all(isinstance(item, dict) for item in items):
        raise ValueError("FinBot input must be an unflattened list of message and tool items")
    return {
        "top_level_keys": sorted(body),
        "roles": list(dict.fromkeys(item["role"] for item in items if "role" in item)),
        "item_types": [item.get("type", "message") for item in items],
        "function_call_ids": [item["call_id"] for item in items if item.get("type") == "function_call"],
        "function_output_ids": [item["call_id"] for item in items if item.get("type") == "function_call_output"],
        "tool_count": len(body.get("tools", [])),
        "max_output_tokens": body.get("max_output_tokens"),
        "temperature": body.get("temperature"),
    }


def baseline_evidence(baseline):
    """Read the frozen matrix and one real SDK request; never import FinBot."""
    paid = baseline / "results" / "paid"
    manifest_path = paid / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    matrix = manifest["matrix"]
    if Counter(job["dataset"] for job in matrix) != {"fpr": 150, "funnel": 77, "vera7": 70}:
        raise ValueError("Unexpected baseline matrix datasets")
    if [sum(job["batch"] == n for job in matrix) for n in range(1, 6)] != [62, 59, 59, 59, 58]:
        raise ValueError("Unexpected baseline batch sizes")
    if len({job["episode"] for job in matrix}) != 297:
        raise ValueError("Duplicate or missing baseline episodes")
    actual_hashes = {name: sha256(baseline.parent / "code" / "finbot477" / name) for name in DATA_HASHES}
    if actual_hashes != DATA_HASHES:
        raise ValueError("Baseline scenario hashes differ from handoff")
    job = next(job for job in matrix if job["dataset"] == "fpr" and job["scenario"]["id"] == "TH601")
    journal = paid / "main" / "episodes" / job["episode"] / "calls.jsonl.gz"
    sample = None
    with gzip.open(journal, "rt") as stream:
        for line in stream:
            event = json.loads(line)
            if event.get("event") != "request":
                continue
            body = event["sdk_request"]
            if isinstance(body, str):
                body = json.loads(body)
            shape = request_shape(body)
            if shape["function_call_ids"] and shape["function_output_ids"]:
                sample = body
                provenance = {
                    "journal": str(journal), "journal_sha256": sha256(journal),
                    "attempt_id": event["attempt_id"], "agent": event.get("agent"),
                    "shape": shape,
                }
                break
    if sample is None:
        raise ValueError("No real tool-history request found in frozen TH601 journal")
    return manifest, sample, {
        "manifest": str(manifest_path), "manifest_sha256": sha256(manifest_path),
        "scenario_hashes": actual_hashes, "sdk_request_provenance": provenance,
    }


def cli_identity(codex):
    """Only invoke documented diagnostic commands; discard credential-related output."""
    version = subprocess.run([codex, "--version"], check=True, capture_output=True, text=True, timeout=30)
    login = subprocess.run([codex, "login", "status"], capture_output=True, text=True, timeout=30)
    # Сохраняем только способ входа, без сырого вывода авторизации.
    chatgpt = login.returncode == 0 and "Logged in using ChatGPT" in login.stdout + login.stderr
    return {"version": version.stdout.strip(), "login_status_exit_code": login.returncode,
            "chatgpt_login_confirmed": chatgpt, "plan_usage_direct_scope": None,
            "scope_note": "CLI login does not establish a separately registered plan-usage client."}


def collect(schema_dir, baseline, output, codex):
    if output.exists():
        raise FileExistsError("Preserve the previous receipt; choose a fresh output directory")
    schemas = {key: json.loads((schema_dir / "v2" / name).read_text()) for key, name in SCHEMAS.items()}
    route = inspect_route(schemas)
    manifest, sample, baseline_info = baseline_evidence(baseline)
    direct_route = inspect_plan_usage(sample)
    identity = cli_identity(codex)
    output.mkdir(parents=True)
    (output / "schemas").mkdir()
    for name in SCHEMAS.values():
        shutil.copyfile(schema_dir / "v2" / name, output / "schemas" / name)
    write_json(output / "finbot-sdk-request.reference.json", sample)
    write_json(output / "matrix.reference.json", manifest["matrix"])
    write_json(output / "requested-series.json", {
        "status": "not_frozen_not_started", "model": "gpt-6-luna",
        "roles": ["executor", "defender"], "pilot_efforts": ["medium", "high"],
        "selected_effort": None, "temperature_requested": 0, "max_output_tokens_requested": 5000,
        "request_timeout_s": 60, "episode_timeout_s": 1800, "main_concurrency": 4,
        "baseline_main_usd": 4.403506026, "main_api_equivalent_limit_usd": 5.30,
        "forecast_reserve_multiplier": 1.25, "pilot_episodes_per_effort": 8,
        "main_episodes": 297, "checkpoints": [62, 121, 180, 239, 297],
        "matrix_file": "matrix.reference.json", "matrix_source": baseline_info,
        "financial_ledger_reused": False, "cache_reused": False,
    })
    report = {
        "collected_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": route["status"], "route": "installed_codex_app_server_public_protocol",
        "cli": identity, "compatibility": route, "baseline": baseline_info,
        "direct_oauth_plan_usage_compatibility": direct_route,
        "preflight_script_sha256": sha256(__file__),
        "model_requests_submitted_by_preflight": 0,
        "smoke": "not_started", "pilots": "not_started", "main": "not_started",
        "offline_297_integration_replay": "not_run_route_gate_failed",
        "actual_inference_cost_usd": None, "subscription_inference_usage": None,
        "limitations": [
            "Static schema checks cannot establish the actual model, entitlement, effective prompt or tool set.",
            "Missing parameter fields establish no supported mapping; arbitrary config overrides are unverified.",
            "A user-text serialization changes message roles and is not an equivalent FinBot request.",
            "Direct OAuth needs a separate grant but does not support the requested max_output_tokens limit either.",
            "Official GPT-6 guidance requires omitting temperature for medium/high; temperature=0 cannot be claimed effective.",
        ],
        "official_sources": [
            "https://learn.chatgpt.com/docs/app-server",
            "https://developers.openai.com/siwc/token-sharing-open-source/sign-in",
            "https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference",
            "https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations",
            "https://developers.openai.com/api/docs/guides/latest-model",
        ],
    }
    report["files_sha256"] = {
        str(path.relative_to(output)): sha256(path) for path in sorted(output.rglob("*")) if path.is_file()
    }
    write_json(output / "report.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schema-dir", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--codex", default="/opt/homebrew/bin/codex")
    args = parser.parse_args()
    report = collect(args.schema_dir.resolve(), args.baseline.resolve(), args.output.resolve(), args.codex)
    print(json.dumps({"status": report["status"], "report": str(args.output / "report.json"),
                      "blockers": report["compatibility"]["blockers"], "model_requests_submitted": 0}))
    # Этот диагностический шаг никогда не выдает разрешение на генерации.
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
