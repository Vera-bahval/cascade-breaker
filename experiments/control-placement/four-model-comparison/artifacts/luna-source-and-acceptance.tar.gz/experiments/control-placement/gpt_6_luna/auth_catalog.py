"""Approved RAM-auth helper entry point for the explicit recovery supervisor."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'verification'))
from resumption import main

if __name__=='__main__':main()
