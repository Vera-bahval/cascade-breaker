"""Official ChatGPT plan-usage OAuth; credentials remain in this process's RAM.

The local broker transfers only short-lived access tokens to experiment workers.
It never reads Codex credentials and never proxies provider inference traffic.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import secrets
import socket
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import parse_qs, urlencode, urlsplit
import uuid

import httpx
import jwt


HERE = Path(__file__).resolve().parent
ISSUER = "https://auth.openai.com"
RESOURCE = "https://api.openai.com/v1"
AUTHORIZE = ISSUER + "/api/accounts/authorize"
TOKEN_ENDPOINT = ISSUER + "/api/accounts/oauth/token"
JWKS = ISSUER + "/.well-known/jwks.json"
SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"


class AuthError(Exception):
    """Messages contain diagnostic codes only, never response bodies or credentials."""


def new_attempt(redirect_uri, host_id, client_id=None):
    verifier = secrets.token_urlsafe(64)
    state, nonce = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    params = dict(client_id=client_id or "dynamic_agent_client", ext_agent_host_id=host_id,
                  response_type="code", redirect_uri=redirect_uri, scope=SCOPES, resource=RESOURCE,
                  state=state, nonce=nonce, code_challenge_method="S256", code_challenge=challenge)
    if not client_id:
        params["agent_name_hint"] = "FinBot Luna Experiment"
    return {"url": AUTHORIZE + "?" + urlencode(params), "verifier": verifier, "state": state,
            "nonce": nonce, "redirect_uri": redirect_uri, "client_id": client_id}


def check_callback(query, attempt):
    if any(len(values) != 1 for values in query.values()):
        raise AuthError("ambiguous_callback")
    if not hmac.compare_digest(query.get("state", [""])[0], attempt["state"]):
        raise AuthError("invalid_state")
    if "error" in query:
        raise AuthError("authorization_denied")
    code = query.get("code", [""])[0]
    client_id = query.get("client_id", [attempt.get("client_id") or ""])[0]
    if not code or not client_id or client_id == "dynamic_agent_client":
        raise AuthError("incomplete_registration")
    if attempt.get("client_id") and client_id != attempt["client_id"]:
        raise AuthError("client_identity_changed")
    return code, client_id


def verify_identity(token, key, client_id, nonce=None):
    try:
        claims = jwt.decode(token, key, algorithms=["RS256", "ES256"], audience=client_id,
                            issuer=ISSUER, leeway=5, options={"require": ["sub", "exp", "iat", "iss", "aud"]})
        if not isinstance(claims["sub"], str) or not claims["sub"]:
            raise AuthError("missing_subject")
        if nonce is not None and not hmac.compare_digest(str(claims.get("nonce", "")), nonce):
            raise AuthError("invalid_nonce")
        return claims["sub"]
    except jwt.PyJWTError:
        raise AuthError("invalid_id_token") from None


def check_token_fields(value):
    if not isinstance(value, dict) or not isinstance(value.get("access_token"), str) or not value["access_token"]:
        raise AuthError("missing_access_token")
    if str(value.get("token_type", "")).lower() != "bearer":
        raise AuthError("unsupported_token_type")
    if type(value.get("expires_in")) is not int or value["expires_in"] <= 120:
        raise AuthError("invalid_token_expiry")
    scope = value.get("scope")
    if not isinstance(scope, str) or not {"chatgpt.tokens.use.direct", "resource.invoke"} <= set(scope.split()):
        raise AuthError("plan_usage_scope_missing")


def public_json(path, value):
    def contains_credentials(item):
        if isinstance(item, dict):
            forbidden = {"access_token", "refresh_token", "id_token", "code_verifier", "capability", "client_secret"}
            return bool(forbidden.intersection(item)) or any(contains_credentials(v) for v in item.values())
        if isinstance(item, list):
            return any(contains_credentials(v) for v in item)
        return False
    if contains_credentials(value):
        raise AuthError("credentials_in_public_metadata")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    descriptor = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(path)


class TokenSession:
    def __init__(self, value, client_id, subject, public_keys):
        check_token_fields(value)
        self.value, self.client_id, self.subject = value, client_id, subject
        self.public_keys = public_keys
        self.expires = time.time() + value["expires_in"]
        self.lock = threading.Lock()

    def key(self, token):
        try:
            kid = jwt.get_unverified_header(token)["kid"]
            return next(key.key for key in self.public_keys.keys if key.key_id == kid)
        except (KeyError, StopIteration, jwt.PyJWTError):
            raise AuthError("unknown_signing_key") from None

    def access_token(self):
        with self.lock:
            if self.expires - time.time() > 120:
                return self.value["access_token"]
            earliest = self.value.get("earliest_refresh_at")
            if earliest is not None:
                if not isinstance(earliest, (int, float)) or isinstance(earliest, bool):
                    raise AuthError("unsupported_earliest_refresh_at")
                if time.time() < earliest:
                    raise AuthError("refresh_not_yet_allowed")
            if not self.value.get("refresh_token"):
                raise AuthError("refresh_token_unavailable")
            refreshed = token_request(dict(grant_type="refresh_token", client_id=self.client_id,
                                          refresh_token=self.value["refresh_token"], resource=RESOURCE))
            check_token_fields(refreshed)
            if refreshed.get("id_token"):
                subject = verify_identity(refreshed["id_token"], self.key(refreshed["id_token"]), self.client_id)
                if subject != self.subject:
                    raise AuthError("refreshed_identity_changed")
            if not refreshed.get("refresh_token"):
                raise AuthError("replacement_refresh_token_missing")
            self.value = refreshed
            self.expires = time.time() + refreshed["expires_in"]
            return refreshed["access_token"]


def token_request(data):
    try:
        response = httpx.post(TOKEN_ENDPOINT, data=data, timeout=30, follow_redirects=False)
        if response.status_code != 200:
            raise AuthError("token_endpoint_http_" + str(response.status_code))
        return response.json()
    except (httpx.HTTPError, ValueError):
        raise AuthError("token_exchange_failed") from None


def authorize(registration_path):
    saved = json.loads(registration_path.read_text()) if registration_path.exists() else {
        "host_id": "urn:uuid:" + str(uuid.uuid4())}
    public_json(registration_path, saved)
    try:
        discovery = httpx.get(ISSUER + "/.well-known/openid-configuration", timeout=20).json()
        expected = {"issuer": ISSUER, "authorization_endpoint": AUTHORIZE,
                    "token_endpoint": TOKEN_ENDPOINT, "jwks_uri": JWKS}
        if any(discovery.get(key) != value for key, value in expected.items()):
            raise AuthError("discovery_endpoint_changed")
        response = httpx.get(JWKS, timeout=20)
        response.raise_for_status()
        keys = jwt.PyJWKSet.from_dict(response.json())
    except (httpx.HTTPError, ValueError, jwt.PyJWTError):
        raise AuthError("discovery_or_keys_unavailable") from None
    result, attempt = {}, {}

    class Callback(BaseHTTPRequestHandler):
        def do_GET(self):
            parts = urlsplit(self.path)
            if parts.path == "/":
                payload = ('<!doctype html><meta charset="utf-8"><title>FinBot Luna Experiment</title>'
                           '<h1>FinBot Luna Experiment</h1><p>Используйте тот же аккаунт, что в Codex.</p>'
                           '<p>Токены сохраняются только в памяти этого процесса.</p>'
                           '<a href="' + attempt["url"].replace("&", "&amp;") + '">Continue with ChatGPT</a>').encode()
                self.send_response(200)
            elif parts.path == "/auth/callback" and not result:
                query = parse_qs(parts.query, keep_blank_values=True)
                try:
                    result["callback"] = check_callback(query, attempt)
                    payload = b"Authorization received. You may return to Codex."
                    self.send_response(200)
                except AuthError as error:
                    states = query.get("state", [])
                    if len(states) == 1 and hmac.compare_digest(states[0], attempt["state"]):
                        result["error"] = str(error)
                    payload = b"Authorization callback rejected."
                    self.send_response(400)
            else:
                self.send_error(404)
                return
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), Callback)
    server.timeout = 1
    local_url = "http://127.0.0.1:" + str(server.server_port) + "/"
    attempt.update(new_attempt(local_url + "auth/callback", saved["host_id"], saved.get("client_id")))
    print(json.dumps({"status": "awaiting_user_sign_in", "local_ui": local_url,
                      "app_name": "FinBot Luna Experiment", "inference_requests": 0}), flush=True)
    expires = time.monotonic() + 600
    try:
        while not result and time.monotonic() < expires:
            server.handle_request()
    finally:
        server.server_close()
    if "callback" not in result:
        raise AuthError(result.get("error", "authorization_timeout"))
    code, client_id = result["callback"]
    value = token_request(dict(grant_type="authorization_code", client_id=client_id, code=code,
                               code_verifier=attempt["verifier"], redirect_uri=attempt["redirect_uri"], resource=RESOURCE))
    check_token_fields(value)
    if not value.get("id_token"):
        raise AuthError("id_token_missing")
    session = TokenSession(value, client_id, "", keys)
    session.subject = verify_identity(value["id_token"], session.key(value["id_token"]), client_id, attempt["nonce"])
    subject_hash = hashlib.sha256(session.subject.encode()).hexdigest()
    if saved.get("subject_sha256") and saved["subject_sha256"] != subject_hash:
        raise AuthError("selected_account_changed")
    public_json(registration_path, {"host_id": saved["host_id"], "client_id": client_id,
                                    "subject_sha256": subject_hash})
    return session


class Broker:
    def __init__(self, session):
        self.directory = Path(tempfile.mkdtemp(prefix="finbot-luna-auth-", dir="/private/tmp"))
        self.address = str(self.directory / "token.sock")
        self.capability = secrets.token_hex(32)
        capability = self.capability

        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                self.connection.settimeout(35)
                try:
                    request = json.loads(self.rfile.readline(4096))
                    if not hmac.compare_digest(str(request.get("capability", "")), capability):
                        raise AuthError("invalid_broker_capability")
                    value = {"access_token": session.access_token(), "expires_at": session.expires}
                except Exception:
                    value = {"error": "broker_credentials_unavailable"}
                self.wfile.write(json.dumps(value).encode() + b"\n")

        self.server = socketserver.ThreadingUnixStreamServer(self.address, Handler)
        self.server.daemon_threads = True
        os.chmod(self.address, 0o600)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def environment(self):
        return {"LUNA_AUTH_SOCKET": self.address, "LUNA_AUTH_CAPABILITY": self.capability}

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        Path(self.address).unlink()
        self.directory.rmdir()


def worker_token():
    address, capability = os.environ.get("LUNA_AUTH_SOCKET"), os.environ.get("LUNA_AUTH_CAPABILITY")
    if not address or not capability:
        raise AuthError("oauth_broker_not_configured")
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
            connection.settimeout(40)
            connection.connect(address)
            connection.sendall(json.dumps({"capability": capability}).encode() + b"\n")
            with connection.makefile("rb") as stream:
                value = json.loads(stream.readline(65536))
        if not isinstance(value.get("access_token"), str) or not value["access_token"]:
            raise AuthError("broker_credentials_unavailable")
        return value["access_token"]
    except (OSError, ValueError):
        raise AuthError("broker_connection_failed") from None


def catalog(session, output):
    try:
        response = httpx.get(RESOURCE + "/models", headers={"Authorization": "Bearer " + session.access_token()},
                             timeout=30, follow_redirects=False)
        if response.status_code != 200:
            raise AuthError("catalog_http_" + str(response.status_code))
        value = response.json()
        if not isinstance(value.get("models"), list):
            raise AuthError("unexpected_plan_catalog")
        slugs = [model["slug"] for model in value["models"] if model.get("visibility") == "list"]
        receipt = {"auth_route": "official_direct_oauth_plan_usage", "identity_verified": True,
                   "granted_scopes": session.value["scope"].split(), "catalog_model_slugs": slugs,
                   "luna_listed": "gpt-6-luna" in slugs, "inference_requests": 0,
                   "credentials_persisted": False, "model_entitlement_proven_by_inference": False}
        public_json(output, receipt)
        return receipt
    except (httpx.HTTPError, ValueError, KeyError):
        raise AuthError("catalog_failed") from None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registration", type=Path, default=HERE / ".runtime/auth-registration.public.json")
    parser.add_argument("--catalog-output", type=Path, default=HERE / ".runtime/auth-catalog.json")
    args = parser.parse_args()
    session = authorize(args.registration)
    receipt = catalog(session, args.catalog_output)
    print(json.dumps({"status": "oauth_verified", "luna_listed": receipt["luna_listed"],
                      "credentials_in_ram_only": True, "inference_requests": 0}), flush=True)
    broker = Broker(session)
    try:
        for line in sys.stdin:
            command = json.loads(line)
            if command.get("action") == "close":
                break
            argv = command.get("argv", [])
            allowed = {HERE / "experiment.py", HERE / "auth_catalog.py"}
            if command.get("action") != "run" or len(argv) < 2 or Path(argv[0]).resolve() != Path(sys.executable).resolve() or Path(argv[1]).resolve() not in allowed:
                print(json.dumps({"status": "command_rejected"}), flush=True)
                continue
            result = subprocess.run(argv, env=os.environ.copy() | broker.environment())
            print(json.dumps({"status": "command_finished", "exit_code": result.returncode}), flush=True)
    finally:
        broker.close()


if __name__ == "__main__":
    try:
        main()
    except AuthError as error:
        print(json.dumps({"status": "auth_stopped", "reason": str(error), "inference_requests": 0}), flush=True)
        raise SystemExit(2)
