import importlib.util
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE/'export.py').is_file(),'Missing offline exporter')
        spec=importlib.util.spec_from_file_location('luna_export',HERE/'export.py')
        self.e=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.e)

    # Счетчики не удваивают reasoning; requested и effective сохраняются отдельно.
    def test_request_preserves_effective_and_requested_parameters(self):
        row={'attempt_id':'one','phase':'main','role':'executor','effort':'high','latency_s':2,
             'native_response':{'id':'resp1','model':'gpt-6-luna','temperature':1.,'max_output_tokens':None,
                 'reasoning':{'effort':'high'},'usage':{'input_tokens':100,'output_tokens':50,
                 'output_tokens_details':{'reasoning_tokens':40}}},
             'estimate':{'upper_usd':.000035,'lower_usd':.000035,'unavailable':[]}}
        intent={'sdk_request':{'temperature':0,'max_output_tokens':5000},'mapping':{'protocol':2}}
        result=self.e.request_row(row,intent,Path('/local/calls.gz'))
        self.assertEqual(result['output_tokens'],50)
        self.assertEqual(result['reasoning_tokens'],40)
        self.assertEqual(result['requested_temperature'],0)
        self.assertEqual(result['effective_temperature'],1.)
        self.assertIsNone(result['effective_max_output_tokens'])

    # Один attempt нельзя оплатить дважды из-за повторной ссылки в другом эпизоде.
    def test_duplicate_request_ids_are_rejected(self):
        with self.assertRaises(ValueError):self.e.unique_requests([{'attempt_id':'one'},{'attempt_id':'one'}])

    # Разница общих процентов подписки не объявляется токенами или расходом серии.
    def test_quota_summary_keeps_shared_attribution(self):
        result=self.e.quota_observations([{'observed_at':'a','buckets':{'codex':{'primary':{'usedPercent':8}}}},
                                          {'observed_at':'b','buckets':{'codex':{'primary':{'usedPercent':9}}}}])
        self.assertIsNone(result['experiment_exclusive_usage'])
        self.assertEqual(len(result['observations']),2)


if __name__=='__main__':unittest.main()
