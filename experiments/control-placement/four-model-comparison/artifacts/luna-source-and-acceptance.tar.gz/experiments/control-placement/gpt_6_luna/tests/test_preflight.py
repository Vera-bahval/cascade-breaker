"""Offline tests for the subscription-route compatibility audit."""

import importlib.util
from pathlib import Path
import unittest


HERE = Path(__file__).resolve().parents[1]


class RouteAuditTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "preflight.py").is_file(), "Missing Luna preflight")
        spec = importlib.util.spec_from_file_location("luna_preflight", HERE / "preflight.py")
        self.audit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.audit)

    def fixture(self):
        return {
            "start": {"properties": {"baseInstructions": {}, "dynamicTools": {}}},
            "turn": {
                "properties": {"input": {}, "effort": {}, "outputSchema": {}},
                "definitions": {
                    "UserInput": {"oneOf": [
                        {"properties": {"type": {"enum": ["text"]}, "text": {}}},
                        {"properties": {"type": {"enum": ["image"]}}},
                    ]},
                    "ReasoningEffort": {"enum": ["low", "medium", "high"]},
                },
            },
            "resume": {"properties": {"history": {
                "description": "[UNSTABLE] FOR CODEX CLOUD - DO NOT USE.",
                "items": {"$ref": "#/definitions/ResponseItem"},
            }}},
            "config": {"definitions": {"Config": {"properties": {
                "model_context_window": {}, "model_reasoning_effort": {},
            }}}},
        }

    # Историю с настоящими ролями нельзя заменять одним текстовым вводом.
    def test_user_text_does_not_support_stateless_finbot_history(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertEqual(result["user_input_types"], ["image", "text"])
        self.assertFalse(result["raw_history_public"])
        self.assertEqual(result["status"], "blocked_before_inference")

    # Наличие внутреннего поля не делает его поддержанным интерфейсом.
    def test_cloud_only_history_is_not_an_authorized_route(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertIn("DO NOT USE", result["history_description"])
        self.assertIn("raw_history_not_public", result["blockers"])

    # Dynamic tools и базовая инструкция не доказывают эквивалентность запроса.
    def test_dynamic_tools_do_not_clear_history_blocker(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertTrue(result["dynamic_tools_field"])
        self.assertTrue(result["base_instructions_field"])
        self.assertIn("raw_history_not_public", result["blockers"])

    # Лимит контекста не подменяет лимит генерации.
    def test_context_window_does_not_prove_output_limit(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertFalse(result["output_limit_public_field"])
        self.assertIn("output_limit_not_established", result["blockers"])

    # Поддержка enum не выдается за проверенный runtime модели.
    def test_effort_enum_is_static_evidence_only(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertEqual(result["reasoning_efforts_in_schema"], ["high", "low", "medium"])
        self.assertIsNone(result["effective_model"])
        self.assertIsNone(result["effective_reasoning"])

    # Неизвестная схема останавливает проверку, а не превращается в допуск.
    def test_missing_user_input_definition_is_rejected(self):
        data = self.fixture()
        del data["turn"]["definitions"]["UserInput"]
        with self.assertRaisesRegex(ValueError, "UserInput"):
            self.audit.inspect_route(data)

    # Публичная история сама по себе не заменяет runtime-доказательство.
    def test_public_history_still_requires_runtime_proof(self):
        data = self.fixture()
        data["resume"]["properties"]["history"]["description"] = "Public history import."
        data["turn"]["properties"]["maxOutputTokens"] = {"type": "integer"}
        data["turn"]["properties"]["temperature"] = {"type": "number"}
        result = self.audit.inspect_route(data)
        self.assertEqual(result["status"], "runtime_verification_required")
        self.assertFalse(result["inference_authorized_by_audit"])

    # Отсутствующие поля параметров остаются неизвестными, а не значениями default.
    def test_unavailable_parameters_are_explicit(self):
        result = self.audit.inspect_route(self.fixture())
        self.assertFalse(result["temperature_public_field"])
        self.assertIn("temperature_not_established", result["blockers"])

    # Сводка запроса сохраняет типы сообщений и связи инструментов.
    def test_request_summary_retains_roles_and_call_ids(self):
        body = {"input": [
            {"role": "system", "content": "original instructions"},
            {"role": "user", "content": "invoice"},
            {"type": "function_call", "call_id": "call_1", "name": "read_invoice", "arguments": "{}"},
            {"type": "function_call_output", "call_id": "call_1", "output": "{}"},
        ], "tools": [{"name": "read_invoice"}], "max_output_tokens": 5000, "temperature": 0}
        result = self.audit.request_shape(body)
        self.assertEqual(result["roles"], ["system", "user"])
        self.assertEqual(result["function_call_ids"], ["call_1"])
        self.assertEqual(result["function_output_ids"], ["call_1"])
        self.assertEqual(result["max_output_tokens"], 5000)
        self.assertEqual(result["temperature"], 0)

    # Строковый input не принимается за исходную историю FinBot.
    def test_flattened_request_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "list"):
            self.audit.request_shape({"input": "flattened history"})

    # Новый OAuth grant не снимает ограничение endpoint на max_output_tokens.
    def test_direct_plan_route_cannot_preserve_output_limit(self):
        self.assertTrue(hasattr(self.audit, "inspect_plan_usage"), "Missing direct-route audit")
        result = self.audit.inspect_plan_usage({"input": [], "max_output_tokens": 5000})
        self.assertIn("max_output_tokens", result["unsupported_requested_fields"])
        self.assertEqual(result["status"], "blocked_before_inference")

    # System role и плоские tools требуют отдельного изменения протокола.
    def test_direct_route_records_message_and_tool_remapping(self):
        self.assertTrue(hasattr(self.audit, "inspect_plan_usage"), "Missing direct-route audit")
        result = self.audit.inspect_plan_usage({"input": [{"role": "system", "content": "original"}],
                                               "tools": [{"type": "function", "name": "read_invoice"}]})
        self.assertIn("system_role_mapping_required", result["blockers"])
        self.assertIn("tool_grouping_required", result["blockers"])

    # Удаление исходных параметров не объявляется сохранением их значений.
    def test_direct_route_preserves_unsupported_temperature_evidence(self):
        self.assertTrue(hasattr(self.audit, "inspect_plan_usage"), "Missing direct-route audit")
        body = {"input": [], "temperature": 0, "max_output_tokens": 5000}
        result = self.audit.inspect_plan_usage(body)
        self.assertEqual(body, {"input": [], "temperature": 0, "max_output_tokens": 5000})
        self.assertEqual(result["unsupported_requested_fields"], ["max_output_tokens", "temperature"])

    # Совместимая форма запроса не доказывает фактический доступ к Luna.
    def test_direct_route_compatible_shape_still_needs_runtime_verification(self):
        self.assertTrue(hasattr(self.audit, "inspect_plan_usage"), "Missing direct-route audit")
        result = self.audit.inspect_plan_usage({"input": [{"role": "user", "content": "hello"}],
                                               "stream": True, "store": False})
        self.assertEqual(result["status"], "runtime_verification_required")
        self.assertFalse(result["inference_authorized_by_audit"])


if __name__ == "__main__":
    unittest.main()
