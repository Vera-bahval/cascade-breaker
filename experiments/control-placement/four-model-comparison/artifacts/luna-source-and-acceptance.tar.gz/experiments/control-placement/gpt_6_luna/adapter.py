"""Protocol 2: FinBot SDK requests to the documented subscription Responses route."""

from copy import deepcopy
import json


MODEL = "gpt-6-luna"
NAMESPACE = "finbot_tools"


class ProtocolError(Exception):
    pass


def wire_request(original, effort, *, chat=False):
    if effort not in ("medium", "high"):
        raise ProtocolError("Unfrozen reasoning effort")
    allowed = {"model", "input", "instructions", "temperature", "max_output_tokens", "tools", "tool_choice",
               "parallel_tool_calls", "stream", "store", "reasoning", "text", "include"}
    if chat:
        allowed = {"model", "messages", "temperature", "stream", "max_tokens"}
    if set(original) - allowed:
        raise ProtocolError("Unsupported SDK request option")
    if original.get("store"):
        raise ProtocolError("Persistent provider storage is outside this protocol")
    body = deepcopy(original)
    changes = {"protocol": 2, "system_to_developer_indices": [], "tool_namespace": NAMESPACE,
               "server_output_limit_unavailable": True, "temperature_unavailable": True,
               "source_model": body.pop("model", None),
               "omitted_max_output_tokens": body.pop("max_output_tokens", body.pop("max_tokens", None)),
               "omitted_temperature": body.pop("temperature", None)}
    if chat:
        body["input"] = body.pop("messages")
    if isinstance(body.get("input"), str):
        body["input"] = [{"role": "user", "content": body["input"]}]
    if not isinstance(body.get("input"), list):
        raise ProtocolError("Expected complete input history")
    for index, item in enumerate(body["input"]):
        if not isinstance(item, dict):
            raise ProtocolError("Invalid history item")
        if item.get("role") == "system":
            item["role"] = "developer"
            changes["system_to_developer_indices"].append(index)
        if item.get("type") == "function_call":
            if item.get("namespace") not in (None, NAMESPACE):
                raise ProtocolError("Foreign tool namespace in history")
            item["namespace"] = NAMESPACE
    tools = body.get("tools")
    if tools:
        if not all(tool.get("type") == "function" for tool in tools):
            raise ProtocolError("Only original FinBot functions are supported")
        if len({tool["name"] for tool in tools}) != len(tools):
            raise ProtocolError("Duplicate original tool names")
        body["tools"] = [{"type": "namespace", "name": NAMESPACE, "description": "", "tools": tools}]
    choice = body.get("tool_choice")
    if choice is not None and choice not in ("auto", "none", "required"):
        raise ProtocolError("Unverified tool_choice mapping")
    body.update(model=MODEL, reasoning={"effort": effort}, stream=True, store=False, service_tier="default")
    include = body.setdefault("include", [])
    if "reasoning.encrypted_content" not in include:
        include.append("reasoning.encrypted_content")
    return body, changes


def sdk_response(native):
    response = deepcopy(native)
    for item in response.get("output", []):
        if item.get("type") == "function_call":
            if item.get("namespace") not in (None, NAMESPACE):
                raise ProtocolError("Foreign function call namespace")
            item.pop("namespace", None)
    return response


def sdk_entries(output):
    """Match the pinned FinBot SDK's history serialization exactly."""
    entries = []
    for item in output:
        if item.get("type") == "message":
            entries.append({"role": item["role"], "content": "".join(
                part["text"] for part in item.get("content", [])
                if part.get("type") == "output_text" and part.get("text"))})
        elif item.get("type") == "function_call":
            entries.append({"type": "function_call", "name": item["name"],
                            "call_id": item["call_id"], "arguments": item["arguments"]})
    return entries


def restore_reasoning(items, previous, agent):
    """Retain provider reasoning that the pinned FinBot SDK does not serialize."""
    additions = {}
    for record in previous:
        if record.get("agent") != agent:
            continue
        expected = record["input"] + sdk_entries(record["output"])
        if len(expected) > len(items) or items[:len(expected)] != expected:
            continue
        position = len(record["input"])
        for reasoning in record["output"]:
            if reasoning.get("type") != "reasoning":
                continue
            known = additions.setdefault(position, [])
            if reasoning not in known:
                known.append(reasoning)
    result = []
    for index, item in enumerate(items):
        result.extend(deepcopy(additions.get(index, [])))
        result.append(deepcopy(item))
    return result


def terminal_response(events):
    seen, completed, items = {}, None, {}
    for event in events:
        if not isinstance(event, dict) or not isinstance(event.get("type"), str):
            raise ProtocolError("Invalid streaming event")
        sequence = event.get("sequence_number")
        if sequence is not None:
            serialized = json.dumps(event, sort_keys=True)
            if sequence in seen:
                if seen[sequence] != serialized:
                    raise ProtocolError("Conflicting duplicate streaming event")
                continue
            seen[sequence] = serialized
        kind = event["type"]
        if kind == 'response.output_item.done':
            index, item = event.get('output_index'), event.get('item')
            if type(index) is not int or index < 0 or not isinstance(item,dict):
                raise ProtocolError('Invalid completed output item')
            if index in items and items[index] != item:
                raise ProtocolError('Conflicting completed output item')
            items[index] = item
        if "rerout" in kind or "compact" in kind:
            raise ProtocolError("Unapproved provider rerouting or compaction")
        if kind in ("response.failed", "response.incomplete", "error"):
            raise ProtocolError("Unsuccessful terminal event: " + kind)
        if kind == "response.completed":
            response = event.get("response")
            if not isinstance(response, dict) or response.get("status") != "completed":
                raise ProtocolError("Invalid completed response")
            if completed is not None and completed != response:
                raise ProtocolError("Multiple completed responses in one request")
            completed = response
    if completed is None:
        raise ProtocolError("Stream ended without response.completed")
    if items:
        if sorted(items) != list(range(len(items))):raise ProtocolError('Missing completed output index')
        ordered = [items[index] for index in sorted(items)]
        if completed.get('output') and completed['output'] != ordered:
            raise ProtocolError('Terminal output conflicts with completed items')
        completed = deepcopy(completed)
        completed['output'] = deepcopy(ordered)
    return completed


def as_chat(response):
    if any(item.get("type") == "function_call" for item in response.get("output", [])):
        raise ProtocolError("Defender returned an unexpected function call")
    text = "".join(part["text"] for item in response.get("output", []) if item.get("type") == "message"
                   for part in item.get("content", []) if part.get("type") == "output_text")
    usage = response.get("usage") or {}
    return {"id": response["id"], "object": "chat.completion", "created": response.get("created_at", 0),
            "model": response["model"],
            "choices": [{"index": 0, "finish_reason": "stop", "message": {"role": "assistant", "content": text}}],
            "usage": {"prompt_tokens": usage.get("input_tokens"), "completion_tokens": usage.get("output_tokens"),
                      "total_tokens": usage.get("total_tokens"),
                      "prompt_tokens_details": usage.get("input_tokens_details"),
                      "completion_tokens_details": usage.get("output_tokens_details")}}
