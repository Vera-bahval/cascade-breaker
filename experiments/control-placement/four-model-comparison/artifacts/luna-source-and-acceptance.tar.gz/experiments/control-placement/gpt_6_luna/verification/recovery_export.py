"""Read-only final recovery accounting. No model client construction or inference."""
import argparse
from collections import Counter
from contextlib import closing
from datetime import UTC, datetime
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from export import collect, csv_export, paired_comparison, quota_observations, request_row
from support import digest, estimate_usage, read_records, write_json


def reconcile_states(ledger, events, allowed):
    ids = [r['id'] for r in ledger]
    if len(ids) != len(set(ids)) or set(ids) != set(events):
        raise ValueError('Ledger/journal identity or duplicate mismatch')
    unknown = {r['id'] for r in ledger if r['state'] == 'unknown'}
    if unknown != set(allowed) or any(r['state'] not in ('complete', 'unknown') for r in ledger):
        raise ValueError('New unresolved outcome, pending request, or missing original unknown')


def accounting(rows, allowed):
    if len({r['attempt_id'] for r in rows}) != len(rows):
        raise ValueError('Duplicate exported attempt')
    known = [r for r in rows if r['accounting_state'] == 'complete']
    unknown = [r for r in rows if r['accounting_state'] != 'complete']
    spent = sum(r['estimate_upper_usd'] for r in known)
    bound = sum(allowed[r['attempt_id']]['budget_bound_usd'] for r in unknown)
    return dict(attempts=len(rows), complete_requests=len(known), unknown_requests=len(unknown),
                known_api_equivalent_usd=spent, unknown_usage=None if unknown else [],
                total_api_equivalent_usd=None if unknown else spent,
                unknown_planning_bound_usd=bound, planning_upper_including_unknown_usd=spent+bound,
                planning_bound_is_measured_or_guaranteed=False, actual_subscription_charge_usd=None,
                **{name+'_known_sum': sum(r.get(name) or 0 for r in known)
                   for name in ('input_tokens', 'output_tokens', 'reasoning_tokens', 'cached_tokens', 'cache_write_tokens')},
                reasoning_already_in_output=True,
                native_counters_unavailable_requests=len(unknown))


def unknown_row(entry, rows, allowed):
    path, intent = next((p, r) for p, r in rows if r['event'] == 'intent')
    raw = [json.loads(r['raw']) for _, r in rows if r['event'] == 'raw_event']
    if any(r.get('type') in ('response.completed', 'response.failed', 'response.incomplete') for r in raw):
        raise ValueError('Original unknown has terminal event requiring reconciliation')
    created = next((r['response'] for r in raw if r.get('type') == 'response.created'), {})
    stopped = next(r for _, r in rows if r['event'] == 'stopped')
    headers = next((r for _, r in rows if r['event'] == 'headers'), {})
    if entry['reserved'] != allowed['reserved'] or digest(json.loads(entry['context'])) != allowed['context_sha256']:
        raise ValueError('Authorized unknown identity changed')
    row = {k: intent.get(k) for k in ('attempt_id', 'phase', 'episode', 'role', 'effort', 'agent', 'view')}
    row.update(response_id=created.get('id'), model=created.get('model'), response_status='unknown',
               requested_reasoning=intent['effort'], effective_reasoning=None,
               observed_created_reasoning=created.get('reasoning'),
               requested_temperature=intent['sdk_request'].get('temperature'), effective_temperature=None,
               requested_max_output_tokens=intent['sdk_request'].get('max_output_tokens', intent['sdk_request'].get('max_tokens')),
               effective_max_output_tokens=None, output_limit_configurable=False, temperature_configurable=False,
               usage_unavailable=['all native counters: no terminal response'], native_usage=None,
               estimate_lower_usd=None, estimate_upper_usd=None, actual_subscription_charge_usd=None,
               intent_at=intent['at'], response_at=None, stopped_at=stopped['at'],
               latency_s=stopped['at']-intent['at'], error=stopped['reason'],
               http_status=headers.get('http_status'), request_id=headers.get('headers', {}).get('x-request-id'),
               raw_event_types=dict(Counter(r.get('type') for r in raw)), raw_journal=str(path),
               wire_request_sha256=intent['request_sha256'], mapping=intent['mapping'],
               unknown_planning_bound=allowed)
    row.update({k: None for k in ('input_tokens', 'output_tokens', 'reasoning_tokens', 'cached_tokens', 'cache_write_tokens')})
    return row


def database_check(folder, episode):
    snapshot = json.loads((folder/'database.json').read_text())
    with tempfile.TemporaryDirectory() as work:
        dest = Path(work)/'business.sqlite'
        dest.write_bytes(gzip.decompress((folder/'snapshot.sqlite.gz').read_bytes()))
        with closing(sqlite3.connect(dest)) as db:
            if db.execute('pragma integrity_check').fetchone()[0] != 'ok':
                raise ValueError('Business SQLite integrity')
            db.row_factory = sqlite3.Row
            actual = {name: [dict(r) for r in db.execute('select * from "'+name+'"')] for name in snapshot}
            if actual != snapshot or len(actual['invoices']) != 6:
                raise ValueError('Business snapshot mismatch')
    payments = episode['payment_transactions']
    if len({p['id'] for p in payments}) != len(payments):
        raise ValueError('Duplicate payment identity')
    counts = Counter(p['invoice_id'] for p in payments if p.get('status') == 'completed')
    if max(counts.values(), default=0) > 1:
        raise ValueError('Duplicate completed business payment')


def export_recovery(root, output):
    # Импорты не запускают FinBot; configure сверяет исходный core и отдельную надстройку.
    from resumption import configure, AuthorizedLedger
    experiment, policy = configure(root)
    state = AuthorizedLedger(root/'budget.db').state()
    if state['pending'] or state['unresolved'] or (root/'halt.json').exists():
        raise ValueError('Final export requires idle accepted recovery')
    checkpoint = json.loads((root/'checkpoint-5.json').read_text())
    manifest = json.loads((root/'manifest.json').read_text())
    if checkpoint['episodes'] != 297 or checkpoint['forecast']['total_with_reserve_usd'] > 5.30:
        raise ValueError('Final checkpoint/cost gate')
    allowed = policy['authorized_unknowns']
    journals = sorted(set(root.glob('*/episodes/*/*/*calls.jsonl.gz')) | set(root.glob('smoke-*/calls.jsonl.gz')))
    events = {}
    for path in journals:
        for row in read_records(path):
            events.setdefault(row['attempt_id'], []).append((path, row))
    with closing(sqlite3.connect('file:'+str((root/'budget.db').resolve())+'?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        if db.execute('pragma integrity_check').fetchone()[0] != 'ok':
            raise ValueError('Ledger integrity')
        ledger = [dict(r) for r in db.execute('select * from intents order by created')]
    reconcile_states(ledger, events, allowed)
    requests = []
    responses = {}
    for entry in ledger:
        rows = events[entry['id']]
        intents = [(p, r) for p, r in rows if r['event'] == 'intent']
        completed = [(p, r) for p, r in rows if r['event'] == 'response']
        if len(intents) != 1 or len(completed) != (entry['state'] == 'complete'):
            raise ValueError('Intent/response multiplicity')
        path, intent = intents[0]
        if entry['state'] == 'complete':
            response = completed[0][1]
            row = request_row(response, intent, path)
            recalculated = estimate_usage(row['native_usage'])
            if abs(recalculated['upper_usd']-entry['upper']) > 1e-12 or abs(row['estimate_upper_usd']-entry['upper']) > 1e-12:
                raise ValueError('Native usage/ledger price mismatch')
            if row['model'] != 'gpt-6-luna' or row['effective_reasoning'] != row['effort'] or row['synthetic']:
                raise ValueError('Model/reasoning/synthetic mismatch')
            if row['phase'] == 'main' and row['effort'] != 'high':
                raise ValueError('Main effort changed')
            responses[entry['id']] = response
        else:
            row = unknown_row(entry, rows, allowed[entry['id']])
        row.update(accounting_state=entry['state'], reservation_usd=entry['reserved'],
                   workflow_attempt_kind='original_technical_failure' if 'failed-main-1' in path.parts else
                   'authorized_fresh_retry' if row['phase'] == 'main' and row['episode'] in policy['retry_episodes'] else 'canonical',
                   unknown_cost_is_zero=False)
        requests.append(row)
    if abs(sum(r['estimate_upper_usd'] or 0 for r in requests)-state['estimate_upper_usd']) > 1e-8:
        raise ValueError('Complete request cost reconciliation')
    episodes, _, _ = collect(root)
    aggregate = {(r['phase'], r['episode']): r for r in json.loads((root/'episodes.json').read_text())}
    episodes = [aggregate[(r['phase'], r['episode'])] | r for r in episodes]
    main = [r for r in episodes if r['phase'] == 'main']
    expected = {r['episode']: experiment.stamp(r, 'main', 'high', policy['core_spec']) for r in manifest['matrix']}
    if len(main) != 297 or {r['episode'] for r in main} != set(expected):
        raise ValueError('Canonical matrix completeness')
    vote_ids = set()
    guard_sources = set()
    workflow_attempts = []
    for episode in main:
        folder = root/'main/episodes'/episode['episode']
        job = json.loads((folder/'job.json').read_text())
        if job != expected[episode['episode']] or episode['job_sha256'] != digest(job) or not episode['valid']:
            raise ValueError('Canonical job identity/validity')
        database_check(folder, episode)
        guard = json.loads((folder/'defender.json').read_text())
        if len(guard['votes']) != 3:
            raise ValueError('Missing input vote')
        vote_ids.update(r['attempt_id'] for r in guard['votes'])
        for answer in guard['votes']+list(guard['views'].values()):
            journal = Path(answer['journal'])
            if not journal.is_relative_to(root/'main') or digest(answer['identity']) != answer['query_id'] or answer['identity']['execution_fingerprint'] != policy['core_fingerprint']:
                raise ValueError('Guard provenance/cache phase')
            response = responses[answer['attempt_id']]
            if response['estimate']['upper_usd'] != answer['cost_usd'] or response['phase'] != 'main':
                raise ValueError('Guard response accounting')
            guard_sources.add(answer['attempt_id'])
        episode['workflow_attempt_kind'] = 'authorized_fresh_retry' if episode['episode'] in policy['retry_episodes'] else 'canonical'
        workflow_attempts.append(episode)
    if len(vote_ids) != 234*3:
        raise ValueError('Expected 150/77/7 unique inputs with three votes')
    failed = []
    for path in sorted(root.glob('failed-main-1/episodes/*/*/failed-episode.json')):
        episode = json.loads(path.read_text())
        database_check(path.parent, episode)
        if episode['valid'] or episode['transfers']:
            raise ValueError('Failed attempt business state changed')
        group = [r for r in requests if r['workflow_attempt_kind'] == 'original_technical_failure' and r['episode'] == episode['episode']]
        episode.update(workflow_attempt_kind='original_technical_failure', native_unknown_requests=sum(r['accounting_state'] == 'unknown' for r in group),
                       known_api_equivalent_usd=sum(r['estimate_upper_usd'] or 0 for r in group), total_api_equivalent_usd=None,
                       executor_provider_wait_s=sum(r['latency_s'] for r in group), raw_folder=str(path.parent))
        failed.append(episode)
    if len(failed) != 4 or {r['episode'] for r in failed} != set(policy['retry_episodes']):
        raise ValueError('Four original technical workflows required')
    workflow_attempts += failed
    summary = json.loads((root/'summary.json').read_text())
    if len(summary['phases']['main']['levels']) != 22:
        raise ValueError('Missing control combinations')
    phases = {phase: accounting([r for r in requests if r['phase'] == phase], allowed) for phase in sorted({r['phase'] for r in requests})}
    baseline_path = HERE.parent/'deepseek_flash/results/paid/episodes.json'
    baseline_summary_path = baseline_path.with_name('summary.json')
    baseline = json.loads(baseline_path.read_text())
    paired = paired_comparison(main, baseline)
    observations = {}
    for folder in (Path(policy['source_root']), root):
        for path in folder.glob('usage*.json'):
            row = json.loads(path.read_text()); observations[row['observed_at']] = row
    quota = quota_observations([observations[k] for k in sorted(observations)])
    from analysis import distribution, metrics
    metadata = dict(protocol='2-recovery1', generated_at=datetime.now(UTC).isoformat(), main_completed=297,
        main_workflow_attempts=301, original_technical_failures=4, partial=False, accounting=phases,
        all_phases=accounting(requests, allowed),
        canonical_main_accounting=accounting([r for r in requests if r['phase'] == 'main' and r['workflow_attempt_kind'] != 'original_technical_failure'], allowed),
        original_failed_attempt_accounting=accounting([r for r in requests if r['workflow_attempt_kind'] == 'original_technical_failure'], allowed),
        unknown_requests=[r for r in requests if r['accounting_state'] == 'unknown'],
        matched_deepseek=paired, main_metrics=summary['phases']['main'],
        deepseek_main_metrics=metrics([r for r in baseline if r['phase'] == 'main']),
        deepseek_full_main_metrics=json.loads(baseline_summary_path.read_text())['phases']['main'],
        deepseek_main_executor_and_guard_eliza_usd=4.403506026,
        timing={key: distribution([r.get(field) for r in main]) for key, field in
            [('executor_workflow_s','wall_s'),('defender_s','defender_wall_s'),('workflow_and_posthoc_s','full_wall_s'),
             ('executor_provider_wait_s','model_wait_s'),('defender_provider_wait_s','guard_provider_wait_s'),('workflow_other_s','tool_and_workflow_s')]},
        failed_workflow_s=distribution([r['wall_s'] for r in failed]),
        subscription_usage=quota, final_checkpoint=checkpoint,
        unique_input_votes=len(vote_ids), unique_guard_responses=len(guard_sources),
        core_fingerprint=policy['core_fingerprint'], overlay_fingerprint=policy['runtime_overlay_fingerprint'],
        initial_pilot_forecast=json.loads((root/'forecast.json').read_text()),
        counterfactual_guard_only=True, actual_subscription_charge_usd=None,
        limitations=['Four original requests have no terminal or usage: actual total API-equivalent is unknown; the additional bound is a planning assumption, not measured or guaranteed billing.',
            'Both roles High; model rolling alias is not an immutable weight snapshot.',
            'Authorized protocol 2 omits unsupported 5000-token cap and temperature and maps system to developer plus finbot_tools namespace; encrypted reasoning is replayed.',
            'Shared account subscription percentages include this chat and other activity, with no exclusive FinBot attribution.',
            'Defender is posthoc and did not prevent business actions. Vera repeats reuse three votes per unique input.',
            'Process startup and scheduling waits were not measured and stay null; workflow/posthoc times and native waits are separate.',
            'Four failed original workflows and their known partial costs are separate from successful retries; original runtime clock naturally differs.',
            'Reasoning tokens are included in output tokens and never billed twice.'])
    output.mkdir(parents=True, exist_ok=False)
    for name, rows in [('requests', requests), ('episodes', main), ('workflow-attempts', workflow_attempts),
                       ('original-failed-attempts', failed), ('pilot-episodes', [r for r in episodes if r['phase'].startswith('pilot')])]:
        write_json(output/(name+'.json'), rows); csv_export(output/(name+'.csv'), rows)
    with (output/'requests.jsonl').open('w') as handle:
        for row in requests: handle.write(json.dumps(row, ensure_ascii=False)+'\n')
    write_json(output/'comparison.json', metadata)
    by_role = {phase+':'+role: accounting([r for r in requests if r['phase'] == phase and r['role'] == role], allowed)
               for phase in phases for role in sorted({r['role'] for r in requests if r['phase'] == phase})}
    derived_summary = dict(summary, protocol='2-recovery1', complete_attempt_accounting=phases,
                           canonical_workflow_accounting=summary['accounting'], accounting=by_role,
                           original_unknown_outcomes=metadata['unknown_requests'])
    write_json(output/'summary.json', derived_summary)
    csv_export(output/'control-combinations.csv', [dict(combination=k, **v) for k, v in summary['phases']['main']['levels'].items()])
    write_json(output/'matched-deepseek.json', paired)
    with closing(sqlite3.connect('file:'+str((root/'budget.db').resolve())+'?mode=ro', uri=True)) as db:
        with tempfile.TemporaryDirectory() as td:
            dest = Path(td)/'budget.sqlite'
            with closing(sqlite3.connect(dest)) as target: db.backup(target)
            (output/'budget.snapshot.sqlite.gz').write_bytes(gzip.compress(dest.read_bytes(), mtime=0))
    sources = [Path(__file__), HERE/'verification/export.py', HERE/'verification/resumption.py', HERE/'verification/test_recovery_export.py', HERE/'verification/recovery_report.py']
    write_json(output/'receipt.json', dict(main_episodes=297, workflow_attempts=301, all_requests=len(requests),
        unknown_requests=4, pending=0, business_databases_checked=301, model_usage_checked=len(responses),
        unique_input_votes=702, combinations=22, all_attempts_reconciled=True, unique_completed_payments=True,
        original_unknown_states_preserved=True, core_fingerprint=policy['core_fingerprint'], overlay_hashes=policy['overlay_hashes'],
        source_hashes={str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        recovery_policy_sha256=hashlib.sha256((root/'recovery-policy.json').read_bytes()).hexdigest(),
        deepseek_sources={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (baseline_path, baseline_summary_path)},
        raw_inventory={str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in journals}, network_calls=0))
    return {'main':297, 'workflow_attempts':301, 'requests':len(requests), 'unknown':4, 'output':str(output)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE/'results/subscription-resume-1')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(export_recovery(args.root.resolve(), args.output.resolve())))
