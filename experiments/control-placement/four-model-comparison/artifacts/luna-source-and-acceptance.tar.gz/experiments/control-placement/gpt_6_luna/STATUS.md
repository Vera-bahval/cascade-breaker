# GPT-6 Luna: завершено 297/297

25 октября 2026 финальная точка 297 принята. Обе роли gpt-6-luna / High,
официальный OAuth-маршрут подписки, без покупок и перехода на платный API.
Все пять точек 62/121/180/239/297 проверены; четыре старых unknown приняты только
как явно разрешённое исключение recovery, их usage и стоимость остаются null.
Pending 0, новых unknown 0. 200 готовых workflow не повторялись.

- Выбор по пилотам: High $3.53498233125 с 25% запасом; Medium $3.26966986875.
- Известный main API-эквивалент $1.63539998, включая $0.00920762 известных шагов
  четырёх исходных сбоев. 297 канонических workflow + guard: $1.62619236.
- Неизвестные четыре: плановый резерв $0.9317792, не измеренный/гарантированный
  биллинг. Итоговый прогноз с 25% $3.208973975 <= $5.30; точная полная стоимость null.
- Smoke $0.0001814 и пилоты $0.10984318 отдельно. 6847 намерений во всех фазах,
  6843 завершённых и четыре unknown. Main 6462 = 6458 complete + 4 unknown.
- 301 бизнес-БД main попыток проверены, уникальность платежей подтверждена.
  702 уникальных input votes (234×3), 22 сочетания, native usage завершённых
  запросов и все raw IDs сверены с ledger. CSV/JSON/JSONL экспортированы.
- FPR Luna/DeepSeek 0/150 и 0/150; честные переводы 44/150 и 113/150;
  плохие funnel-переводы 3/43 и 6/43. Posthoc guard не блокировал действия.
- Workflow p50/p95 Luna 99.94/123.50 с, DeepSeek 44.67/60.15 с.
- Weekly used 6%→21% — общий аккаунтный показатель. Обычный лимит доступен
  в последнем снимке 18:22:45 UTC; доля FinBot отдельно не измерима.
- Замороженный core и FinBot/DeepSeek сохранены; отдельная recovery-надстройка
  отражена в policy/fingerprint. 59 core tests и dry 297/297 ранее приняты;
  recovery dry 97/97 и финальные 15 verification tests проходят.
- RAM helper 66225 завершился exit 0; heartbeat finbot-luna-97 удалён.
  Remote OAuth revocation не заявляется. Результаты только в локальном Git.

Главный отчёт: [COMPARISON.md](results/subscription-resume-1/export/COMPARISON.md).
Данные: export/episodes.csv (297), export/workflow-attempts.csv (301),
export/requests.csv (6847), export/comparison.json, export/summary.json,
export/control-combinations.csv, export/original-failed-attempts.csv.
Доказательства: export/receipt.json и checkpoints/batch-5/inventory.json.
Согласованные различия протокола: server cap 5000 и temperature недоступны,
system→developer, namespace finbot_tools, encrypted reasoning replay;
startup/scheduling waits не измерены. Полные ограничения находятся в отчёте.
