import unittest

from suspended_export import summarize_attempts


class SuspendedAccountingTests(unittest.TestCase):
    # Неизвестный usage не превращается в ноль или в резервную оценку.
    def test_unknown_usage_stays_unknown(self):
        rows = [dict(attempt_id='known', accounting_state='complete', estimate_upper_usd=1.25, reservation_usd=0),
                dict(attempt_id='unknown', accounting_state='unknown', estimate_upper_usd=None, reservation_usd=.07)]
        result = summarize_attempts(rows)
        self.assertEqual(result['known_api_equivalent_usd'], 1.25)
        self.assertIsNone(result['total_api_equivalent_usd'])
        self.assertEqual(result['unknown_attempts'], 1)
        self.assertEqual(result['unresolved_reservation_usd'], .07)

    # Повтор журнала не удваивает стоимость молча.
    def test_duplicate_attempt_is_rejected(self):
        row = dict(attempt_id='same', accounting_state='complete', estimate_upper_usd=1, reservation_usd=0)
        with self.assertRaises(ValueError):
            summarize_attempts([row, row])


if __name__ == '__main__':
    unittest.main()
