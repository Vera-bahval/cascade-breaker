import asyncio
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

import httpx

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))


def native():
    return {'id': 'resp_test', 'object': 'response', 'created_at': 1, 'status': 'completed',
            'model': 'gpt-6-luna', 'reasoning': {'effort': 'medium'},
            'output': [{'type': 'message', 'id': 'msg_test', 'role': 'assistant', 'status': 'completed',
                        'content': [{'type': 'output_text', 'text': 'OK', 'annotations': []}]}],
            'usage': {'input_tokens': 10, 'output_tokens': 2, 'total_tokens': 12,
                      'input_tokens_details': {'cached_tokens': 0, 'cache_write_tokens': 0},
                      'output_tokens_details': {'reasoning_tokens': 0}}}


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / 'transport.py').is_file(), 'Missing subscription transport')
        spec = importlib.util.spec_from_file_location('luna_transport_test', HERE / 'transport.py')
        self.t = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.t)

    def run_case(self, upstream):
        async def run(directory):
            tr = self.t.RecordedTransport(Path(directory) / 'calls.jsonl.gz',
                self.t.Ledger(Path(directory) / 'budget.db'),
                {'phase': 'pilot-medium', 'role': 'executor', 'effort': 'medium', 'agent': 'invoice'},
                upstream=httpx.MockTransport(upstream), token_source=lambda: 'fake-token')
            async with httpx.AsyncClient(transport=tr) as client:
                return await client.post('https://api.openai.com/v1/responses', json={
                    'model': 'gpt-6-luna', 'input': [{'role': 'system', 'content': 'unchanged'}],
                    'temperature': 0, 'max_output_tokens': 5000})
        with tempfile.TemporaryDirectory() as directory:
            error = None; response = None
            try: response = asyncio.run(run(directory))
            except self.t.RunStopped as exc: error = exc
            rows = self.t.read_records(Path(directory) / 'calls.jsonl.gz')
            state = self.t.Ledger(Path(directory) / 'budget.db').state()
            return response, error, rows, state

    # Native SSE сохраняется; SDK получает привычный Responses JSON.
    def test_success_and_mapping(self):
        def handler(request):
            body = json.loads(request.content)
            self.assertEqual(body['input'][0], {'role': 'developer', 'content': 'unchanged'})
            self.assertNotIn('max_output_tokens', body)
            self.assertEqual(request.headers['Authorization'], 'Bearer fake-token')
            event = {'type': 'response.completed', 'sequence_number': 1, 'response': native()}
            return httpx.Response(200, text='data: ' + json.dumps(event) + '\n\n',
                                  headers={'content-type': 'text/event-stream'})
        response, error, rows, state = self.run_case(handler)
        self.assertIsNone(error)
        self.assertEqual(response.json()['id'], 'resp_test')
        self.assertEqual(state['pending'], 0)
        self.assertEqual(len([r for r in rows if r['event'] == 'response']), 1)
        self.assertNotIn('fake-token', json.dumps(rows))

    # Обрыв потока оставляет неопределенный intent, исключая повтор.
    def test_truncated_stream_is_unknown(self):
        response, error, rows, state = self.run_case(lambda _: httpx.Response(200, text='data: {}\n\n'))
        self.assertIsNotNone(error)
        self.assertEqual(len(state['unresolved']), 1)

    # HTTP-ошибки не вызывают скрытые повторные обращения.
    def test_http_failures_are_not_retried(self):
        for code in (401, 403, 429, 500):
            attempts = []
            def handler(request):
                attempts.append(request); return httpx.Response(code, json={'error': 'fixture'})
            _, error, _, _ = self.run_case(handler)
            self.assertIsNotNone(error)
            self.assertEqual(len(attempts), 1)

    # Счетчики не теряются даже при ошибочной модели в завершенном ответе.
    def test_wrong_model_is_stopped_with_usage_saved(self):
        value = native(); value['model'] = 'another-model'
        event = {'type': 'response.completed', 'response': value}
        _, error, rows, state = self.run_case(lambda _: httpx.Response(200, text='data: ' + json.dumps(event) + '\n\n'))
        self.assertIsNotNone(error)
        self.assertEqual(state['pending'], 0)
        self.assertGreater(state['estimate_upper_usd'], 0)

    # Промежуточный накопительный usage не суммируется с terminal usage.
    def test_cumulative_usage_is_accounted_once(self):
        value=native()
        events=[{'type':'response.in_progress','response':value},
                {'type':'response.completed','sequence_number':3,'response':value}]
        events.append(events[-1])
        _, error, _, state=self.run_case(lambda _:httpx.Response(200,text=''.join('data: '+json.dumps(e)+'\n\n' for e in events)))
        self.assertIsNone(error)
        self.assertAlmostEqual(state['estimate_upper_usd'], .000002)

    # Потерянный usage, битый JSON и перенаправление не разрешают следующий запрос.
    def test_protocol_failures_are_saved_and_stopped(self):
        missing=native();missing.pop('usage')
        for event in ('broken-json',json.dumps({'type':'response.completed','response':missing}),
                      json.dumps({'type':'model/rerouted','model':'other'}),
                      json.dumps({'type':'response.compaction','summary':'fixture'}),
                      json.dumps({'type':'response.failed','response':dict(native(),status='failed')})):
            _, error, rows, _=self.run_case(lambda _:httpx.Response(200,text='data: '+event+'\n\n'))
            self.assertIsNotNone(error)
            self.assertTrue(any(r['event']=='raw_event' for r in rows))

    # Неизвестный tool, повторный call_id и некорректные аргументы не исполняются.
    def test_malformed_tools_never_reach_finbot(self):
        for item in ({'name':'foreign','call_id':'call_x','arguments':'{}'},
                     {'name':'foreign','call_id':'','arguments':'{}'},
                     {'name':'foreign','call_id':'call_x','arguments':'not-json'}):
            value=native();value['output']=[dict(item,type='function_call',namespace='finbot_tools')]
            event={'type':'response.completed','response':value}
            response,error,_,state=self.run_case(lambda _:httpx.Response(200,text='data: '+json.dumps(event)+'\n\n'))
            self.assertIsNone(response);self.assertIsNotNone(error)
            self.assertEqual(state['pending'],0)

    # Таймаут после отправки оставляет unknown; пустой terminal сохраняется, но не исполняется.
    def test_timeout_and_empty_output_stop(self):
        def timeout(request):raise httpx.ReadTimeout('fixture timeout')
        _,error,_,state=self.run_case(timeout)
        self.assertIsNotNone(error);self.assertEqual(len(state['unresolved']),1)
        value=native();value['output']=[]
        event={'type':'response.completed','response':value}
        _,error,_,state=self.run_case(lambda _:httpx.Response(200,text='data: '+json.dumps(event)+'\n\n'))
        self.assertIsNotNone(error);self.assertEqual(state['pending'],0)


if __name__ == '__main__': unittest.main()
