"""Recorded subscription Responses transport. FinBot owns all business tools."""

import asyncio
import json
import time
import uuid

import httpx

from adapter import MODEL, ProtocolError, as_chat, restore_reasoning, sdk_response, terminal_response, wire_request
from support import Ledger, RunStopped, append_record, digest, estimate_usage, read_records, reservation, write_json

BASE_URL = 'https://api.openai.com/v1'


def validate_output(response, body):
    if response.get('model') != MODEL: raise ProtocolError('Unexpected effective model')
    effort = (response.get('reasoning') or {}).get('effort')
    if effort != body['reasoning']['effort']: raise ProtocolError('Effective reasoning unavailable or mismatched')
    if response.get('service_tier') not in (None, 'default'): raise ProtocolError('Unexpected service tier')
    if not isinstance(response.get('output'), list) or not response['output']: raise ProtocolError('Empty response output')
    names = {tool['name'] for group in body.get('tools', []) for tool in group.get('tools', [])}
    call_ids = set()
    for item in response.get('output', []):
        kind = item.get('type')
        if kind == 'function_call':
            call_id = item.get('call_id')
            if not isinstance(call_id, str) or not call_id or call_id in call_ids:
                raise ProtocolError('Invalid or duplicated function call ID')
            call_ids.add(call_id)
            if item.get('name') not in names: raise ProtocolError('Function not in original schema')
            try: arguments = json.loads(item['arguments'])
            except (KeyError, TypeError, ValueError) as exc: raise ProtocolError('Malformed function arguments') from exc
            if not isinstance(arguments, dict): raise ProtocolError('Function arguments must be an object')
        elif kind not in ('message', 'reasoning'):
            raise ProtocolError('Unexpected output item: ' + str(kind))
    sdk_response(response)


class RecordedTransport(httpx.AsyncBaseTransport):
    def __init__(self, path, ledger, context, *, upstream=None, token_source=None):
        self.path = path; self.ledger = ledger; self.context = context
        self.upstream = httpx.AsyncClient(transport=upstream or httpx.AsyncHTTPTransport(retries=0),
                                          timeout=60, follow_redirects=False, trust_env=False)
        if token_source is None:
            from subscription_auth import worker_token
            token_source = worker_token
        self.token_source = token_source
        self.previous = [{'input': row['sdk_input'], 'output': row['sdk_output'], 'agent': row.get('agent')}
                         for row in read_records(path) if row.get('event') == 'sdk_delivery' and row.get('sdk_output')]

    def record(self, event, attempt, **values):
        append_record(self.path, dict(self.context, event=event, attempt_id=attempt, at=time.time(), **values))

    @staticmethod
    def mask(value):
        import re
        return re.sub(r'(?i)(?:OAuth|Bearer)\s+\S+|\b(?:sk-|eyJ)[A-Za-z0-9_.-]{10,}', '<redacted>', value)

    async def handle_async_request(self, request):
        attempt = uuid.uuid4().hex; started = time.perf_counter(); response = None; accounted = False
        try:
            if request.method != 'POST' or request.url.host != 'api.openai.com' or request.url.path not in (
                    '/v1/responses', '/v1/chat/completions'):
                raise ProtocolError('Unexpected SDK endpoint')
            original = json.loads(await request.aread())
            source = dict(original)
            history = source.get('input')
            if isinstance(history, list):
                source['input'] = restore_reasoning(history, self.previous, self.context.get('agent'))
            body, mapping = wire_request(source, self.context['effort'], chat=request.url.path.endswith('/chat/completions'))
            mapping['restored_reasoning_items'] = len(body['input']) - (len(history) if isinstance(history, list) else len(body['input']))
            # Credential retrieval precedes intent: no provider request has happened if the broker fails.
            token = self.token_source()
        except (Exception, RunStopped) as exc:
            raise RunStopped('Before dispatch: ' + self.mask(type(exc).__name__ + ': ' + str(exc))) from exc
        with self.ledger.request_lease(attempt):
            self.ledger.reserve(attempt, self.context['phase'], 0. if self.context.get('synthetic') else reservation(body), self.context)
            self.record('intent', attempt, sdk_request=original, wire_request=body, mapping=mapping,
                        request_sha256=digest(body), timeout_s=60)
            events = []; first_event = None; first_text = None; http_status = None
            try:
                async with asyncio.timeout(60):
                    async with self.upstream.stream('POST', BASE_URL + '/responses', json=body,
                            headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'}) as upstream:
                        http_status = upstream.status_code
                        self.record('headers', attempt, http_status=http_status,
                                    headers={k:v for k,v in upstream.headers.items() if k in ('x-request-id', 'openai-processing-ms')
                                             or k.startswith('x-ratelimit-')})
                        if http_status != 200: raise ProtocolError('Provider HTTP ' + str(http_status))
                        frame = []
                        async for line in upstream.aiter_lines():
                            if line:
                                if line.startswith('data:'): frame.append(line[5:].lstrip())
                                continue
                            if not frame: continue
                            raw = '\n'.join(frame); frame = []
                            if raw == '[DONE]': continue
                            elapsed = time.perf_counter() - started
                            self.record('raw_event', attempt, raw=raw, elapsed_s=elapsed)
                            event = json.loads(raw); events.append(event)
                            if first_event is None: first_event = elapsed
                            if first_text is None and event.get('type') == 'response.output_text.delta': first_text = elapsed
                        if frame: raise ProtocolError('Unterminated SSE frame')
                # Preserve usage on known terminal failures, too; never fabricate completion from a partial stream.
                candidates = [event.get('response') for event in events if event.get('type') in (
                              'response.completed', 'response.incomplete', 'response.failed') and isinstance(event.get('response'), dict)]
                assembly_error = None
                try: native = terminal_response(events)
                except ProtocolError as exc:
                    native = None; assembly_error = exc
                if candidates:
                    response = candidates[-1]
                    estimate = estimate_usage(response.get('usage'))
                    if self.context.get('synthetic'):
                        estimate.update(lower_usd=0., upper_usd=0., kind='Offline synthetic fixture; no inference')
                    self.ledger.complete(attempt, estimate, {'response_id': response.get('id')}); accounted = True
                    self.record('response', attempt, native_response=response, assembled_response=native,
                                assembly='Completed output items by index; native terminal retained unchanged', estimate=estimate, http_status=http_status,
                                latency_s=time.perf_counter()-started, first_event_s=first_event, first_text_s=first_text)
                if assembly_error is not None:raise assembly_error
                validate_output(native, body)
                normalized = sdk_response(native)
                sdk_input = original.get('input', original.get('messages'))
                self.record('sdk_delivery', attempt, sdk_input=sdk_input, sdk_output=normalized.get('output'),
                            response_id=native['id'])
                if isinstance(sdk_input, list):
                    self.previous.append({'input': sdk_input, 'output': normalized.get('output', []), 'agent': self.context.get('agent')})
                return httpx.Response(200, json=as_chat(normalized) if request.url.path.endswith('/chat/completions') else normalized)
            except BaseException as exc:
                reason = self.mask(type(exc).__name__ + ': ' + str(exc))
                if not accounted: self.ledger.unknown(attempt, reason)
                self.record('stopped', attempt, reason=reason, usage_accounted=accounted)
                write_json(self.ledger.path.parent / 'halt.json', {'reason': reason, 'attempt_id': attempt,
                           'usage_accounted': accounted, 'at': time.time()})
                raise RunStopped(reason) from exc
            finally: token = None

    async def aclose(self):
        await self.upstream.aclose()
