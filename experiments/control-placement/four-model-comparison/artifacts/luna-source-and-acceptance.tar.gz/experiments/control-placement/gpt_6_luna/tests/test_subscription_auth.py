"""No external network or real credentials in authentication tests."""

import importlib.util
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

import jwt
from cryptography.hazmat.primitives.asymmetric import rsa


HERE = Path(__file__).resolve().parents[1]


class AuthTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "subscription_auth.py").is_file(), "Missing OAuth client")
        spec = importlib.util.spec_from_file_location("subscription_auth", HERE / "subscription_auth.py")
        self.auth = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.auth)

    # PKCE challenge зависит от verifier; в URL verifier не попадает.
    def test_authorization_url_contains_required_plan_scope_and_no_verifier(self):
        attempt = self.auth.new_attempt("http://127.0.0.1:1455/auth/callback", "urn:uuid:test-host")
        query = parse_qs(urlsplit(attempt["url"]).query)
        self.assertEqual(query["client_id"], ["dynamic_agent_client"])
        self.assertIn("chatgpt.tokens.use.direct", query["scope"][0].split())
        self.assertNotIn(attempt["verifier"], attempt["url"])
        self.assertEqual(query["code_challenge_method"], ["S256"])

    # Неверный state не дает принять authorization code.
    def test_callback_rejects_wrong_state(self):
        with self.assertRaises(self.auth.AuthError):
            self.auth.check_callback({"state": ["wrong"], "code": ["fake"]}, {"state": "expected"})

    # Отказ пользователя не приводит к обмену code.
    def test_callback_rejects_access_denied(self):
        with self.assertRaisesRegex(self.auth.AuthError, "denied"):
            self.auth.check_callback({"state": ["ok"], "error": ["access_denied"]}, {"state": "ok"})

    # Дубли query parameters не позволяют выбрать неоднозначное значение.
    def test_callback_rejects_duplicate_code(self):
        with self.assertRaises(self.auth.AuthError):
            self.auth.check_callback({"state": ["ok"], "code": ["one", "two"], "client_id": ["issued"]},
                                     {"state": "ok"})

    # Динамический placeholder нельзя использовать как выданный client ID.
    def test_callback_requires_issued_client_id(self):
        with self.assertRaises(self.auth.AuthError):
            self.auth.check_callback({"state": ["ok"], "code": ["code"],
                                      "client_id": ["dynamic_agent_client"]}, {"state": "ok"})

    # Повторный вход не заменяет сохраненный client ID другим.
    def test_callback_rejects_client_switch(self):
        with self.assertRaises(self.auth.AuthError):
            self.auth.check_callback({"state": ["ok"], "code": ["code"], "client_id": ["other"]},
                                     {"state": "ok", "client_id": "issued"})

    # Подписанный JWT проверяется по audience, issuer и nonce.
    def test_signed_identity_validation_and_nonce(self):
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        claims = {"iss": "https://auth.openai.com", "aud": "issued", "sub": "fake-subject",
                  "iat": int(time.time()), "exp": int(time.time()) + 120, "nonce": "nonce"}
        token = jwt.encode(claims, private, algorithm="RS256")
        self.assertEqual(self.auth.verify_identity(token, private.public_key(), "issued", "nonce"), "fake-subject")
        with self.assertRaises(self.auth.AuthError):
            self.auth.verify_identity(token, private.public_key(), "issued", "other-nonce")
        with self.assertRaises(self.auth.AuthError):
            self.auth.verify_identity(token, private.public_key(), "other-client", "nonce")

    # Подпись чужим ключом не принимается.
    def test_bad_signature_is_rejected(self):
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        token = jwt.encode({"iss": "https://auth.openai.com", "aud": "issued", "sub": "fake",
                            "iat": int(time.time()), "exp": int(time.time()) + 120, "nonce": "nonce"},
                           private, algorithm="RS256")
        with self.assertRaises(self.auth.AuthError):
            self.auth.verify_identity(token, other.public_key(), "issued", "nonce")

    # Один ID token без разрешения на plan usage недостаточен.
    def test_granted_scope_is_required(self):
        with self.assertRaises(self.auth.AuthError):
            self.auth.check_token_fields({"access_token": "fake", "token_type": "Bearer",
                                         "expires_in": 3600, "scope": "openid"})

    # Даже ошибочный caller не может записать credential через public metadata writer.
    def test_public_metadata_rejects_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "metadata.json"
            with self.assertRaises(self.auth.AuthError):
                self.auth.public_json(output, {"nested": {"access_token": "test-only"}})
            self.assertFalse(output.exists())

    # Unix broker передает токен только клиенту с capability и не пишет его на диск.
    def test_broker_round_trip_and_permissions(self):
        class FakeSession:
            expires = time.time() + 3600
            def access_token(self):
                return "test-only-broker-token"
        broker = self.auth.Broker(FakeSession())
        try:
            self.assertEqual(os.stat(broker.directory).st_mode & 0o777, 0o700)
            self.assertEqual(os.stat(broker.address).st_mode & 0o777, 0o600)
            with patch.dict(os.environ, broker.environment()):
                self.assertEqual(self.auth.worker_token(), "test-only-broker-token")
            with patch.dict(os.environ, broker.environment() | {"LUNA_AUTH_CAPABILITY": "wrong"}):
                with self.assertRaises(self.auth.AuthError):
                    self.auth.worker_token()
        finally:
            broker.close()


if __name__ == "__main__":
    unittest.main()
