import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "adapter.py").is_file(), "Missing protocol-2 adapter")
        spec = importlib.util.spec_from_file_location("luna_adapter", HERE / "adapter.py")
        self.a = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.a)

    def request(self):
        return json.loads((HERE / "results/preflight-20261025-v2/finbot-sdk-request.reference.json").read_text())

    # Содержимое system message и порядок истории остаются исходными.
    def test_real_request_mapping_preserves_content_order_and_tool_schemas(self):
        original = self.request()
        before = copy.deepcopy(original)
        wire, changes = self.a.wire_request(original, "medium")
        self.assertEqual(original, before)
        self.assertNotIn("temperature", wire)
        self.assertNotIn("max_output_tokens", wire)
        self.assertEqual(wire["input"][0]["content"], original["input"][0]["content"])
        self.assertEqual(wire["input"][0]["role"], "developer")
        self.assertEqual(wire["tools"][0]["tools"], original["tools"])
        self.assertEqual(wire["reasoning"]["effort"], "medium")
        self.assertEqual(wire["model"], "gpt-6-luna")
        self.assertFalse(wire["store"])
        self.assertTrue(wire["stream"])
        self.assertTrue(changes["server_output_limit_unavailable"])
        for old, new in zip(original["input"], wire["input"]):
            if old.get("type") == "function_call":
                self.assertEqual(old["call_id"], new["call_id"])
                self.assertEqual(old["arguments"], new["arguments"])
                self.assertEqual(new["namespace"], "finbot_tools")

    # Неизвестный параметр не теряется при переводе запроса.
    def test_unknown_request_field_is_rejected(self):
        with self.assertRaises(self.a.ProtocolError):
            self.a.wire_request(self.request() | {"unknown_option": 1}, "high")

    # Чужой namespace не превращается в допустимый бизнес-инструмент.
    def test_response_tool_namespace_is_checked(self):
        response = {"output": [{"type": "function_call", "name": "read", "namespace": "other"}]}
        with self.assertRaises(self.a.ProtocolError):
            self.a.sdk_response(response)

    # Частные namespace metadata не меняют исходное имя и ID инструмента.
    def test_response_removes_only_adapter_namespace(self):
        response = {"output": [{"type": "function_call", "name": "read", "namespace": "finbot_tools",
                                  "call_id": "one", "arguments": "{}"}]}
        sdk = self.a.sdk_response(response)
        self.assertNotIn("namespace", sdk["output"][0])
        self.assertEqual(sdk["output"][0]["call_id"], "one")
        self.assertEqual(response["output"][0]["namespace"], "finbot_tools")

    # Guard Chat request переводится в Responses без изменения текста.
    def test_guard_chat_conversion(self):
        wire, _ = self.a.wire_request({"model": "gpt-6-luna", "temperature": 0,
                                       "messages": [{"role": "user", "content": "original guard"}]},
                                      "high", chat=True)
        self.assertEqual(wire["input"], [{"role": "user", "content": "original guard"}])

    # Reasoning items восстанавливаются только для совпавшего префикса истории.
    def test_reasoning_replay_matches_exact_history_and_agent(self):
        prior = {"input": [{"role": "user", "content": "invoice"}],
                 "output": [{"type": "reasoning", "id": "rs1", "encrypted_content": "opaque"},
                            {"type": "function_call", "name": "read", "call_id": "c1", "arguments": "{}"}],
                 "agent": "invoice"}
        current = prior["input"] + [{"type": "function_call", "name": "read", "call_id": "c1", "arguments": "{}"},
                                     {"type": "function_call_output", "call_id": "c1", "output": "result"}]
        augmented = self.a.restore_reasoning(current, [prior], "invoice")
        self.assertEqual(augmented[1], prior["output"][0])
        self.assertEqual(self.a.restore_reasoning(current, [prior], "fraud"), current)
        self.assertEqual(self.a.restore_reasoning([{"role": "user", "content": "different"}], [prior], "invoice"),
                         [{"role": "user", "content": "different"}])

    # Повторное событие не учитывается вторым ответом; конфликт дублей — ошибка.
    def test_terminal_deduplication_and_conflict(self):
        response = {"id": "resp1", "model": "gpt-6-luna", "status": "completed", "output": [{"type": "message"}]}
        event = {"type": "response.completed", "sequence_number": 7, "response": response}
        self.assertEqual(self.a.terminal_response([event, event]), response)
        with self.assertRaises(self.a.ProtocolError):
            self.a.terminal_response([event, event | {"response": response | {"id": "other"}}])

    # Обрезанный поток без terminal event не выдается за завершенный ответ.
    def test_stream_without_terminal_is_rejected(self):
        with self.assertRaises(self.a.ProtocolError):
            self.a.terminal_response([{"type": "response.created", "response": {"id": "one"}}])

    # Подписочный SSE отдает готовый item отдельно от пустого terminal output.
    def test_completed_items_assemble_empty_terminal_output(self):
        item={"id":"msg_fixture","type":"message","status":"completed","role":"assistant",
              "content":[{"type":"output_text","text":"OK","annotations":[]}]}
        native={"id":"resp_fixture","status":"completed","output":[]}
        events=[{"type":"response.output_item.done","output_index":0,"item":item},
                {"type":"response.completed","response":native}]
        self.assertEqual(self.a.terminal_response(events)["output"],[item])
        self.assertEqual(native['output'],[])

    # Пропуск индекса или противоречащие финальные items не достраиваются догадкой.
    def test_completed_item_conflicts_are_rejected(self):
        item={"type":"message","id":"msg1"}
        for events in ([{"type":"response.output_item.done","output_index":1,"item":item}],
                       [{"type":"response.output_item.done","output_index":0,"item":item},
                        {"type":"response.output_item.done","output_index":0,"item":dict(item,id='msg2')}]):
            events += [{"type":"response.completed","response":{"status":"completed","output":[]}}]
            with self.assertRaises(self.a.ProtocolError):self.a.terminal_response(events)


if __name__ == "__main__":
    unittest.main()
