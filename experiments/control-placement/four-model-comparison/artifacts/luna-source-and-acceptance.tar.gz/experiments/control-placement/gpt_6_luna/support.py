"""Durable intent ledger and API-equivalent accounting; no subscription charges."""

from contextlib import contextmanager
import fcntl
import gzip
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import time
import uuid


class RunStopped(BaseException):
    """Bypass business/SDK Exception retry handlers after an uncertain request."""


PRICING = {"model": "gpt-6-luna", "tier": "Standard", "checked_on": "2026-10-25",
           "url": "https://developers.openai.com/api/docs/models/gpt-6-luna",
           "usd_per_million": {"input": .10, "cached": .01, "output": .50,
                               "write_30m": .125, "write_12h": .25},
           "long_context_threshold": 272000, "maximum_model_output": 128000}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    import os
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('x') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write('\n'); handle.flush(); os.fsync(handle.fileno())
        temporary.replace(path)
        fd = os.open(path.parent, os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)


def append_record(path, value):
    import os
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n').encode()
    with path.open('ab') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        handle.write(gzip.compress(raw) if path.suffix == '.gz' else raw)
        handle.flush(); os.fsync(handle.fileno())


def read_records(path):
    path = Path(path)
    if not path.exists() or not path.stat().st_size: return []
    opener = gzip.open if path.suffix == '.gz' else open
    try:
        with opener(path, 'rt') as handle: return [json.loads(line) for line in handle if line.strip()]
    except (EOFError, OSError, ValueError) as exc:
        raise RunStopped('Damaged journal: ' + str(path)) from exc


def count(value, name):
    if type(value) is not int or value < 0: raise RunStopped('Invalid usage counter: ' + name)
    return value


def estimate_usage(usage):
    if not isinstance(usage, dict): raise RunStopped('Usage unavailable')
    incoming = count(usage.get('input_tokens'), 'input_tokens')
    outgoing = count(usage.get('output_tokens'), 'output_tokens')
    details = usage.get('input_tokens_details') or {}
    out_details = usage.get('output_tokens_details') or {}
    unavailable = []
    counters = {}
    for name, data in [('cached_tokens', details), ('cache_write_tokens', details),
                       ('reasoning_tokens', out_details)]:
        value = data.get(name)
        if value is None: unavailable.append(name)
        else: count(value, name)
        counters[name] = value
    cached, writes = counters['cached_tokens'], counters['cache_write_tokens']
    if (cached or 0) + (writes or 0) > incoming or (counters['reasoning_tokens'] or 0) > outgoing:
        raise RunStopped('Inconsistent usage counters')
    if usage.get('total_tokens') is not None and count(usage['total_tokens'], 'total_tokens') != incoming + outgoing:
        raise RunStopped('Inconsistent total tokens')
    long = incoming > PRICING['long_context_threshold']
    input_multiplier, output_multiplier = (2, 1.5) if long else (1, 1)
    rates = PRICING['usd_per_million']
    known_cached = cached or 0
    known_writes = writes or 0
    remainder = incoming - known_cached - known_writes
    low_remainder = rates['cached'] if cached is None else rates['input']
    high_remainder = rates['write_12h'] if writes is None else rates['input']
    lower_in = known_cached * rates['cached'] + known_writes * rates['write_30m'] + remainder * low_remainder
    upper_in = known_cached * rates['cached'] + known_writes * rates['write_12h'] + remainder * high_remainder
    output_cost = outgoing * rates['output'] * output_multiplier
    return dict(lower_usd=(lower_in * input_multiplier + output_cost) / 1e6,
                upper_usd=(upper_in * input_multiplier + output_cost) / 1e6,
                input_tokens=incoming, output_tokens=outgoing, **counters,
                unavailable=unavailable, actual_charge_usd=None, long_context=long,
                kind='API-equivalent estimate; subscription usage measured separately', pricing=PRICING)


def reservation(body):
    # A UTF-8 byte bound and the advertised model maximum; neither is an enforced output cap.
    incoming_bound = len(json.dumps(body, ensure_ascii=False).encode()) + 4096
    long = incoming_bound > PRICING['long_context_threshold']
    return (incoming_bound * .25 * (2 if long else 1) + 128000 * .50 * (1.5 if long else 1)) / 1e6


class Ledger:
    def __init__(self, path, cap=5.30):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.cap = cap
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS intents (id TEXT PRIMARY KEY, phase TEXT NOT NULL, '
                       'state TEXT NOT NULL, reserved REAL NOT NULL, lower REAL, upper REAL, '
                       'context TEXT NOT NULL, metadata TEXT, created REAL NOT NULL, completed REAL)')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db: yield db
        finally: db.close()

    def lease_path(self, attempt):
        directory = self.path.parent / 'request-leases'; directory.mkdir(exist_ok=True)
        return directory / (digest(attempt) + '.lock')

    @contextmanager
    def request_lease(self, attempt):
        with self.lease_path(attempt).open('a+b') as handle:
            try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError: raise RunStopped('Duplicate active request lease')
            yield

    def alive(self, attempt):
        with self.lease_path(attempt).open('a+b') as handle:
            try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError: return True
        return False

    def reserve(self, attempt, phase, worst, context):
        if not math.isfinite(worst) or worst < 0: raise RunStopped('Invalid request reservation')
        if (self.path.parent / 'halt.json').exists(): raise RunStopped('Run is halted')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            active = db.execute("SELECT * FROM intents WHERE state != 'complete'").fetchall()
            if any(row['state'] == 'unknown' or not self.alive(row['id']) for row in active):
                raise RunStopped('Unresolved request outcome; reconciliation required')
            if phase == 'main':
                spent = db.execute("SELECT COALESCE(SUM(CASE WHEN state='complete' THEN upper ELSE reserved END),0) "
                                   "FROM intents WHERE phase='main'").fetchone()[0]
                if spent + worst > self.cap: raise RunStopped('Main API-equivalent exposure exceeds cap')
            try:
                db.execute('INSERT INTO intents(id,phase,state,reserved,context,created) VALUES(?,?,?,?,?,?)',
                           (attempt, phase, 'pending', worst, json.dumps(context), time.time()))
            except sqlite3.IntegrityError as exc: raise RunStopped('Repeated request intent') from exc

    def complete(self, attempt, estimate, metadata):
        lower, upper = estimate.get('lower_usd'), estimate.get('upper_usd')
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in (lower, upper)) or lower > upper:
            raise RunStopped('Invalid estimate')
        with self.connect() as db:
            result = db.execute("UPDATE intents SET state='complete',lower=?,upper=?,metadata=?,completed=? "
                                "WHERE id=? AND state='pending'", (lower, upper,
                                json.dumps(dict(metadata, estimate=estimate)), time.time(), attempt))
            if result.rowcount != 1: raise RunStopped('Request is not pending; cannot complete')

    def unknown(self, attempt, reason):
        with self.connect() as db:
            db.execute("UPDATE intents SET state='unknown',metadata=? WHERE id=? AND state='pending'",
                       (json.dumps({'reason': reason}), attempt))

    def state(self):
        with self.connect() as db: rows = [dict(r) for r in db.execute('SELECT * FROM intents ORDER BY created')]
        phases = {}
        for row in rows:
            phase = phases.setdefault(row['phase'], {'lower_usd': 0., 'upper_usd': 0., 'reserved_usd': 0., 'requests': 0})
            phase['requests'] += 1
            if row['state'] == 'complete':
                phase['lower_usd'] += row['lower']; phase['upper_usd'] += row['upper']
            else: phase['reserved_usd'] += row['reserved']
        return {'estimate_lower_usd': sum(p['lower_usd'] for p in phases.values()),
                'estimate_upper_usd': sum(p['upper_usd'] for p in phases.values()),
                'pending': sum(r['state'] == 'pending' for r in rows),
                'unresolved': [r['id'] for r in rows if r['state'] != 'complete'],
                'phases': phases, 'actual_charge_usd': None, 'main_cap_usd': self.cap,
                'sqlite_integrity': self.integrity()}

    def integrity(self):
        with self.connect() as db: return db.execute('PRAGMA integrity_check').fetchone()[0]
