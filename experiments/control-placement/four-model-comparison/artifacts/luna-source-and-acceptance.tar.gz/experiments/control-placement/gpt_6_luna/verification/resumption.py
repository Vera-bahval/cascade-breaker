"""Explicit recovery overlay; original FinBot/transport/prompt sources are immutable.

Four original unknown outcomes stay unknown. User approved fresh isolated retries
and continuation on 2026-10-25. Any additional unknown stops all new requests.
"""
import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sqlite3
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from support import Ledger as BaseLedger, RunStopped, digest, read_records, write_json, reservation

SOURCE=HERE/'results/subscription'
DEST=HERE/'results/subscription-resume-1'
AUTHORIZATION='Давай продолжим 93, а эти можем поретраить'


def unknown_bound(body):
    # Запас на сериализацию/служебный контекст; это модель бюджета, не новый usage.
    incoming=min(1050000,4*len(json.dumps(body,ensure_ascii=False).encode())+65536)
    long=incoming>272000
    # Максимальная опубликованная цена записи кэша; дополнительный запас Fast/region.
    upper=(incoming*.25*(2 if long else 1)+128000*.50*(1.5 if long else 1))/1e6*2.2
    return dict(input_tokens_budget_ceiling=incoming,output_tokens_ceiling=128000,
                budget_bound_usd=max(reservation(body),upper),usage=None,
                method='4x serialized UTF8 bytes + 65536 input buffer, model output maximum, maximum published cache-write rate, 2.2x extra tier/regional reserve; planning assumption, not measured usage',
                pricing_source='https://developers.openai.com/api/docs/pricing',
                model_source='https://developers.openai.com/api/docs/models/gpt-6-luna')


class AuthorizedLedger(BaseLedger):
    def policy(self):
        value=json.loads((self.path.parent/'recovery-policy.json').read_text())
        if Path(value['root']).resolve()!=self.path.parent.resolve():raise RunStopped('Recovery root mismatch')
        return value

    def allowed(self,rows):
        expected=self.policy()['authorized_unknowns']
        if len(expected)>4:raise RunStopped('Recovery allowance exceeds four original requests')
        found={r['id']:r for r in rows if r['id'] in expected}
        if set(found)!=set(expected):raise RunStopped('Original unknown disappeared')
        for key,row in found.items():
            rule=expected[key]
            if row['state']!='unknown' or row['reserved']!=rule['reserved'] or digest(json.loads(row['context']))!=rule['context_sha256']:
                raise RunStopped('Original unknown identity changed')
        return expected

    def reserve(self,attempt,phase,worst,context):
        import math
        if not math.isfinite(worst) or worst<0:raise RunStopped('Invalid reservation')
        if (self.path.parent/'halt.json').exists():raise RunStopped('New halt blocks recovery')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows=[dict(r) for r in db.execute('select * from intents')]
            allowed=self.allowed(rows)
            active=[r for r in rows if r['state']!='complete' and r['id'] not in allowed]
            if any(r['state']=='unknown' or not self.alive(r['id']) for r in active):raise RunStopped('New unresolved request blocks recovery')
            if phase=='main':
                spent=sum(r['upper'] if r['state']=='complete' else allowed[r['id']]['budget_bound_usd'] if r['id'] in allowed else r['reserved'] for r in rows if r['phase']=='main')
                if spent+worst>self.cap:raise RunStopped('Combined main exposure exceeds cap')
            try:db.execute('insert into intents(id,phase,state,reserved,context,created) values(?,?,?,?,?,?)',
                           (attempt,phase,'pending',worst,json.dumps(context),time.time()))
            except sqlite3.IntegrityError as exc:raise RunStopped('Repeated intent') from exc

    def state(self):
        value=super().state()
        with self.connect() as db:rows=[dict(r) for r in db.execute('select * from intents')]
        allowed=self.allowed(rows)
        value['unresolved_all']=value['unresolved']
        value['authorized_unknowns']=list(allowed)
        value['unresolved']=[key for key in value['unresolved_all'] if key not in allowed]
        value['unresolved_definition']='Blocking outcomes; the explicit original allowance is preserved separately in unresolved_all/authorized_unknowns and in SQLite as unknown.'
        value['authorized_unknown_budget_bound_usd']=sum(r['budget_bound_usd'] for r in allowed.values())
        value['total_api_equivalent_usd']=None if value['unresolved_all'] else value['estimate_upper_usd']
        value['main_api_equivalent_interval_usd']=[value['phases'].get('main',{}).get('lower_usd',0),value['phases'].get('main',{}).get('upper_usd',0)+value['authorized_unknown_budget_bound_usd']]
        return value


def overlay_hashes():
    return {str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'auth_catalog.py',Path(__file__),HERE/'verification/test_resumption.py')}


def initialize(destination=DEST):
    import experiment
    if destination.exists():raise RunStopped('Recovery destination already exists')
    original=json.loads((SOURCE/'manifest.json').read_text())
    with closing(sqlite3.connect('file:'+str((SOURCE/'budget.db').resolve())+'?mode=ro',uri=True)) as db:
        db.row_factory=sqlite3.Row
        unknown=[dict(r) for r in db.execute("select * from intents where state!='complete'")]
        if len(unknown)!=4 or any(r['state']!='unknown' for r in unknown):raise RunStopped('Expected exactly four original unknowns')
        destination.mkdir()
        with closing(sqlite3.connect(destination/'budget.db')) as target:db.backup(target)
    copied=[]
    for name in ('main','pilot-medium','pilot-high','smoke-medium','smoke-high','smoke'):
        shutil.copytree(SOURCE/name,destination/name,ignore=shutil.ignore_patterns('*.lock','*.db','*.db-wal','*.db-shm'))
    for name in ('manifest.json','forecast.json','usage-latest.json','checkpoint-1.json','checkpoint-2.json','checkpoint-3.json'):
        shutil.copyfile(SOURCE/name,destination/name)
    # Пути к побайтовым копиям raw journals меняются только в метаданных кэша.
    for path in destination.rglob('*.json'):
        if path.name!='defender.json' and path.parent.name!='guard-results':continue
        value=json.loads(path.read_text())
        def rebase(v):
            if isinstance(v,dict):return {k:rebase(x) for k,x in v.items()}
            if isinstance(v,list):return [rebase(x) for x in v]
            if isinstance(v,str) and v.startswith(str(SOURCE)+'/'):return str(destination)+v[len(str(SOURCE)):]
            return v
        updated=rebase(value)
        if updated!=value:
            copied.append({'path':str(path.relative_to(destination)),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
            write_json(path,updated)
    allowances={};retry=[]
    for row in unknown:
        context=json.loads(row['context']);episode=context['episode'];retry.append(episode)
        source=destination/'main/episodes'/episode
        outcome=json.loads((source/'episode.json').read_text());database=json.loads((source/'database.json').read_text())
        tools=[r.get('tool_name','') for r in read_records(source/'hooks.jsonl') if r.get('hook_kind')=='before_tool']
        if outcome['transfers'] or outcome['create_transfer_calls'] or database.get('emails') or database.get('payment_transactions') or any('send_email' in t or 'create_transfer' in t or t=='delegate_to_communication' for t in tools):
            raise RunStopped('Retry would duplicate a business side effect')
        intent=next(r for r in read_records(source/'calls.jsonl.gz') if r['event']=='intent' and r['attempt_id']==row['id'])
        allowances[row['id']]={'reserved':row['reserved'],'context_sha256':digest(context),**unknown_bound(intent['wire_request'])}
        archive=destination/'failed-main-1/episodes'/episode;archive.parent.mkdir(parents=True,exist_ok=True)
        source.rename(archive)
        (archive/'episode.json').rename(archive/'failed-episode.json')
    policy={'version':'protocol2-recovery1','root':str(destination.resolve()),'source_root':str(SOURCE),
            'authorization':AUTHORIZATION,'authorized_unknowns':allowances,'retry_episodes':retry,
            'core_spec':original['execution_spec'],'core_fingerprint':original['execution_fingerprint'],
            'overlay_hashes':overlay_hashes(),'runtime_overlay_fingerprint':digest(overlay_hashes()),
            'copied_guard_metadata':copied,'original_halt':json.loads((SOURCE/'halt.json').read_text()),
            'new_unknown_policy':'Stop, no automatic retries','unknown_usage_policy':'Keep original unknown and null counters; reserve budget bound, never mark complete or zero',
            'completed_prefix':200,'new_episodes':93,'fresh_retry_episodes':4}
    write_json(destination/'recovery-policy.json',policy)
    return policy


def configure(root):
    import experiment,transport,analysis,worker
    policy=json.loads((root/'recovery-policy.json').read_text())
    if policy['overlay_hashes']!=overlay_hashes():raise RunStopped('Recovery overlay changed')
    original_spec=experiment.execution_spec
    def pinned_spec():
        actual=original_spec();expected=policy['core_spec']
        extra=set(actual['source_hashes'])-set(expected['source_hashes'])
        if extra!={'gpt_6_luna/auth_catalog.py'}:raise RunStopped('Unexpected source overlay')
        actual['source_hashes'].pop('gpt_6_luna/auth_catalog.py')
        if actual!=expected:raise RunStopped('Frozen FinBot/transport/model/dependencies changed')
        return expected
    pinned_spec()
    experiment.execution_spec=pinned_spec;worker.execution_spec=pinned_spec
    for module in (experiment,transport,analysis,worker):module.Ledger=AuthorizedLedger
    original_forecast=experiment.remaining_forecast
    def forecast(runroot,manifest):
        value=original_forecast(runroot,manifest)
        state=AuthorizedLedger(runroot/'budget.db').state()
        value.update(authorized_unknowns=state['authorized_unknowns'],authorized_unknown_budget_bound_usd=state['authorized_unknown_budget_bound_usd'],total_actual_api_equivalent_usd=None)
        value['total_with_reserve_usd']=1.25*(value['spent_upper_usd']+value['remaining_base_usd']+state['authorized_unknown_budget_bound_usd'])
        write_json(runroot/'main-forecast-latest.json',value)
        if value['total_with_reserve_usd']>5.30:
            write_json(runroot/'halt.json',{'reason':'Combined recovery forecast exceeds cap','forecast':value})
            raise RunStopped('Combined recovery forecast exceeds cap')
        return value
    experiment.remaining_forecast=forecast
    def run_worker(job,runroot,mode):
        existing,defend_only=experiment.preflight_job(job,runroot)
        if existing is not None and not defend_only:return existing
        if (runroot/'halt.json').exists():raise RunStopped('New halt blocks recovery')
        dest=runroot/job['phase']/'episodes'/job['episode'];dest.mkdir(parents=True,exist_ok=True)
        write_json(dest/'job.json',job)
        command=[sys.executable,str(HERE/'auth_catalog.py'),'worker',str(dest/'job.json'),str(runroot),mode]
        if defend_only:command.append('--defend-only')
        try:
            cp=subprocess.run(command,cwd=experiment.FINBOT,env=experiment.env_for(dest/'final.db'),capture_output=True,
                              timeout=1800,pass_fds=(experiment.CONTROLLER_FD,) if experiment.CONTROLLER_FD is not None else ())
        except subprocess.TimeoutExpired:
            write_json(runroot/'halt.json',{'reason':'Recovery worker timeout','episode':job['episode']})
            raise RunStopped('Worker timeout')
        for name,payload in [('out.txt',cp.stdout),('err.txt',cp.stderr)]:
            (dest/(('resume-' if defend_only else '')+name)).write_text(transport.RecordedTransport.mask(payload.decode(errors='replace')))
        write_json(runroot/'budget.json',AuthorizedLedger(runroot/'budget.db').state())
        if cp.returncode or not (dest/'defender.json').exists():
            if not (runroot/'halt.json').exists():write_json(runroot/'halt.json',{'reason':'Recovery worker failed','episode':job['episode']})
            raise RunStopped('Recovery worker failed: '+job['episode'])
        row=json.loads((dest/'episode.json').read_text())
        print(json.dumps({'episode':job['episode'],'valid':row['valid'],'retry':job['episode'] in policy['retry_episodes']}),flush=True)
        return row
    experiment.run_worker=run_worker
    return experiment,policy


def dry(root):
    experiment,policy=configure(root)
    target=HERE/'.runtime/recovery-dry';target.mkdir(exist_ok=False)
    drypolicy=dict(policy,root=str(target.resolve()),authorized_unknowns={})
    write_json(target/'recovery-policy.json',drypolicy)
    # Включая те же 97 ID и повторения, но без внешней сети и OAuth.
    complete={p.parent.parent.name+'/'+p.parent.name for p in root.glob('main/episodes/*/*/defender.json')}
    jobs=[experiment.stamp(j,'main','high',policy['core_spec']) for j in experiment.matrix() if j['episode'] not in complete]
    from concurrent.futures import ThreadPoolExecutor
    with experiment.controller_lock(target),ThreadPoolExecutor(max_workers=4) as pool:
        for wave in experiment.waves(jobs,4):list(pool.map(lambda job:experiment.run_worker(job,target,'offline'),wave))
    receipt=__import__('analysis').acceptance(target,'main',97)
    receipt.update(overlay_hashes=overlay_hashes(),external_inference_requests=0,episodes=97)
    write_json(root/'recovery-dry-accepted.json',receipt)
    return {'dry_accepted':97,'external_inference_requests':0}


def main():
    try:
        if len(sys.argv)>1 and sys.argv[1]=='worker':
            root=Path(sys.argv[3]);configure(root)
            sys.argv=[str(HERE/'worker.py')]+sys.argv[2:]
            runpy.run_path(str(HERE/'worker.py'),run_name='__main__');return
        parser=argparse.ArgumentParser(description=__doc__)
        parser.add_argument('command',choices=['initialize','dry','forecast','main','checkpoint','report'])
        parser.add_argument('--root',type=Path,default=DEST);parser.add_argument('--batch',type=int,choices=[4,5])
        args=parser.parse_args();root=args.root.resolve()
        if args.command=='initialize':
            p=initialize(root);print(json.dumps({'initialized':str(root),'unknown_budget_bound_usd':sum(r['budget_bound_usd'] for r in p['authorized_unknowns'].values())}));return
        if args.command=='dry':print(json.dumps(dry(root)));return
        experiment,policy=configure(root)
        if args.command=='forecast':
            print(json.dumps(experiment.remaining_forecast(root,json.loads((root/'manifest.json').read_text()))));return
        if args.command in ('main','checkpoint'):
            receipt=json.loads((root/'recovery-dry-accepted.json').read_text())
            if receipt.get('episodes')!=97 or receipt['overlay_hashes']!=overlay_hashes():raise RunStopped('Current recovery dry acceptance required')
        result=experiment.execute(args)
        print(json.dumps({'command':args.command,'batch':args.batch,'completed':True,
                          'authorized_unknowns':4,'result':result if args.command=='checkpoint' else None}),flush=True)
    except RunStopped as exc:
        print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(2)


if __name__=='__main__':main()
