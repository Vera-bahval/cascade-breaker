# DeepSeek Flash reproduction — execution ledger

Approved specification: the user's implementation plan in this chat.
Research base: 5c2b5c3309de10b460225ee0b4edff0b90d1c35d.
FinBot base: a7f6964fbc60da807e2544d826a5b4e20eb0c5dc.
Global paid budget: USD 25 including smoke, pilot, retries and defender.

1. Isolated branch: complete. Native app worktree creation returned Not a git repository; used the existing clone's Git worktree mechanism in the authorized workspace.
2. Offline transport, accounting and fault tests: 22 passed. Original research tests: 64 run, one prototype module skipped (Flask absent).
3. Full 297-case offline execution and artifact checks: accepted. Receipt and complete execution log are in verification/. Incomplete earlier attempts are quarantined and never accepted under a new code version.
4. Smoke attempted once: OpenRouter returned 404 paid-model-training-violation-by-account before generation. Two readbacks confirm zero cost and unchanged external quota; reservation reconciled with evidence. Eight-case pilot pending a supported route decision.
5. Frozen main execution in five balanced batches: pending.
6. Independent whole-branch review: completed once; all six Important findings addressed before paid inference. Final analysis and verification pending.

Pre-flight: worker requests and defender requests must share one durable spend ledger; unknown in-flight cost prevents further inference. Both roles consume the same frozen model configuration. Offline results must never enter paid metrics.

Review rulings:

- Fingerprint includes controller/tests, original prompts/views, datasets, runtime FinBot sources, dependencies, Python and pristine DB. Captured before a phase, included in jobs and checked by workers and at phase end.
- Unclassified failed workflows pause execution as invalid. Exhausted iterations remain model outcomes.
- Raw HTTP response/status/request ID are saved before JSON parsing.
- All new transactions are compared with pristine, including transfers on another invoice.
- Fresh, restored and cached guard answers use identical block/reason/confidence validation.
- Acceptance opens snapshots, validates guard query provenance, reconciles snapshot JSON and spend journals, and rejects every unknown ledger status.
- Eliza getRetries reads X-Retries; the executor compares AttemptCount against this total attempt limit. Requests send X-Retries=1 and X-Request-Timeout=60s and require attempt_count=1. SDK retries and provider fallbacks are also disabled.
- Fresh account quota must cover the conservative remaining forecast at each main checkpoint. No quota reset is issued.
- A later fault test reproduced JSON corruption when redacting credential-shaped model text. Redaction now walks parsed strings instead of rewriting serialized JSON. The incomplete dry run was stopped on its source fingerprint change and quarantined; the entire matrix is being repeated with the corrected version.

Preflight metadata: external remaining USD 27.813626592 in chain:top_opensource; daily USD 15; no DeepSeek paid generation at this point.

Live blocker: pinned DeepSeek provider endpoint is excluded by the selected Eliza OpenRouter key's account data policy. No retry, fallback, key switching or privacy change was attempted. Eliza also advertises a native external deepseek-flash route (/deepseek/chat/completions), but it has no versioned IDs in the registry and requires a Responses-to-Chat adapter. A user choice has been requested because this changes the approved fixed-snapshot transport plan.

User steering: use the correct Eliza route as documented. Native means Eliza directly proxies the provider's API; it does not require a separate user DeepSeek key. Implemented the documented /deepseek/chat/completions route for deepseek-flash and a stateless Responses↔Chat adapter. Current official mapping is DeepSeek-V4.1-Flash-1017; a public-document version check guards phase/checkpoint continuation. Both SDK and wire data are retained. 25 fault/integration tests pass; the first native offline episode completed 21 calls plus all 13 guard checks. A fresh full native 297-case offline run is underway before native generation.

Native validation: all 297 current-source dry episodes accepted; 26 fault/integration tests passed. Four native smoke requests passed, cost USD 0.000337668. Delayed quota readback at 2026-10-24T19:32:30Z exactly reconciled DeepSeek monthly +4 requests / +0.000337668. Accepted original requests without repeated inference. Eight-case native pilot started.

User requested API parallelism. Sequential eight-case pilot accepted without technical failure (USD 0.10880832; combined smoke+pilot USD 0.109145988). Preserved unchanged under results/paid/history/sequential-pilot with relocation receipt. Added four-job waves with unique scenario cache keys, one-controller flock, per-request kernel leases, aggregate outstanding reserves in every cap, and cross-worker halt receipts. All 32 tests pass, including four concurrent simulated HTTP calls, orphan reservation, cap exposure, unknown/halt propagation, wave uniqueness and controller exclusion. A fresh full offline matrix is running before paid parallel validation.

Independent review found two restart hazards before paid parallel use. Fixed controller ownership across parent death by inheriting its flock descriptor in each worker (no explicit LOCK_UN); added a real subprocess regression. Added full-phase resume preflight before dispatch and sticky halt for all worker/preflight errors; added partial-episode regression. All 34 tests pass; reviewer confirmed both Important findings closed. The incomplete free dry is archived without reusing its receipts. Restarting full current-source matrix.

Current parallel full dry accepted297/297, external inference0. Parallel pilot accepted8/8; observed peak HTTP concurrency4, elapsed146.1276s vs sequential468.6561s, 3.207x. Parallel pilot cost USD0.118402422; all tests USD0.227548410. Main297 conservative total bound USD11.588170848. Manifest frozen; main batch1 launching.

## Native service timeout and audited continuation

The main series stopped at 32 fully completed episodes when four concurrent native requests hit the fixed 60-second deadline. No retries were sent while billing was unknown. Two stable Eliza readbacks (20:17:39 and 20:22:01 UTC) matched all 1370 successful native requests exactly: $0.766306548. Each of the four timeouts was reconciled to zero cost with this saved evidence. All original interrupted episodes and journals are preserved in `results/paid/incidents/native-timeout-20261024T2011/`.

Three episodes resumed only the missing defender queries. TH664 had already completed 19 paid calls and all four delegates; `verification/resume_orchestrator.py` restored the original session, context, delegation counters, chain and remaining iteration budget. It checked both SDK and wire payload equality before reserve/dispatch. A local fixture and rejection gates passed; a separate code review was accepted. Exactly one new model request completed the original workflow, costing $0.000678156, without replaying prior delegates. The episode records explicit recovery provenance and separate active versus pause-inclusive durations. Frozen inference core and its execution fingerprint remain unchanged.

Completed obsolete dry-run scratch directories were compressed losslessly after verifying every member SHA256; receipts are in `verification/scratch-compression.json`. Accepted current dry-run and all paid evidence remain available.

A second native read timeout occurred in TH519's Fraud call at 49 completed episodes. It stopped the next request in H5's Communication workflow and one defender. Two readbacks matched 1780 successful native requests and $0.990179808 exactly; the sole new unreturned request was reconciled to zero. `verification/recover_stack.py` reconstructed original agent stacks from 10/18 existing SDK responses, using exact saved initial prompts and verified rebuilt subsequent inputs. Completed tools returned their recorded outputs without executing; original delegation loops restored counters and context. MCP reconnection added only explicit `tools/list` audit records, separately preserved. All business tables stayed unchanged before the first new request. Offline proofs, crash/idempotency rejection tests and independent review passed. Controlled continuations completed successfully; all additional real responses and explicit provenance are retained. Total expense after both continuations: $0.996903600.

## Завершение основной серии

Приняты контрольные точки 62/121/180/239/297. Пакеты 2–5 не добавили технических сбоев. Финальная проверка всех 297 эпизодов прошла; 8236 оплаченных ответов и $4.631054436 точно совпали с внешней квотой Eliza. Остаток $23.182572156, неопределённых списаний нет. Итоги и ограничения сравнения: results/paid/COMPARISON.md.
