"""Write status from the latest reviewed immutable checkpoint, never live partial data."""
import json
from pathlib import Path
PKG=Path(__file__).resolve().parents[1];root=PKG/'results/paid'
accepted=sorted(root.glob('checkpoints/batch-*/reviewed.json'))
assert accepted
folder=accepted[-1].parent;batch=int(folder.name[-1])
audit=json.loads((folder/'audit.json').read_text());summary=json.loads((folder/'summary.json').read_text())
forecast=json.loads((folder/'forecast.json').read_text());m=summary['phases']['main'];n=m['submitted']
complete=n==297
text=['# Состояние эксперимента DeepSeek Flash','',
 f'Последняя проверенная контрольная точка: **{n}/297 ({100*n/297:.1f}%)**, пакет{batch}. '+('Полная серия завершена.' if complete else 'Полная серия ещё не завершена; выполняется основная программа эксперимента.'),'',
 f'Подтверждённый расход на этой точке: **${audit["budget"]["spent_usd"]:.9f}** из$25, включая smoke, оба пилота и все продолжения. '+f'Консервативный прогноз полной серии: ${forecast["total_bound_usd"]:.9f}.','',
 f'FPR FinBot: {m["fpr"]["numerator"]}/{m["fpr"]["denominator"]}; FPR входного защитника: {m["input_guard_fpr"]["numerator"]}/{m["input_guard_fpr"]["denominator"]}; честных с переводом: {m["honest_paid"]["numerator"]}/{m["honest_paid"]["denominator"]}; плохих с завершённым переводом: {m["bad_transferred"]["numerator"]}/{m["bad_transferred"]["denominator"]}. Отсутствие оплаты не приравнивается к отклонению.','',
 '- Бесплатный dry run:297/297, внешних генераций0; 34 проверки основного стенда пройдены.\n- Smoke и отдельный восьмисценарный пилот приняты до основной серии.\n- Обе роли: внешний deepseek-flash через Eliza /deepseek/chat/completions, temperature0, thinking disabled, reasoning effort none, output limit5000, request timeout60s.\n- Alias обновляемый; декларация версии DeepSeek-V4.1-Flash-1017 проверяется по документации.\n- Четыре параллельных эпизода. Пилот ускорился с468,66 до146,13с (3,21×); аудит подтверждает peak4.\n- Исходные наборы, FinBot a7f6964, промпты, бизнес-логика и core стенда4c94925 заморожены. Восстановления имеют отдельные SHA и provenance.','',
 f'Сохранено технических ошибок API: {len(audit["errors_preserved"])}. Все соответствующие расходы сверены; на проверенной точке нет неопределённых списаний. Исходные инциденты, offline proofs и независимые review находятся в results/paid/incidents/. Выполненные бизнес-действия и уже оплаченные ответы при восстановлении не повторялись.','',
 f'Артефакты: results/paid/checkpoints/{folder.name}/ — отчёты, сравнение, CSV/JSON запросов, ledger, квота, аудит и SHA256. Все промежуточные точки сохранены отдельно.','',
 'Квота Eliza обновляется с задержкой; стоимость каждого полученного ответа и отдельно сверенных таймаутов зафиксирована в ledger. Финальная сверка квоты хранится отдельно после завершения серии. Защитник оценивается posthoc: его решения не выдаются за фактические блокировки FinBot.']
(PKG/'STATUS.md').write_text('\n'.join(text)+'\n')
print('Status updated from',folder.name)
