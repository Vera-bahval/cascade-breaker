"""Local checkpoint audit independent of the frozen runner; no API requests."""
import collections,json,sys
from datetime import datetime
from pathlib import Path
PKG=Path(__file__).resolve().parents[1];sys.path.insert(0,str(PKG))
from transport import Ledger,read_records,write_json
root=PKG/'results/paid';batch=int(sys.argv[1])
from experiment import controller_lock
with controller_lock(root):
    checkpoint=json.loads((root/f'checkpoint-{batch}.json').read_text())
    manifest=json.loads((root/'manifest.json').read_text())
    ledger=Ledger(root/'budget.db').state();assert ledger['pending']==0 and ledger['spent_usd']<25
    jobs=[j for j in manifest['matrix'] if j['batch']<=batch]
    episodes=[json.loads((root/'main/episodes'/j['episode']/'episode.json').read_text()) for j in jobs]
    assert len(episodes)==[62,121,180,239,297][batch-1]
    assert all(r['valid'] for r in episodes)
    counts=collections.Counter(r['dataset'] for r in episodes)
    assert counts['fpr']==30*batch and counts['vera7']==14*batch
    native_requests=[];responses=[];accounting=[];errors=[]
    for j in jobs:
     p=root/'main/episodes'/j['episode']
     for name in ['calls.jsonl.gz','guard-calls.jsonl.gz']:
      for r in read_records(p/name):
       if r['event']=='request':
        b=r['request'];assert r['endpoint']=='/deepseek/chat/completions'
        assert b['model']=='deepseek-flash' and b['temperature']==0 and b['thinking']=={'type':'disabled'}
        assert b['reasoning_effort']=='none' and b['max_tokens']==5000 and b['stream'] is False
        assert r['eliza_headers']=={'X-Retries':'1','X-Request-Timeout':'60s'}
        native_requests.append(r)
       elif r['event']=='response':
        responses.append(r)
        if r['http_status']==200:
         assert r['body']['attempt_count']==1
         inner=r['body']['response'];assert inner['model']=='deepseek-flash'
         assert not inner['choices'][0]['message'].get('reasoning_content')
       elif r['event']=='accounting':accounting.append(r)
       elif r['event']=='error':errors.append(r)
    with Ledger(root/'budget.db').connect() as db:
     bills={r['id']:dict(r) for r in db.execute('SELECT * FROM requests')}
    role={}
    for name in ['executor','defender']:
     rows=[r for r in accounting if r['role']==name]
     attempts=[r for r in native_requests if r['role']==name]
     role[name]={'total_attempts':len(attempts),'successful_accounting_requests':len(rows),
      'cost_usd':sum(bills[r['attempt_id']]['cost'] for r in attempts)}
     for field in ['input_tokens','output_tokens','cached_tokens','reasoning_tokens','provider_cost_usd']:
      available=[r[field] for r in rows if r.get(field) is not None]
      role[name][field]={'sum_available':sum(available) if available else None,'available_requests':len(available),'total_requests':len(attempts)}
    edges=[]
    for r in responses:
        if r.get('utc') and r.get('latency_s') is not None:
            end=datetime.fromisoformat(r['utc']).timestamp()
            edges.extend([(end-r['latency_s'],1),(end,-1)])
    active=peak=0
    for _,delta in sorted(edges):
        active+=delta;peak=max(peak,active)
    assert peak<=4
    quota=json.loads((root/f'checkpoint-{batch}-quota.json').read_text())
    write_json(root/'checkpoints'/f'batch-{batch}'/'audit.json',{'accepted':True,'completed':len(episodes),
     'by_dataset':dict(counts),'observed_successful_request_peak_concurrency':peak,'parameter_checked_requests':len(native_requests),'responses':len(responses),
     'main_accounting_by_role':role,'errors_preserved':errors,'budget':ledger,
     'quota_readback_file':f'checkpoint-{batch}-quota.json','quota_lag_possible':True,
     'recovery_episodes':[r['episode'] for r in episodes if r.get('recovery_provenance')]})
    print(json.dumps({'accepted':True,'batch':batch,'completed':len(episodes),'requests_checked':len(native_requests),'spent_usd':ledger['spent_usd']}))
