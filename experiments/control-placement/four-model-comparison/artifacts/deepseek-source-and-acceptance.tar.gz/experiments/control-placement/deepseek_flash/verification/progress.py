"""Read-only compact status for the running controlled experiment."""
import collections,json,sqlite3,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'results/paid'
episodes=[json.loads(p.read_text()) for p in root.glob('main/episodes/*/*/episode.json')]
complete=[r for r in episodes if r['valid'] and (root/'main/episodes'/r['episode']/'defender.json').is_file()]
with sqlite3.connect(root/'budget.db') as db:
 db.row_factory=sqlite3.Row;rows=[dict(x) for x in db.execute('SELECT * FROM requests')]
print(json.dumps({'complete':len(complete),'datasets':dict(collections.Counter(r['dataset'] for r in complete)),
 'executor_complete':sum(r['valid'] for r in episodes),'spent_usd':sum(r['cost'] or 0 for r in rows),
 'active_or_unsettled':[(r['id'],r['status']) for r in rows if r['cost'] is None or r['status']=='unknown'],
 'halt':json.loads((root/'halt.json').read_text()) if (root/'halt.json').is_file() else None,
 'checkpoints':[p.name for p in root.glob('checkpoint-?.json')]},ensure_ascii=False))
