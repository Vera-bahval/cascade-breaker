"""Frozen reproduction controller. All inference requires an explicit paid command."""
from __future__ import annotations

import argparse
import fcntl
import collections
import hashlib
import json
import os
import random
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from contextlib import contextmanager

from transport import Ledger, MODEL, DECLARED_VERSION, RunStopped, digest, read_records, write_json

HERE = Path(__file__).resolve().parent
CODE = HERE.parent / 'code'
RUNTIME = HERE / '.runtime'
FINBOT = RUNTIME / 'finbot'
SETS = {'fpr': 'v6_honest_scenarios.json', 'vera7': 'vera7_scenarios.json', 'funnel': 'our_scenarios.json'}
RESEARCH = '5c2b5c3309de10b460225ee0b4edff0b90d1c35d'
FINBOT_COMMIT = 'a7f6964fbc60da807e2544d826a5b4e20eb0c5dc'
PAID_CONCURRENCY = 4
CONTROLLER_FD = None


@contextmanager
def controller_lock(root):
    global CONTROLLER_FD
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    with (root / 'controller.lock').open('a+b') as handle:
        try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise RunStopped('Another inference controller owns this run')
        previous = CONTROLLER_FD; CONTROLLER_FD = handle.fileno()
        try: yield CONTROLLER_FD
        finally: CONTROLLER_FD = previous
        # Закрытие, без LOCK_UN: унаследованный worker сохраняет lock после смерти родителя.


def waves(jobs, count):
    pending = list(jobs)
    while pending:
        wave, deferred, keys = [], [], set()
        for job in pending:
            key = (job['dataset'], job['scenario']['id'])
            if len(wave) < count and key not in keys:
                wave.append(job); keys.add(key)
            else: deferred.append(job)
        yield wave
        pending = deferred


def matrix():
    sets = {k: json.loads((CODE / 'finbot477' / p).read_text()) for k, p in SETS.items()}
    assert {k: len(v) for k, v in sets.items()} == {'fpr': 150, 'vera7': 7, 'funnel': 77}
    rng = random.Random(20261024)
    buckets = [[] for _ in range(5)]
    for dataset, scenarios in sets.items():
        groups = collections.defaultdict(list)
        for index, scenario in enumerate(scenarios): groups[scenario['truth']].append((index, scenario))
        for truth, rows in sorted(groups.items()):
            rng.shuffle(rows)
            if dataset == 'vera7':
                for batch in range(5):
                    for index, scenario in rows:
                        for repeat in (2 * batch + 1, 2 * batch + 2):
                            buckets[batch].append(dict(dataset=dataset, index=index, scenario=scenario,
                                                       repeat=repeat, batch=batch + 1,
                                                       episode=f'{dataset}/{scenario["id"]}-r{repeat}'))
            else:
                # Сдвиг малых страт сохраняет все четыре класса в каждом пакете.
                for n, (index, scenario) in enumerate(rows):
                    batch = n % 5
                    buckets[batch].append(dict(dataset=dataset, index=index, scenario=scenario,
                                               repeat=1, batch=batch + 1,
                                               episode=f'{dataset}/{scenario["id"]}-r1'))
    out = []
    for bucket in buckets:
        rng.shuffle(bucket); out.extend(bucket)
    return out


def source_hashes():
    paths = list(HERE.glob('*.py')) + list((HERE / 'tests').glob('*.py'))
    paths += [CODE / p for p in ('llm_guardrail.py', 'levels_finbot477.py', 'levels_inputs.py', 'levels_detector.py')]
    paths += [CODE / 'finbot477' / p for p in SETS.values()]
    return {str(p.relative_to(HERE.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def pilot_jobs():
    selected=[('fpr','TH601'),('fpr','TH608'),('funnel','H1'),('funnel','TA501'),
              ('funnel','FD57-none'),('funnel','FD53-none'),('vera7','V2'),('vera7','V5')]
    return [next(j for j in matrix() if j['dataset']==ds and j['scenario']['id']==sid and j['repeat']==1)
            for ds,sid in selected]


def execution_spec():
    import importlib.metadata
    paths=[p for p in FINBOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.suffix in ('.py','.toml','.yaml','.yml','.txt','.jinja','.jinja2','.j2','.json','.md')]
    return {'source_hashes':source_hashes(),
            'finbot_hashes':{str(p.relative_to(FINBOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},
            'dependencies':{d.metadata['Name'].lower():d.version for d in importlib.metadata.distributions() if d.metadata.get('Name')},
            'python':sys.version,'model':MODEL,'declared_version':DECLARED_VERSION,'model_id_kind':'native rolling alias',
            'endpoint':'/deepseek/chat/completions','provider':'deepseek','temperature':0,'thinking':{'type':'disabled'},'reasoning':'none',
            'offline_concurrency':4,'paid_concurrency':PAID_CONCURRENCY,
            'scheduling':'Four-episode waves; unique (dataset, scenario ID) within each wave',
            'pristine_sha256':hashlib.sha256((RUNTIME/'pristine_C.db').read_bytes()).hexdigest()}


def stamped(job,phase,spec=None):
    return dict(job,phase=phase,execution_fingerprint=digest(spec or execution_spec()))


def start_phase(root,phase,spec):
    path=Path(root)/phase/'execution.json'
    if path.exists() and json.loads(path.read_text())['fingerprint']!=digest(spec):
        raise RunStopped('Phase implementation changed; preserve old artifacts and use a fresh phase root')
    write_json(path,{'fingerprint':digest(spec),'spec':spec,'started_at':datetime.now(UTC).isoformat()})


def env_for(database):
    return os.environ.copy() | {'DATABASE_URL': 'sqlite:///' + str(database), 'DATABASE_TYPE': 'sqlite',
                               'LLM_PROVIDER': 'openai', 'LLM_DEFAULT_MODEL': MODEL,
                               'LLM_DEFAULT_TEMPERATURE': '0', 'LLM_MAX_TOKENS': '5000', 'LLM_TIMEOUT': '60',
                               'OPENAI_API_KEY': 'injected-in-transport-only', 'EMAIL_PROVIDER': 'console',
                               'REDIS_URL': 'redis://127.0.0.1:1', 'LOG_LEVEL': 'error', 'DEBUG': 'true'}


def prepare():
    if not (FINBOT / 'scripts/cascade_failure_demo.py').is_file(): raise RunStopped('Pinned FinBot archive absent')
    pristine = RUNTIME / 'pristine_C.db'
    if not pristine.exists():
        env = env_for(pristine)
        commands = [[sys.executable, 'scripts/db.py', 'setup'],
                    [sys.executable, str(CODE / 'finbot477/seed_profile.py'), 'C', '0']]
        with (RUNTIME / 'seed.log').open('w') as log:
            for command in commands:
                subprocess.run(command, cwd=FINBOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        import sqlite3
        with sqlite3.connect(pristine) as db:
            db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            assert db.execute('SELECT count(*) FROM vendors').fetchone()[0] == 1
            assert db.execute('SELECT count(*) FROM invoices').fetchone()[0] == 5
    return pristine


def metadata():
    import httpx
    sys.path.insert(0, str(Path.home() / '.agents/skills/store/scripts'))
    from agent_auth_client import resolve
    token = resolve('eliza', store=True)
    with httpx.Client(headers={'Authorization': 'OAuth ' + token}, timeout=30) as client:
        result = {'verified_at': datetime.now(UTC).isoformat()}
        for name, path in [('quotas', '/v2/quotas'), ('usage', '/v2/usage'),
                           ('model', '/v1/models?id=' + MODEL.replace('/', '%2F'))]:
            r = client.get('https://api.eliza.yandex.net' + path)
            if r.status_code != 200: raise RunStopped('Metadata HTTP ' + str(r.status_code))
            result[name] = r.json()
    result['declared_native_version']=native_version()
    return result


def native_version():
    import html,re,httpx
    # Отдельный публичный клиент: OAuth Eliza никогда не уходит на сайт документации.
    response=httpx.get('https://api-docs.deepseek.com/quick_start/pricing/',timeout=30,follow_redirects=True)
    response.raise_for_status()
    text=' '.join(html.unescape(re.sub('<[^>]+>',' ',response.text)).split())
    match=re.search(r'MODEL VERSION\s+(DeepSeek-[A-Za-z0-9.-]+)',text)
    if not match or match.group(1)!=DECLARED_VERSION:raise RunStopped('Declared native DeepSeek version changed or unavailable')
    return {'version':match.group(1),'source':'https://api-docs.deepseek.com/quick_start/pricing/',
            'html_sha256':hashlib.sha256(response.content).hexdigest(),'verified_at':datetime.now(UTC).isoformat()}


def remaining(meta):
    limits = meta['quotas']['quotas']['external']['limits']
    limit = next(a for a in limits if a['name'] == 'chain:top_opensource')
    monthly = next(a['usage']['cost'] for a in limit['limits'] if a['type'] == 'monthly')
    usage = meta['usage']['usage']['chain:top_opensource']['stats']
    return monthly - usage['monthly']['cost'], 15 - sum(
        v['stats']['daily']['cost'] for v in meta['usage']['usage'].values())


def preflight_job(job, root):
    root = Path(root).resolve()
    if (root/'halt.json').exists(): raise RunStopped('Run halted; audit required')
    dest = root / job['phase'] / 'episodes' / job['episode']
    final = dest / 'episode.json'
    defender_only=False
    if final.exists():
        existing = json.loads(final.read_text())
        if existing['job_sha256'] != digest(job): raise RunStopped('Resume job mismatch')
        if not existing['valid']:raise RunStopped('Invalid saved episode; audit required')
        if episode_complete(dest,digest(job)):return existing,False
        defender_only=True
    if not defender_only and dest.exists() and any(dest.iterdir()): raise RunStopped('Partial episode needs audit: ' + str(dest))
    return (existing if defender_only else None),defender_only


def run_worker(job, root, mode):
    try: return _run_worker(job, root, mode)
    except BaseException:
        write_json(Path(root)/'halt.json',{'reason':'Worker or preflight failed','episode':job['episode'],'at':time.time()})
        raise


def _run_worker(job, root, mode):
    root=Path(root).resolve()
    existing,defender_only=preflight_job(job,root)
    if existing is not None and not defender_only:return existing
    dest=root/job['phase']/'episodes'/job['episode'];final=dest/'episode.json'
    dest.mkdir(parents=True, exist_ok=True)
    write_json(dest / 'job.json', job)
    command = [sys.executable, str(HERE / 'worker.py'), str(dest / 'job.json'), str(root), mode]
    if defender_only:command.append('--defend-only')
    started = time.monotonic()
    try:
        cp = subprocess.run(command, cwd=FINBOT, env=env_for(dest / 'final.db'),
                            capture_output=True, timeout=1800,
                            pass_fds=(CONTROLLER_FD,) if CONTROLLER_FD is not None else ())
    except subprocess.TimeoutExpired as exc:
        (dest / 'out.txt').write_bytes(exc.stdout or b'')
        (dest / 'err.txt').write_bytes(exc.stderr or b'')
        write_json(root/'halt.json',{'reason':'Worker wall timeout','episode':job['episode'],'at':time.time()})
        raise RunStopped('Worker wall timeout; reconcile pending requests')
    for name, payload in [('out.txt', cp.stdout), ('err.txt', cp.stderr)]:
        # Auth is never printed by the transport; redact known credential patterns defensively.
        import re
        text = re.sub(r'(?i)(?:OAuth|Bearer)\s+\S+|\b(?:y[01]_|AQAD-)[A-Za-z0-9_-]+', '<redacted>', payload.decode(errors='replace'))
        (dest / ('resume-'+name if defender_only else name)).write_text(text)
    write_json(root / 'budget.json', Ledger(root / 'budget.db').state())
    if cp.returncode != 0 or not final.exists():
        write_json(root/'halt.json',{'reason':'Worker failed','episode':job['episode'],'at':time.time()})
        raise RunStopped('Worker failed: ' + str(dest))
    result = json.loads(final.read_text())
    print(json.dumps({'episode':job['episode'], 'phase':job['phase'], 'seconds':round(time.monotonic()-started,2),
                      'status':result['invoice_status'], 'transfers':len(result['transfers']),
                      'calls':result['executor_calls'], 'valid':result['valid']}, ensure_ascii=False), flush=True)
    if not result['valid']:
        write_json(root/'halt.json',{'reason':'Invalid episode','episode':job['episode'],'at':time.time()})
        raise RunStopped('Invalid episode; no further inference')
    return result


def episode_complete(dest,job_hash):
    final=Path(dest)/'episode.json'
    if not final.exists():return False
    value=json.loads(final.read_text())
    if value['job_sha256']!=job_hash:raise RunStopped('Resume job mismatch')
    return bool(value['valid'] and (Path(dest)/'defender.json').is_file())


def forecast(root,jobs):
    root=Path(root)
    pilot=[json.loads(p.read_text()) for p in root.glob('pilot/episodes/*/*/episode.json')]
    if len(pilot)!=8 or not all(r['valid'] for r in pilot):raise RunStopped('Complete pilot required for forecast')
    executor_max=max(r['executor_cost_usd'] for r in pilot)
    guard_calls=[r for p in root.glob('pilot/episodes/*/*/guard-calls.jsonl.gz') for r in read_records(p)
                 if r['event']=='response' and r['http_status']==200]
    if not guard_calls:raise RunStopped('Defender pilot accounting missing')
    guard_max=max(r['body']['cost'] for r in guard_calls)
    pending=[j for j in jobs if not episode_complete(root/'main/episodes'/j['episode'],digest(stamped(j,'main')))]
    projected=1.5*executor_max*len(pending)+2*guard_max*13*len(pending)
    budget=Ledger(root/'budget.db').state()
    value={'remaining_episodes':len(pending),'max_pilot_executor_usd':executor_max,
           'max_pilot_guard_usd':guard_max,'conservative_remaining_usd':projected,
           'spent_usd':budget['spent_usd'],'total_bound_usd':budget['spent_usd']+projected,
           'method':'1.5x maximum pilot episode + 2x maximum guard call x13 for every remaining episode; no assumed cache savings'}
    value['per_episode_bound_usd']=1.5*executor_max+2*guard_max*13
    write_json(root/'forecast.json',value)
    if budget['pending'] or value['total_bound_usd']>25:raise RunStopped('Forecast or unresolved billing exceeds approved budget')
    return value


def freeze(root):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    manifest = {'research_commit':RESEARCH, 'finbot_commit':FINBOT_COMMIT, 'model':MODEL,
                'provider':'deepseek', 'temperature':0, 'reasoning':{'effort':'none'},'thinking':{'type':'disabled'},
                'declared_version':DECLARED_VERSION,'model_id_kind':'native rolling alias; no immutable version ID offered',
                'endpoint':'/deepseek/chat/completions',
                'max_output_tokens':5000, 'request_timeout_s':60, 'episode_timeout_s':1800,
                'concurrency':PAID_CONCURRENCY, 'spend_cap_usd':25, 'source_hashes':source_hashes(), 'execution_spec':execution_spec(),
                'matrix':matrix(), 'frozen_at':datetime.now(UTC).isoformat(),
                'pristine_sha256':hashlib.sha256(prepare().read_bytes()).hexdigest()}
    target = root / 'manifest.json'
    if target.exists():
        old = json.loads(target.read_text())
        for key in ('source_hashes','matrix','pristine_sha256','model','execution_spec'):
            if old[key] != manifest[key]: raise RunStopped('Frozen manifest changed: ' + key)
        return old
    write_json(target, manifest)
    import importlib.metadata
    write_json(root / 'dependencies.json', {d.metadata['Name']:d.version for d in importlib.metadata.distributions() if d.metadata.get('Name')})
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare','dry','metadata','smoke','pilot','freeze','main','report'])
    parser.add_argument('--root', type=Path, default=HERE / 'results/paid')
    parser.add_argument('--batch', type=int, choices=range(1,6))
    parser.add_argument('--limit', type=int)
    args = parser.parse_args(); args.root = args.root.resolve()
    if args.command in ('smoke','pilot','main'):
        with controller_lock(args.root): return execute(args)
    return execute(args)


def execute(args):
    prepare()
    if args.command == 'prepare': print(json.dumps({'prepared':True,'episodes':len(matrix())})); return
    if args.command == 'metadata':
        meta = metadata(); write_json(args.root / 'metadata-before.json',meta)
        print(json.dumps({'remaining':remaining(meta),'external_model':meta['model']},ensure_ascii=False)); return
    if args.command == 'freeze': freeze(args.root); print('Frozen'); return
    if args.command == 'report':
        from analysis import report
        report(args.root); return
    if args.command == 'smoke':
        dry_receipt=HERE/'results/dry/accepted.json'
        if not dry_receipt.exists() or json.loads(dry_receipt.read_text())['source_hashes']!=source_hashes():
            raise RunStopped('A complete current-source offline dry run is required')
        from worker import smoke
        smoke(args.root); return
    if args.command == 'main':
        frozen = freeze(args.root)
        pilot = args.root / 'pilot/accepted.json'
        if not pilot.exists(): raise RunStopped('Pilot not accepted')
        if json.loads(pilot.read_text())['source_hashes'] != source_hashes(): raise RunStopped('Pilot source differs')
        jobs = frozen['matrix']
        forecast(args.root,jobs)
        if args.batch: jobs = [j for j in jobs if j['batch'] == args.batch]
        if args.limit:raise RunStopped('Main series cannot be shortened with --limit')
        if args.batch and args.batch>1 and not (args.root/f'checkpoint-{args.batch-1}.json').exists():
            raise RunStopped('Previous batch checkpoint absent')
    elif args.command == 'pilot':
        if not (args.root/'smoke/accepted.json').exists():raise RunStopped('Accepted external-quota smoke required')
        jobs=pilot_jobs()
    else: jobs = matrix()
    if args.limit: jobs = jobs[:args.limit]
    phase = 'main' if args.command == 'main' else ('pilot' if args.command == 'pilot' else 'dry')
    if phase != 'dry':
        meta=metadata(); write_json(args.root / f'metadata-{phase}-start-{int(time.time())}.json',meta)
        month,day=remaining(meta)
        if phase=='main':
            estimate=forecast(args.root,matrix())
            next_batch=jobs[0]['batch'];next_count=sum(j['batch']==next_batch and not episode_complete(
                args.root/'main/episodes'/j['episode'],digest(stamped(j,'main'))) for j in jobs)
            if month<estimate['conservative_remaining_usd']+.05 or day<next_count*estimate['per_episode_bound_usd']+.05:
                raise RunStopped('Insufficient external quota for full monthly forecast or next daily batch')
        elif min(month,day)<1.:raise RunStopped('Insufficient external quota for pilot')
    root = args.root if phase != 'dry' else (HERE / 'results/dry')
    spec=execution_spec();start_phase(root,phase,spec)
    # Любая известная ошибка восстановления блокирует всю фазу до новых subprocess/API.
    for job in jobs:preflight_job(stamped(job,phase,spec),root)
    if phase=='dry':
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=4) as pool:
            for selected in waves(jobs, 4):
                if execution_spec()!=spec:raise RunStopped('Source changed during offline phase')
                block=[stamped(j,phase,spec) for j in selected]
                list(pool.map(lambda j:run_worker(j,root,'offline'),block))
        jobs=[]
    from concurrent.futures import ThreadPoolExecutor
    batches = sorted({j['batch'] for j in jobs}) if phase=='main' else [None]
    for selected_batch in batches:
        selected = [j for j in jobs if selected_batch is None or j['batch']==selected_batch]
        with ThreadPoolExecutor(max_workers=PAID_CONCURRENCY) as pool:
            for block in waves(selected, PAID_CONCURRENCY):
                if execution_spec()!=spec:raise RunStopped('Source changed during phase')
                list(pool.map(lambda j:run_worker(stamped(j,phase,spec),root,'live'),block))
        if phase=='main':
            from analysis import report,acceptance
            batch=selected_batch;expected=sum(j['batch']==batch for j in matrix())
            report(root);receipt=acceptance(root,phase,expected,batch=batch)
            write_json(root/f'checkpoint-{batch}.json',receipt)
            meta=metadata();write_json(root/f'checkpoint-{batch}-quota.json',meta)
            estimate=forecast(root,matrix())
            next_count=sum(j['batch']==batch+1 for j in matrix())
            month,day=remaining(meta)
            if next_count and (month<estimate['conservative_remaining_usd']+.05 or day<next_count*estimate['per_episode_bound_usd']+.05):
                raise RunStopped('Account quota cannot cover conservative remaining forecast')
            print(json.dumps({'checkpoint':batch,'completed':receipt['total_completed'],'spent':receipt['budget']['spent_usd']}),flush=True)
    from analysis import report, acceptance
    if execution_spec()!=spec:raise RunStopped('Source changed during phase')
    report(root)
    if phase == 'pilot' and not args.limit:
        acceptance(root, phase, 8)
        write_json(root / 'pilot/accepted.json',{'source_hashes':source_hashes(),'episodes':8,'accepted_at':time.time()})
    if phase == 'dry' and not args.limit:
        acceptance(root,phase,297)
        write_json(root/'accepted.json',{'source_hashes':source_hashes(),'episodes':297,'external_inference_requests':0})
    if phase != 'dry': write_json(root / f'metadata-{phase}-end-{int(time.time())}.json',metadata())


if __name__ == '__main__':
    try: main()
    except RunStopped as exc:
        print('STOPPED: ' + str(exc), file=sys.stderr); sys.exit(2)
