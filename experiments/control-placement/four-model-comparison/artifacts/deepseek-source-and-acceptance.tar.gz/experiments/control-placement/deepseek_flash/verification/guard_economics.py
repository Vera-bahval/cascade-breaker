"""Measured posthoc guard latency/cost per original rule combination."""
import csv,json
from pathlib import Path
from analysis import distribution,harmful

def build(rows,root):
    results=[]
    for version in ('v1','v2','facts'):
        labels=['input','input+R_big','boundary','boundary+rules','orchestrator','orchestrator+R_big','orchestrator+rules','final','final+R_big','rules']
        if version=='facts':labels=['boundary','boundary+rules']
        selected=[r for r in rows if r['dataset']=='funnel' and r['transfers'] and
          (harmful(r) or (r['truth']=='legit' and r['amount']<=5000))]
        for label in labels:
            samples=[];queries={}
            for r in selected:
                d=json.loads((root/'main/episodes'/r['episode']/'defender.json').read_text())
                if label.startswith('input'):refs=d['votes'];logical=1
                elif label.startswith('boundary'):
                    refs=[d['views'][version+':b_'+a] for a in ('invoice','fraud') if version+':b_'+a in d['views']];logical=2
                elif label.startswith('orchestrator'):refs=[d['views'][version+':orch']];logical=1
                elif label.startswith('final'):refs=[d['views'][version+':final']];logical=1
                else:refs=[];logical=0
                for ref in refs:queries[ref['query_id']]=ref
                samples.append({'episode':r['episode'],'logical_checks':logical,'model_calls':len(refs),
                  'latency_s':sum(ref['latency_s'] for ref in refs),'cost_usd':sum(ref['cost_usd'] for ref in refs),
                  'query_ids':[ref['query_id'] for ref in refs]})
            results.append({'version':version,'variant':label,'episodes':len(samples),
              'logical_checks_per_episode':distribution([x['logical_checks'] for x in samples]),
              'model_calls_per_episode':distribution([x['model_calls'] for x in samples]),
              'added_latency_s':distribution([x['latency_s'] for x in samples]),
              'cost_per_episode_usd':distribution([x['cost_usd'] for x in samples]),
              'distinct_queries':len(queries),'cost_unique_queries_usd':sum(x['cost_usd'] for x in queries.values()),
              'samples':samples})
    return {'counterfactual_only':True,'scope':'Same paid mixed-set harm/honest subset as original levels comparison',
      'input_voting':'One logical input check consists of three sequential model requests; sum latency/cost retained',
      'combination_evaluation':'Original precomputed OR rules; no assumed short-circuiting; sums of individual measured request durations are estimates of added checking time, not observed live workflow latency',
      'variants':results}

def save(value,root):
    (root/'guard-variant-economics.json').write_text(json.dumps(value,ensure_ascii=False,indent=2))
    flat=[]
    for row in value['variants']:
        item={k:row[k] for k in ['version','variant','episodes','distinct_queries','cost_unique_queries_usd']}
        for field in ['logical_checks_per_episode','model_calls_per_episode','added_latency_s','cost_per_episode_usd']:
            for metric,number in row[field].items():item[field+'_'+metric]=number
        flat.append(item)
    with (root/'guard-variant-economics.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
