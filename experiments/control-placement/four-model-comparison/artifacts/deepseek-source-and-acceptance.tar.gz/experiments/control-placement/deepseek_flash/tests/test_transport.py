import asyncio
import gzip
import json
import tempfile
import unittest
from pathlib import Path

import httpx


def envelope(**updates):
    x = {
        'cost': 0.0002, 'attempt_count': 1,
        'stats': {'model_family': 'deepseek', 'provider': 'api', 'pool': ''},
        'response': {
            'id': 'resp_test', 'object': 'response', 'created_at': 1,
            'model': 'deepseek-flash', 'status': 'completed',
            'output': [{'type': 'message', 'id': 'msg_1', 'role': 'assistant',
                        'status': 'completed', 'content': [{'type': 'output_text', 'text': 'OK', 'annotations': []}]}],
            'usage': {'input_tokens': 10, 'output_tokens': 1, 'total_tokens': 11,
                      'input_tokens_details': {'cached_tokens': 0},
                      'output_tokens_details': {'reasoning_tokens': 0}},
        },
    }
    x.update(updates)
    return x


def native_fixture(value):
    if not isinstance(value,dict) or not isinstance(value.get('response'),dict):return value
    r=value['response']
    if r.get('object')!='response':return value
    content=''.join(c.get('text','') for item in r.get('output',[]) if item.get('type')=='message' for c in item.get('content',[]))
    calls=[{'id':item.get('call_id'),'type':'function','function':{'name':item.get('name'),'arguments':item.get('arguments')}}
           for item in r.get('output',[]) if item.get('type')=='function_call']
    message={'role':'assistant','content':content or None}
    if calls:message['tool_calls']=calls
    wire={k:v for k,v in r.items() if k not in ('output','usage','status')}
    wire.update(object='chat.completion',created=1,choices=[{'index':0,'message':message,
        'finish_reason':'length' if r.get('status')!='completed' else ('tool_calls' if calls else 'stop')}])
    if 'usage' in r:
        u=r['usage'];wire['usage']={'prompt_tokens':u.get('input_tokens'),'completion_tokens':u.get('output_tokens'),
            'total_tokens':u.get('total_tokens'),'prompt_tokens_details':u.get('input_tokens_details',{}),
            'completion_tokens_details':u.get('output_tokens_details',{})}
    return dict(value,response=wire)


class TransportTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def run_request(self, value=None, status=200, failure=None):
        from transport import Ledger, RecordedTransport
        self.ledger = Ledger(self.root / 'budget.db')
        def respond(request):
            self.sent = json.loads(request.content)
            self.sent_url=request.url
            if failure:
                raise failure
            return httpx.Response(status, json=native_fixture(envelope() if value is None else value))
        transport = RecordedTransport(self.root / 'calls.jsonl.gz', self.ledger,
                                      {'phase': 'smoke', 'episode': 'test', 'role': 'executor'},
                                      upstream=httpx.MockTransport(respond), token='secret-not-for-journal')
        async def run():
            async with httpx.AsyncClient(transport=transport) as c:
                return await c.post('https://api.eliza.yandex.net/deepseek/responses',
                                    json={'model': 'wrong', 'input': 'Hello', 'temperature': 1})
        return asyncio.run(run())

    # Обёртка раскрывается без потери стоимости и параметров провайдера.
    def test_records_cost_and_unwraps_response(self):
        r = self.run_request()
        self.assertEqual(r.json()['id'], 'resp_test')
        self.assertEqual(self.sent['model'], 'deepseek-flash')
        self.assertEqual(self.sent['temperature'], 0)
        self.assertEqual(self.sent['thinking'], {'type': 'disabled'})
        self.assertEqual(self.sent['reasoning_effort'],'none')
        self.assertNotIn('provider',self.sent)
        self.assertEqual(self.sent_url.path,'/deepseek/chat/completions')
        self.assertAlmostEqual(self.ledger.state()['spent_usd'], 0.0002)
        data = gzip.open(self.root / 'calls.jsonl.gz', 'rt').read()
        self.assertNotIn('secret-not-for-journal', data)
        self.assertIn('input_tokens', data)

    # Неизвестная стоимость удерживает резерв и запрещает следующие вызовы.
    def test_missing_cost_retains_reservation(self):
        from transport import RunStopped
        value = envelope(); del value['cost']
        with self.assertRaises(RunStopped): self.run_request(value)
        self.assertGreater(self.ledger.state()['reserved_usd'], 0)
        with self.assertRaises(RunStopped): self.ledger.reserve('next', 'smoke', 0.001)

    # Таймаут после отправки не превращается в бесплатный повтор.
    def test_timeout_is_unknown_and_stops(self):
        from transport import RunStopped
        with self.assertRaises(RunStopped):
            self.run_request(failure=httpx.ReadTimeout('after send'))
        self.assertEqual(self.ledger.state()['pending'], 1)

    # Серверные отказы сохраняются, но сами не повторяются.
    def test_http_failures_stop_without_retry(self):
        from transport import RunStopped
        for code in (401, 403, 429, 500, 503):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as tmp:
                self.root = Path(tmp)
                with self.assertRaises(RunStopped): self.run_request({'error': 'rejected'}, status=code)

    # Обрезанный ответ и отсутствующий usage не допускаются к инструментам.
    def test_incomplete_or_missing_usage_stops_after_accounting(self):
        from transport import RunStopped
        for mode in ('incomplete', 'usage', 'empty', 'bad_tool', 'reasoning'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                self.root = Path(tmp); value = envelope()
                if mode == 'incomplete': value['response']['status'] = 'incomplete'
                if mode == 'usage': del value['response']['usage']
                if mode == 'empty': value['response']['output'] = []
                if mode == 'bad_tool': value['response']['output'] = [{'type':'function_call','name':'x','arguments':'broken'}]
                if mode == 'reasoning': value['response']['usage']['output_tokens_details']['reasoning_tokens'] = 100
                with self.assertRaises(RunStopped): self.run_request(value)
                self.assertAlmostEqual(self.ledger.state()['spent_usd'], 0.0002)

    # Общий и пилотный пределы включают незавершённые запросы.
    def test_budget_survives_reopen_and_bounds_pilot(self):
        from transport import Ledger, RunStopped
        db = self.root / 'cost.db'; l = Ledger(db)
        l.reserve('a', 'smoke', 0.09); l.complete('a', 0.09)
        with self.assertRaises(RunStopped): l.reserve('b', 'smoke', 0.02)
        l.reserve('c', 'pilot', 0.9); l.complete('c', 0.9)
        with self.assertRaises(RunStopped): Ledger(db).reserve('d', 'pilot', 0.02)
        with self.assertRaises(RunStopped): Ledger(db, cap=1).reserve('e', 'main', .02)
        with self.assertRaises(RunStopped): Ledger(db).reserve('f', 'main', 14.6)

    # Повторный ID запроса не допускает повторного списания.
    def test_duplicate_request_id_rejected(self):
        from transport import Ledger, RunStopped
        l = Ledger(self.root / 'cost.db'); l.reserve('a', 'main', 0.01); l.complete('a', 0.001)
        with self.assertRaises(RunStopped): l.reserve('a', 'main', 0.01)

    # Даже оплаченный протокольный сбой требует разбора перед продолжением.
    def test_protocol_failure_halts_following_requests(self):
        from transport import Ledger,RunStopped
        l=Ledger(self.root/'halt.db');l.reserve('a','main',.01);l.complete('a',.001);l.unknown('a','bad protocol')
        with self.assertRaises(RunStopped):l.reserve('b','main',.01)

    # HTML/оборванный JSON сохраняется до декодирования и не оплачивается повторно.
    def test_raw_invalid_response_preserved(self):
        from transport import Ledger,RecordedTransport,RunStopped,read_records
        ledger=Ledger(self.root/'raw.db')
        tr=RecordedTransport(self.root/'raw.gz',ledger,{'phase':'smoke'},token='secret',
            upstream=httpx.MockTransport(lambda r:httpx.Response(502,content=b'<html>broken',headers={'x-request-id':'abc'})))
        async def run():
            async with httpx.AsyncClient(transport=tr) as c:
                await c.post('https://api.eliza.yandex.net/deepseek/responses',json={'input':'x'})
        with self.assertRaises(RunStopped):asyncio.run(run())
        raw=next(r for r in read_records(self.root/'raw.gz') if r['event']=='http_response')
        self.assertEqual((raw['http_status'],raw['request_id'],raw['raw_body']),(502,'abc','<html>broken'))
        self.assertEqual(ledger.state()['pending'],1)

    # После рестарта неизвестный запрос требует сохранённой сверки, а не нового списания.
    def test_crash_reconciliation_and_reopen(self):
        from transport import Ledger,RunStopped,write_json
        path=self.root/'crash.db';ledger=Ledger(path);ledger.reserve('sent','main',.01)
        with self.assertRaises(RunStopped):Ledger(path).reserve('retry','main',.01)
        evidence=self.root/'readback.json';write_json(evidence,{'request_id':'sent','verified_cost':.002})
        Ledger(path).reconcile('sent',.002,evidence)
        self.assertAlmostEqual(Ledger(path).state()['spent_usd'],.002)
        with self.assertRaises(RunStopped):Ledger(path).reserve('sent','main',.01)

    # Маскирование текста не повреждает JSON-структуру журнала.
    def test_credential_shaped_model_text_preserves_json(self):
        from transport import read_records
        value=envelope();value['response']['output'][0]['content'][0]['text']='Bearer example-token'
        self.run_request(value)
        rows=read_records(self.root/'calls.jsonl.gz')
        response=next(r for r in rows if r['event']=='response')
        self.assertEqual(response['body']['response']['choices'][0]['message']['content'],'<redacted>')


if __name__ == '__main__': unittest.main()
