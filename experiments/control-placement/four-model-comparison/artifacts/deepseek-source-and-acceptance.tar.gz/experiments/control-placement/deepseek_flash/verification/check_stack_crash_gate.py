"""A paid journal tail or recovery marker must prevent another continuation."""
import json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from recover_stack import validate_unmodified,RunStopped,PKG
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp);source=root/'source';dest=root/'live';proof=root/'proof'
 source.mkdir();dest.mkdir()
 for name in ['calls.jsonl.gz','hooks.jsonl']:
  (source/name).write_bytes(b'original');(dest/name).write_bytes(b'original')
 validate_unmodified(source,dest,proof)
 (dest/'calls.jsonl.gz').write_bytes(b'original-plus-returned-paid-response')
 try:validate_unmodified(source,dest,proof)
 except RunStopped:pass
 else:raise AssertionError('Returned paid response would be submitted twice')
 (dest/'calls.jsonl.gz').write_bytes(b'original');proof.mkdir();(proof/'before-live.json').write_text('{}')
 try:validate_unmodified(source,dest,proof)
 except RunStopped:pass
 else:raise AssertionError('Prior recovery marker accepted')
(PKG/'verification/stack-crash-gates-accepted.json').write_text(json.dumps({'accepted':True,
 'cases':['clean accepted','paid journal tail rejected','prior recovery marker rejected'],'external_calls':0}))
