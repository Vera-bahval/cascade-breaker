"""Local-only export; does not import or modify the frozen inference runner."""
import argparse
import ast
import csv
import fcntl
import re
import gzip
import hashlib
import json
import shutil
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def records(path):
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            if line.strip(): yield json.loads(line)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def transfer_exports(root, destination):
    attempts, completed = [], []
    for path in root.glob('*/episodes/*/*/episode.json'):
        episode = json.loads(path.read_text())
        context = {key: episode[key] for key in ('phase','episode','dataset','scenario_id','repeat','batch','truth')}
        with path.with_name('hooks.jsonl').open() as stream:
            hooks = [json.loads(line) for line in stream if line.strip()]
        successful = {}
        for hook in hooks:
            if hook.get('tool_name') != 'finstripe__create_transfer': continue
            arguments = hook.get('tool_arguments') or {}
            if hook.get('hook_kind') == 'before_tool':
                attempts.append(dict(context, timestamp=hook.get('timestamp'), arguments=arguments,
                                     amount=arguments.get('amount'),invoice_id=arguments.get('invoice_id'),
                                     vendor_id=arguments.get('vendor_id'),
                                     recipient_account=arguments.get('vendor_account')))
            if hook.get('hook_kind') != 'after_tool': continue
            value = hook.get('tool_result')
            if isinstance(value, str):
                try: value = json.loads(value)
                except (ValueError, TypeError):
                    try: value = ast.literal_eval(value)
                    except (ValueError, SyntaxError): value = None
            if isinstance(value, dict) and value.get('transfer_id'):
                successful[value['transfer_id']] = value
        for transfer in episode['transfers']:
            observed = successful.get(transfer.get('transfer_id'), {})
            candidates = [row['arguments'].get('vendor_account') for row in attempts
                if row['phase']==episode['phase'] and row['episode']==episode['episode']
                and row['arguments'].get('invoice_id')==transfer.get('invoice_id')
                and row['arguments'].get('amount')==transfer.get('amount')]
            completed.append(dict(context, transaction=transfer,
                amount=transfer.get('amount'),currency=transfer.get('currency'),
                invoice_id=transfer.get('invoice_id'),vendor_id=transfer.get('vendor_id'),
                transfer_id=transfer.get('transfer_id'),status=transfer.get('status'),
                recipient_account=observed.get('vendor_account'),
                recipient_source='FinStripe tool result matched by transfer_id' if observed.get('vendor_account') else 'unavailable; candidate tool arguments retained separately',
                candidate_accounts=candidates))
    for name, rows in [('transfer-attempts', attempts), ('completed-transfers', completed)]:
        save(destination / (name+'.json'), rows)
        if rows:
            with (destination / (name+'.csv')).open('w') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader()
                for row in rows:writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()})


def export(root, checkpoint):
    destination = root / 'checkpoints' / checkpoint
    destination.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(root / 'budget.db') as db:
        db.row_factory = sqlite3.Row
        billing = [dict(r) for r in db.execute('SELECT * FROM requests ORDER BY rowid')]
        assert all(r['cost'] is not None and r['status'] == 'completed' for r in billing), 'Unsettled requests'
        with tempfile.TemporaryDirectory() as tmp:
            backup = Path(tmp) / 'budget.sqlite'
            with sqlite3.connect(backup) as target: db.backup(target)
            with backup.open('rb') as source, gzip.open(destination / 'budget.sqlite.gz', 'wb') as target:
                shutil.copyfileobj(source, target)
    save(destination / 'billing-ledger.json', billing)
    bills = {row['id']: row for row in billing}
    requests = {}; journals = list(root.glob('*/episodes/*/*/*calls.jsonl.gz'))
    journals += list(root.glob('history/**/*calls.jsonl.gz'))
    journals += list(root.glob('smoke/*calls.jsonl.gz'))
    journals += list(root.glob('archived-openrouter-smoke/*calls.jsonl.gz'))
    for journal in journals:
        job_file=journal.parent/'job.json'
        job=json.loads(job_file.read_text()) if job_file.is_file() else {}
        cohort = 'sequential-preliminary' if 'history' in journal.relative_to(root).parts else (
            'rejected-openrouter-smoke' if 'archived-openrouter-smoke' in journal.relative_to(root).parts else 'current')
        for item in records(journal):
            identity = item['attempt_id']
            slot = requests.setdefault(identity, {'source_journal': str(journal.relative_to(root)), 'cohort': cohort, 'job':job})
            assert slot['source_journal'] == str(journal.relative_to(root)), 'Duplicate attempt across journals'
            assert item['event'] not in slot, 'Duplicate event for one paid attempt'
            slot[item['event']] = item
    assert set(requests) == set(bills), 'Ledger and request identities differ'
    compact = []
    with gzip.open(destination / 'requests.jsonl.gz', 'wt') as full:
        for identity, events in requests.items():
            sent = events.get('request', {}); response = events.get('response', {})
            body = response.get('body') or {}; native = body.get('response') or {}
            usage = native.get('usage') or {}; accounting = events.get('accounting', {})
            http = events.get('http_response', {})
            wire = sent.get('request') or sent.get('body') or {}
            cost = bills[identity]['cost']
            row = dict(attempt_id=identity, cohort=events['cohort'], source_journal=events['source_journal'],
                phase=sent.get('phase'), episode=sent.get('episode'), role=sent.get('role'),
                dataset=events['job'].get('dataset'),scenario_id=events['job'].get('scenario',{}).get('id'),
                repeat=events['job'].get('repeat'),batch=events['job'].get('batch'),
                truth=events['job'].get('scenario',{}).get('truth'),amount=events['job'].get('scenario',{}).get('amount'),
                execution_fingerprint=events['job'].get('execution_fingerprint'),
                agent=sent.get('agent'), view=sent.get('view'), guard_query=sent.get('guard_query'),
                request_utc=sent.get('utc'), response_utc=response.get('utc', http.get('utc')),
                endpoint=sent.get('endpoint'), sdk_endpoint=sent.get('sdk_endpoint'),
                requested_model=wire.get('model'), served_model=native.get('model'),
                declared_version=sent.get('declared_native_version'), temperature=wire.get('temperature'),
                thinking=wire.get('thinking'), reasoning_effort=wire.get('reasoning_effort'),
                max_output_tokens=wire.get('max_tokens', wire.get('max_output_tokens')),
                http_status=response.get('http_status', http.get('http_status')),
                attempt_count=body.get('attempt_count'), eliza_request_id=body.get('request_id', http.get('request_id')),
                provider_response_id=native.get('id'),served_system_fingerprint=native.get('system_fingerprint'),
                eliza_usage=body.get('usage'),eliza_cost_info=body.get('cost_info'),
                eliza_cost_details=body.get('cost_details'),eliza_stats=body.get('stats'),
                input_tokens=usage.get('prompt_tokens', usage.get('input_tokens')),
                output_tokens=usage.get('completion_tokens', usage.get('output_tokens')), total_tokens=usage.get('total_tokens'),
                cached_tokens=accounting.get('cached_tokens'), cache_miss_tokens=usage.get('prompt_cache_miss_tokens'),
                reasoning_tokens=accounting.get('reasoning_tokens'), eliza_cost_usd=cost,
                provider_cost_usd=accounting.get('provider_cost_usd'), reserve_usd=bills[identity]['reserve'],
                latency_s=response.get('latency_s', http.get('latency_s', events.get('error',{}).get('latency_s'))),
                eliza_elapsed_time_ms=body.get('elapsed_time_ms'),
                eliza_last_request_duration_ms=body.get('last_request_duration_ms'),
                error=events.get('error', {}).get('error'), billing_note=bills[identity]['note'],
                unavailable_fields=accounting.get('unavailable_fields', ['API accounting unavailable; use original journal and billing evidence']))
            compact.append(row)
            full.write(json.dumps({'metadata': row, 'events': events}, ensure_ascii=False, allow_nan=False) + '\n')
    assert abs(sum(row['eliza_cost_usd'] for row in compact) - sum(row['cost'] for row in billing)) < 1e-9
    with (destination / 'requests.csv').open('w') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(compact[0]))
        writer.writeheader()
        for row in compact:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in row.items()})
    for name in ('summary.json', 'episodes.json', 'episodes.csv', 'REPORT.md', 'manifest.json',
                 'dependencies.json', 'forecast.json', 'COMPARISON.md', 'comparison.json', 'episode-diagnostics.json', 'episode-diagnostics.csv', 'guard-variant-economics.json', 'guard-variant-economics.csv', f'checkpoint-{checkpoint.removeprefix("batch-")}.json',
                 f'checkpoint-{checkpoint.removeprefix("batch-")}-quota.json'):
        source = root / name
        if source.is_file(): shutil.copy2(source, destination / name)
    for name in ('historical-reference.json','historical-token-accounting.json'):
        source=root.parent/name
        if source.is_file():shutil.copy2(source,destination/name)
    transfer_exports(root, destination)
    inventory = {str(p.relative_to(destination)): {'bytes': p.stat().st_size,
        'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in destination.iterdir() if p.is_file() and p.name!='export-receipt.json'}
    save(destination / 'export-receipt.json', {'checkpoint': checkpoint,
        'at': datetime.now(timezone.utc).isoformat(), 'requests': len(compact),
        'spent_usd': sum(row['cost'] for row in billing), 'files': inventory,
        'exporter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'missing_values': 'null/empty CSV cell means unavailable, never zero by implication'})
    print(json.dumps({'exported': checkpoint, 'requests': len(compact),
                      'spent_usd': sum(row['cost'] for row in billing)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkpoint'); parser.add_argument('--root', type=Path,
        default=Path(__file__).resolve().parents[1] / 'results/paid')
    arguments = parser.parse_args()
    root=arguments.root.resolve()
    with (root/'controller.lock').open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if re.fullmatch(r'batch-[1-5]',arguments.checkpoint):
            batch=int(arguments.checkpoint[-1])
            receipt=json.loads((root/f'checkpoint-{batch}.json').read_text())
            main=[json.loads(p.read_text()) for p in root.glob('main/episodes/*/*/episode.json')]
            assert len(main)==receipt['total_completed']
            assert all(r['batch']<=batch and r['valid'] for r in main)
        assert not (root/'checkpoints'/arguments.checkpoint/'export-receipt.json').exists(), 'Immutable checkpoint export already exists'
        export(root, arguments.checkpoint)
