"""Prove mismatched continuation payloads stop before reserve or dispatch."""
import asyncio,json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from resume_orchestrator import ExactContinuation,Ledger,RunStopped,httpx,write_json,PKG

class Forbidden(httpx.AsyncBaseTransport):
    async def handle_async_request(self,request):
        raise AssertionError('No HTTP dispatch is allowed in rejection fixtures')

async def main():
    with tempfile.TemporaryDirectory() as tmp:
        ledger=Ledger(Path(tmp)/'budget.db')
        for kind in ['sdk','wire']:
            tr=ExactContinuation(Path(tmp)/'calls.gz',ledger,{'phase':'main'},upstream=Forbidden(),token='fixture')
            tr.checked=False
            sdk={'model':'deepseek-flash','input':'fixture'}
            tr.saved={'sdk_request':{} if kind=='sdk' else sdk,'request_sha256':'incorrect'}
            try:await tr.handle_async_request(httpx.Request('POST','https://api.eliza.yandex.net/deepseek/responses',json=sdk))
            except RunStopped as exc:assert 'payload mismatch before reserve' in str(exc)
            else:raise AssertionError('Mismatch accepted')
            assert ledger.state()['requests']==0
        write_json(PKG/'verification/recovery-gates-accepted.json',{'accepted':True,'rejections':['SDK mismatch','wire mismatch'],
          'reserved_requests':0,'external_calls':0})
asyncio.run(main())
