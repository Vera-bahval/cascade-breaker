"""Eliza accounting boundary shared by executor, smoke and defender."""
from __future__ import annotations

import gzip
import fcntl
import hashlib
import json
import math
import os
import re
import sqlite3
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path
from contextlib import contextmanager

import httpx

MODEL = 'deepseek-flash'
DECLARED_VERSION = 'DeepSeek-V4.1-Flash-1017'
BASE_URL = 'https://api.eliza.yandex.net/deepseek'
PRICE_IN_MAX = 0.30 / 1e6
PRICE_OUT_MAX = 1.20 / 1e6


class RunStopped(BaseException):
    """Bypass FinBot's broad exception catches and automatic agent retries."""


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def write_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.'+uuid.uuid4().hex+'.tmp')
    with temp.open('w') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.flush(); os.fsync(f.fileno())
    temp.replace(path)


def append_record(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n').encode()
    # Каждый append — отдельный законченный gzip member; незавершённый хвост виден аудиту.
    with path.open('ab') as raw:
        if path.suffix == '.gz':
            with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as out: out.write(payload)
        else: raw.write(payload)
        raw.flush(); os.fsync(raw.fileno())


def read_records(path):
    path = Path(path)
    if not path.exists(): return []
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt') as f:
        return [json.loads(line) for line in f if line.strip()]


class Ledger:
    def __init__(self, path, cap=25.0):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.cap = cap
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS requests (id TEXT PRIMARY KEY, phase TEXT NOT NULL, '
                       'day TEXT NOT NULL, reserve REAL NOT NULL, cost REAL, status TEXT NOT NULL, note TEXT)')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db: yield db
        finally: db.close()

    def state(self):
        with self.connect() as db:
            rows = [dict(r) for r in db.execute('SELECT * FROM requests')]
        pending = [r for r in rows if r['cost'] is None or r['status']=='unknown']
        return {'spent_usd': sum(r['cost'] or 0 for r in rows),
                'reserved_usd': sum(r['reserve'] for r in pending if r['cost'] is None), 'pending': len(pending),
                'requests': len(rows), 'by_phase': {p: sum(r['cost'] or 0 for r in rows if r['phase'] == p)
                                                 for p in sorted({r['phase'] for r in rows})},
                'unresolved': pending}

    @contextmanager
    def request_lease(self, key):
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', key): raise RunStopped('Invalid lease identity')
        directory = self.path.resolve().parent / 'request-leases'
        directory.mkdir(exist_ok=True)
        with (directory / (key + '.lock')).open('x+b') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            try: yield
            finally: fcntl.flock(handle, fcntl.LOCK_UN)

    def active(self, key):
        path = self.path.resolve().parent / 'request-leases' / (key + '.lock')
        if not path.is_file(): return False
        with path.open('rb') as handle:
            try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError: return True
            fcntl.flock(handle, fcntl.LOCK_UN)
        return False

    def reserve(self, key, phase, worst):
        if not math.isfinite(worst) or worst <= 0: raise RunStopped('Invalid request reserve')
        day = datetime.now(UTC).date().isoformat()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if (self.path.resolve().parent / 'halt.json').exists(): raise RunStopped('Run halted; audit required')
            rows = [dict(r) for r in db.execute('SELECT * FROM requests')]
            if any(r['id'] == key for r in rows): raise RunStopped('Duplicate request identity')
            if any(r['status']=='unknown' or (r['cost'] is None and not self.active(r['id'])) for r in rows):
                raise RunStopped('Unreconciled or failed request')
            exposure = lambda r: r['reserve'] if r['cost'] is None else r['cost']
            spent = sum(exposure(r) for r in rows)
            if spent + worst > self.cap: raise RunStopped('Global USD cap')
            phase_set, phase_cap = ({'smoke'}, .10) if phase == 'smoke' else ({'smoke', 'pilot'}, 1.)
            if phase in ('smoke', 'pilot') and sum(exposure(r) for r in rows if r['phase'] in phase_set) + worst > phase_cap:
                raise RunStopped('Smoke/pilot USD cap')
            if sum(exposure(r) for r in rows if r['day'] == day) + worst > 14.5:
                raise RunStopped('Conservative daily USD cap')
            db.execute('INSERT INTO requests VALUES (?,?,?,?,NULL,?,NULL)', (key, phase, day, worst, 'reserved'))

    def complete(self, key, cost):
        if isinstance(cost, bool) or not isinstance(cost, (int, float)) or not math.isfinite(cost) or cost < 0:
            raise RunStopped('Missing or invalid authoritative Eliza cost')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM requests WHERE id=?', (key,)).fetchone()
            if row is None or row['cost'] is not None: raise RunStopped('Invalid ledger completion')
            db.execute('UPDATE requests SET cost=?,status=? WHERE id=?', (cost, 'completed', key))
            over = cost > row['reserve'] + 1e-9
        if over: raise RunStopped('Billed cost exceeds reserved upper bound')

    def unknown(self, key, note):
        with self.connect() as db:
            db.execute('UPDATE requests SET status=?,note=? WHERE id=?', ('unknown', note, key))

    def reconcile(self, key, cost, evidence):
        if not Path(evidence).is_file(): raise RunStopped('Reconciliation requires saved readback evidence')
        with self.connect() as db:
            row=db.execute('SELECT cost FROM requests WHERE id=?',(key,)).fetchone()
        if row is None:raise RunStopped('Unknown reconciliation identity')
        if row['cost'] is None:self.complete(key,cost)
        elif abs(row['cost']-cost)>1e-12:raise RunStopped('Reconciliation cannot rewrite known cost')
        with self.connect() as db:
            db.execute('UPDATE requests SET status=?,note=? WHERE id=?', ('completed','reconciled:' + str(evidence), key))


def validate_response(value, chat=False, allow_tools=False):
    if not isinstance(value, dict) or not value.get('id'): raise RunStopped('Invalid provider response')
    if value.get('model') not in (MODEL,DECLARED_VERSION.lower()): raise RunStopped('Served model differs from frozen model')
    usage = value.get('usage')
    if not isinstance(usage, dict): raise RunStopped('Missing token accounting')
    names = ('prompt_tokens', 'completion_tokens') if chat else ('input_tokens', 'output_tokens')
    if any(type(usage.get(n)) is not int or usage[n] < 0 for n in names): raise RunStopped('Invalid token counters')
    details = usage.get('completion_tokens_details' if chat else 'output_tokens_details') or {}
    if details.get('reasoning_tokens', 0): raise RunStopped('Reasoning was not disabled')
    if chat:
        choices = value.get('choices') or []
        if not choices or choices[0].get('finish_reason') not in (('stop','tool_calls') if allow_tools else ('stop',)):
            raise RunStopped('Incomplete chat completion')
        message=choices[0].get('message') or {};calls=message.get('tool_calls') or []
        if message.get('reasoning_content'):raise RunStopped('Native thinking was not disabled')
        if not message.get('content') and not (allow_tools and calls): raise RunStopped('Empty chat completion')
        for call in calls:
            fn=call.get('function') or {}
            try:args=json.loads(fn['arguments'])
            except (KeyError,ValueError,TypeError):raise RunStopped('Malformed native tool arguments')
            if not isinstance(args,dict) or not fn.get('name') or not call.get('id'):
                raise RunStopped('Malformed native tool call')
    else:
        if value.get('status') != 'completed': raise RunStopped('Incomplete Responses result')
        output = value.get('output')
        if not isinstance(output, list) or not output: raise RunStopped('Empty Responses result')
        for item in output:
            if item.get('type') == 'function_call':
                try: args = json.loads(item['arguments'])
                except (KeyError, ValueError, TypeError): raise RunStopped('Malformed tool arguments')
                if not isinstance(args, dict) or not item.get('name') or not item.get('call_id'):
                    raise RunStopped('Malformed tool call')
            elif item.get('type') == 'message':
                if any(c.get('type') == 'refusal' for c in item.get('content', [])): raise RunStopped('Provider refusal')


class RecordedTransport(httpx.AsyncBaseTransport):
    def __init__(self, path, ledger, context, *, upstream=None, token=None):
        self.path, self.ledger, self.context = Path(path), ledger, context
        self.upstream = upstream or httpx.AsyncHTTPTransport(retries=0)
        self.token = token
        self.sequence = 0

    async def aclose(self): await self.upstream.aclose()

    def mask(self, text):
        if self.token: text = text.replace(self.token, '<redacted>')
        return re.sub(r'(?i)(?:OAuth|Bearer)\s+\S+|\b(?:y[01]_|AQAD-)[A-Za-z0-9_-]+', '<redacted>', text)

    def redact(self,value):
        if isinstance(value,str):return self.mask(value)
        if isinstance(value,list):return [self.redact(v) for v in value]
        if isinstance(value,dict):return {k:self.redact(v) for k,v in value.items()}
        return value

    async def handle_async_request(self, request):
        key = str(uuid.uuid4())
        with self.ledger.request_lease(key):
            return await self._request(request, key)

    async def _request(self, request, key):
        if request.url.host != 'api.eliza.yandex.net' or request.url.path not in (
                '/deepseek/responses', '/deepseek/chat/completions'):
            raise RunStopped('Endpoint outside frozen external Eliza route')
        sdk_body = json.loads(request.content)
        chat = request.url.path.endswith('/chat/completions')
        from native_adapter import chat_request,as_responses
        body=dict(sdk_body) if chat else chat_request(sdk_body)
        body.pop('reasoning',None);body.pop('provider',None)
        body.update(model=MODEL,temperature=0,thinking={'type':'disabled'},reasoning_effort='none',
                    stream=False,max_tokens=5000)
        wire_url=request.url.copy_with(path='/deepseek/chat/completions')
        payload = json.dumps(body, ensure_ascii=False).encode()
        # UTF-8 bytes bound text tokens conservatively; tools and formatting are included.
        worst = (len(payload) + 1024) * PRICE_IN_MAX + 5000 * PRICE_OUT_MAX
        self.sequence += 1
        self.ledger.reserve(key, self.context['phase'], worst)
        record = dict(self.context, attempt_id=key, call=self.sequence, event='request',
                      utc=datetime.now(UTC).isoformat(), endpoint=wire_url.path,sdk_endpoint=request.url.path,
                      sdk_request=sdk_body,declared_native_version=DECLARED_VERSION,
                      request=body, request_sha256=digest(body), reserved_usd=worst,
                      eliza_headers={'X-Retries':'1','X-Request-Timeout':'60s'})
        append_record(self.path, record)
        headers = dict(request.headers)
        if self.token is None:
            import sys
            sys.path.insert(0, str(Path.home() / '.agents/skills/store/scripts'))
            from agent_auth_client import resolve
            self.token = resolve('eliza', store=True)
        headers['authorization'] = 'OAuth ' + self.token
        headers['x-retries']='1'
        headers['x-request-timeout']='60s'
        headers.pop('content-length', None)
        outbound = httpx.Request(request.method, wire_url, headers=headers, content=payload,
                                 extensions=request.extensions)
        started = time.perf_counter()
        try:
            response = await self.upstream.handle_async_request(outbound)
            raw = await response.aread()
            latency = time.perf_counter() - started
            # Сохраняем повреждённый ответ до JSON parsing, включая диагностический request ID.
            append_record(self.path, dict(self.context, attempt_id=key, call=self.sequence,
                event='http_response', http_status=response.status_code, latency_s=latency,
                request_id=response.headers.get('x-request-id'),
                headers={k:v for k,v in response.headers.items() if k.lower() in
                         ('x-request-id','x-eliza-request-id','content-type','retry-after')},
                raw_body=self.mask(raw.decode('utf-8',errors='replace')),
                utc=datetime.now(UTC).isoformat()))
            value = json.loads(raw)
            terminal = dict(self.context, attempt_id=key, call=self.sequence, event='response',
                            utc=datetime.now(UTC).isoformat(), http_status=response.status_code,
                            latency_s=latency, ttft_s=None, ttft_unavailable='non-streaming protocol',
                            body=value)
            # Не сохраняем идентификатор ключа Eliza: для воспроизводимости достаточно cost/stats.
            if isinstance(value, dict): terminal['body'] = {k: v for k, v in value.items() if k != 'key'}
            append_record(self.path, self.redact(terminal))
            if response.status_code != 200:
                raise RunStopped('HTTP ' + str(response.status_code))
            if not isinstance(value, dict): raise RunStopped('Invalid Eliza envelope')
            self.ledger.complete(key, value.get('cost'))
            if value.get('attempt_count')!=1:raise RunStopped('Unexpected Eliza retry count')
            inner = value.get('response')
            validate_response(inner,True,allow_tools=not chat)
            sdk_response=inner if chat else as_responses(inner)
            if not chat:
                validate_response(sdk_response)
                append_record(self.path,self.redact(dict(self.context,event='sdk_response',attempt_id=key,
                    body=sdk_response,adapter='native-chat-to-responses-v1')))
            stats = value.get('stats') or {}
            if stats.get('model_family') not in (None, 'deepseek') or stats.get('pool'):
                raise RunStopped('Unexpected Eliza account family or pool')
            provider=inner.get('provider')
            if provider and provider.lower()!='deepseek':raise RunStopped('Unexpected inference provider')
            usage=inner['usage'];details=usage.get('completion_tokens_details') or {}
            append_record(self.path,dict(self.context,event='accounting',attempt_id=key,
                response_id=inner['id'],eliza_request_id=value.get('request_id'),provider=provider,
                provider_unavailable=None if provider else 'Native Eliza /deepseek route; vendor fixed by endpoint',
                input_tokens=usage.get('prompt_tokens'),output_tokens=usage.get('completion_tokens'),
                cached_tokens=usage.get('prompt_cache_hit_tokens',(usage.get('prompt_tokens_details') or {}).get('cached_tokens')),
                reasoning_tokens=details.get('reasoning_tokens'),provider_cost_usd=usage.get('cost'),
                eliza_cost_usd=value['cost'],attempt_count=value.get('attempt_count'),
                unavailable_fields=[field for field,present in {
                    'reasoning_tokens':'reasoning_tokens' in details,
                    'cached_tokens':'prompt_cache_hit_tokens' in usage or 'cached_tokens' in (usage.get('prompt_tokens_details') or {}),
                    'provider_cost_usd':'cost' in usage,'eliza_request_id':'request_id' in value}.items() if not present]))
            return httpx.Response(200, json=sdk_response, headers={'content-type': 'application/json'})
        except BaseException as exc:
            self.ledger.unknown(key, self.mask(type(exc).__name__ + ': ' + str(exc))[:300])
            append_record(self.path, dict(self.context, event='error', attempt_id=key, call=self.sequence,
                                         error=self.mask(type(exc).__name__ + ': ' + str(exc))[:500],
                                         latency_s=time.perf_counter() - started))
            if isinstance(exc, RunStopped): raise
            raise RunStopped(self.mask(type(exc).__name__ + ': ' + str(exc))[:300]) from None
