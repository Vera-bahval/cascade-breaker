"""Read original request accounting from pinned archives without estimates."""
import collections,hashlib,json,tarfile
from pathlib import Path
PKG=Path(__file__).resolve().parents[1];CODE=PKG.parent/'code'
history=json.loads((PKG/'results/historical-reference.json').read_text())
ids={r['scenario_id']:r['dataset'] for r in history['models']['mini']['episodes']};assert len(ids)==227
rows=[];episodes={}
archive=CODE/'runs/finbot477_run227_t0_20261005.tar.gz'
with tarfile.open(archive) as tf:
 for member in tf.getmembers():
  if not member.name.endswith('.calls.jsonl'):continue
  sid=Path(member.name).name.removesuffix('.calls.jsonl');assert sid in ids
  calls=[json.loads(line) for line in tf.extractfile(member) if line.strip()]
  episodes[sid]={'dataset':ids[sid],'requests':len(calls),'input_tokens':0,'output_tokens':0,
    'cached_tokens':0,'reasoning_tokens':0,'api_reported_cost_usd':0.,'cost_available_requests':0}
  for row in calls:
   u=row.get('usage') or {};e=episodes[sid]
   e['input_tokens']+=u.get('input_tokens',0);e['output_tokens']+=u.get('output_tokens',0)
   e['cached_tokens']+=(u.get('input_tokens_details') or {}).get('cached_tokens',0)
   e['reasoning_tokens']+=(u.get('output_tokens_details') or {}).get('reasoning_tokens',0)
   if isinstance(u.get('cost'),(int,float)):e['api_reported_cost_usd']+=u['cost'];e['cost_available_requests']+=1
   rows.append({'scenario_id':sid,'dataset':ids[sid],'call':row['call'],'model':row['model'],
      'temperature':row.get('temperature'),'usage':u})
assert len(episodes)==227
nano_archives=[]
for name in history['source_archive_sha256']:
 if 'nanobase' in name:
  p=CODE/'runs'/name
  with tarfile.open(p) as tf:count=sum(m.name.endswith('.calls.jsonl') for m in tf.getmembers())
  nano_archives.append({'archive':name,'sha256':history['source_archive_sha256'][name],'sdk_call_journals':count})
assert all(r['sdk_call_journals']==0 for r in nano_archives)
def aggregate(items):
 out={'requests':len(items),'models':dict(collections.Counter(r['model'] for r in items)),
  'temperatures':dict(collections.Counter(str(r['temperature']) for r in items))}
 for field,detail in [('input_tokens',None),('output_tokens',None),('cached_tokens','input_tokens_details'),('reasoning_tokens','output_tokens_details'),('cost',None)]:
  values=[]
  for r in items:
   source=(r['usage'].get(detail) or {}) if detail else r['usage']
   if source.get(field) is not None:values.append(source[field])
  out[field]={'sum_available':sum(values) if values else None,'available_requests':len(values),'total_requests':len(items)}
 return out
result={'mini_executor':aggregate(rows),'mini_by_dataset':{ds:aggregate([r for r in rows if r['dataset']==ds]) for ds in ['fpr','funnel']},
 'mini_by_episode':episodes,'nano':{'request_token_accounting':None,'reason':'No SDK call journals in the three original nano archives','archives_checked':nano_archives},
 'source_archive':archive.name,'source_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'cost_kind':'Historical provider/API-reported usage.cost; distinct from fixed-rate COST_USD and not independently verified billing'}
(PKG/'results/historical-token-accounting.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result['mini_executor']))
