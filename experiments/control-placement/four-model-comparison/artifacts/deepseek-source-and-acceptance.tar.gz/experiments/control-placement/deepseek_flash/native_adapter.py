"""Stateless Responses ↔ native DeepSeek Chat translation; no business prompt changes."""
from copy import deepcopy

from transport import RunStopped


def text_content(content):
    if content is None or isinstance(content,str):return content
    if not isinstance(content,list):raise RunStopped('Unsupported message content')
    if any(p.get('type') not in ('input_text','output_text','text') or not isinstance(p.get('text'),str) for p in content):
        raise RunStopped('Native adapter accepts text only')
    return ''.join(p['text'] for p in content)


def chat_request(body):
    allowed={'model','input','instructions','temperature','max_output_tokens','tools','tool_choice',
             'parallel_tool_calls','stream','store','reasoning'}
    if set(body)-allowed or body.get('store'):
        raise RunStopped('Unsupported Responses option; never silently discard it')
    messages=[]
    if body.get('instructions'):messages.append({'role':'system','content':body['instructions']})
    items=body.get('input',[])
    if isinstance(items,str):items=[{'role':'user','content':items}]
    for item in items:
        kind=item.get('type')
        if kind=='function_call':
            if not messages or messages[-1]['role']!='assistant':messages.append({'role':'assistant','content':None})
            messages[-1].setdefault('tool_calls',[]).append({'id':item['call_id'],'type':'function',
                'function':{'name':item['name'],'arguments':item['arguments']}})
        elif kind=='function_call_output':
            messages.append({'role':'tool','tool_call_id':item['call_id'],'content':text_content(item['output'])})
        elif kind in (None,'message') and item.get('role') in ('system','developer','user','assistant'):
            messages.append({'role':'system' if item['role']=='developer' else item['role'],
                             'content':text_content(item.get('content'))})
        else:raise RunStopped('Unsupported Responses input item')
    result={'messages':messages}
    if body.get('tools'):
        tools=[]
        for tool in body['tools']:
            if tool.get('type')!='function':raise RunStopped('Unsupported native tool type')
            if set(tool)-{'type','name','description','parameters','strict'}:raise RunStopped('Unsupported tool field')
            # strict — переключатель валидации OpenAI, не часть текста/схемы инструмента.
            tools.append({'type':'function','function':{k:v for k,v in tool.items() if k in ('name','description','parameters')}})
        result['tools']=tools
    if body.get('tool_choice') is not None:
        choice=body['tool_choice']
        if choice in ('auto','none'):result['tool_choice']=choice
        else:raise RunStopped('Unsupported native tool_choice')
    if body.get('parallel_tool_calls') is not None:result['parallel_tool_calls']=body['parallel_tool_calls']
    return result


def as_responses(native):
    message=native['choices'][0]['message'];output=[];identity=native['id']
    if message.get('content'):
        output.append({'type':'message','id':'msg_'+identity,'role':'assistant','status':'completed',
                       'content':[{'type':'output_text','text':message['content'],'annotations':[]}]})
    for call in message.get('tool_calls') or []:
        output.append({'type':'function_call','id':'fc_'+call['id'],'call_id':call['id'],
                       'name':call['function']['name'],'arguments':call['function']['arguments'],'status':'completed'})
    raw=native.get('usage');usage=None
    if raw is not None:
        usage={'input_tokens':raw.get('prompt_tokens'),'output_tokens':raw.get('completion_tokens'),
               'total_tokens':raw.get('total_tokens')}
        input_details=deepcopy(raw.get('prompt_tokens_details') or {})
        if 'prompt_cache_hit_tokens' in raw:input_details['cached_tokens']=raw['prompt_cache_hit_tokens']
        if input_details:usage['input_tokens_details']=input_details
        if 'completion_tokens_details' in raw:usage['output_tokens_details']=deepcopy(raw['completion_tokens_details'])
        if 'cost' in raw:usage['cost']=raw['cost']
    return {'id':identity,'object':'response','created_at':native.get('created',0),'model':native['model'],
            'status':'completed','output':output,'usage':usage}
