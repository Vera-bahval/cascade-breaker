# DeepSeek Flash: reproduction of yurina5t's FinBot experiments

Research source: `5c2b5c3309de10b460225ee0b4edff0b90d1c35d`.
FinBot source: `a7f6964fbc60da807e2544d826a5b4e20eb0c5dc`.
The original FinBot agents, prompts and business tools are not patched.

The matrix contains 150 honest invoices once, Vera's seven scenarios ten times,
and the 77-invoice mixed set once: **297 episodes**. Every episode starts from
profile C (one trusted vendor and five paid historical invoices) in its own SQLite
file and subprocess. Money and mail are simulated by FinBot's in-process MCP tools.

Both executor and defender request `deepseek-flash` through the documented
external Eliza → DeepSeek route `/deepseek/chat/completions`, temperature zero,
thinking disabled, reasoning effort `none`, output limit 5000 and timeout 60 seconds.
The native ID is a rolling alias. DeepSeek currently declares it as
`DeepSeek-V4.1-Flash-1017`; this declaration is checked before paid phases and at
each main checkpoint. The native registry offers no immutable version ID.
The transport converts stateless Responses requests to native Chat and converts
answers back for the unchanged FinBot SDK. It retains both the original SDK
request and actual wire payload, raw native response and adapted SDK response.
Tool descriptions and parameter schemas are preserved; the OpenAI-specific
`strict` tool switch is omitted. There is no vendor fallback. SDK and Eliza
server retries are disabled (X-Retries=1). The external quota is
`chain:top_opensource`; the `deepseek` family is assigned to it by Eliza.
Credentials are resolved in RAM through `agent_auth_client.resolve('eliza', store=True)`.
Do not put a token into a file or command argument.

## Commands

Use a Python 3.13 environment with the original FinBot dependencies and `openai`,
`httpx`, `sqlalchemy`, `pytest`. The current run reuses the existing dependency
environment without changing it; exact installed versions are exported at freeze.
The archived upstream FinBot tree must be present under `.runtime/finbot`.
The upstream is `https://github.com/GenAI-Security-Project/finbot-ctf` (PR #477).
Export commit `a7f6964fbc60da807e2544d826a5b4e20eb0c5dc` with `git archive`
into `.runtime/finbot`; the actual exported sources are included in the execution
fingerprint. The current run uses the existing local Git object store at
`/Users/proskurin-dmi/Documents/hw-itmo/cascades/vendor/finbot`.

Run from this directory:

```sh
python -m unittest discover -s tests -v
python experiment.py prepare
python experiment.py dry
python experiment.py metadata
python experiment.py smoke
python experiment.py pilot
python experiment.py freeze
python experiment.py main
python experiment.py report
```

`dry` has a socket firewall allowing only loopback. It replays the archived
21-call TH601 response sequence through the real SDK, FinBot, passive HTTP hooks
and simulated business tools for every matrix job. It tests integration and
isolation, **not scenario outcomes or model quality**. Its zero-cost, synthetic
records are isolated from paid results. The first preliminary attempt exposed
FinBot's eagerly initialized SDK singleton: a dummy-key request was rejected by
OpenAI with HTTP 401 before generation. Its evidence is quarantined under
`.runtime/failed-dry-attempts/pre-singleton-fix`; the corrected path also installs
an independent socket firewall before importing FinBot.

Smoke requires a complete current-source dry receipt. Smoke has a $0.10 limit;
smoke plus eight pilot episodes have a combined $1 limit. Paid commands share one
durable SQLite ledger and a **$25 total cap**. A conservative $14.50 daily bound
leaves headroom under the account's $15 daily quota. Every outbound request is
journaled and reserved before submission. Unknown cost or a protocol error halts
further inference; no cost is silently treated as zero. Reconciliation requires
a saved readback receipt. Do not reset quotas or retry an unknown paid attempt.

The sequential eight-case integration pilot is retained unchanged under `results/paid/history/sequential-pilot`; its cost remains in the shared ledger and financial reports, while its quality observations are excluded from the new parallel pilot. A relocation receipt preserves its original journal paths.

The main command freezes source hashes, original data hashes, dependencies,
model parameters and the complete matrix. It requires an accepted current-source
pilot and a conservative spend forecast. Five balanced batches each contain
30 ordinary honest invoices, two repetitions of every Vera scenario and a
stratified portion of the mixed set. Each batch produces a completeness/budget
checkpoint and fresh quota readback before continuation. Four isolated episodes run in each wave; identical scenario IDs within a dataset are separated into different waves, preventing duplicate shared input-guard cache misses. A controller lock excludes a second inference controller. Per-request kernel file leases distinguish live concurrent reservations from abandoned ones; every active reserve counts against all applicable caps. Unknown outcomes stop new requests; already submitted requests settle without retries.

The first OpenRouter smoke was rejected before generation by the selected
key's account data policy (404). It cost zero, confirmed by two quota readbacks.
Its immutable evidence remains in `results/paid/archived-openrouter-smoke` and
commit `4d8512c`. Following the user's instruction to use the documented Eliza
path, the current implementation uses Eliza's native DeepSeek vendor route.
No OpenRouter key or privacy setting was changed.

## Evidence and compatibility

| Original artifact or field | New evidence |
| --- | --- |
| scenarios.json, scenario id/truth/amount/description/src | original immutable files, manifest matrix, per-episode job.json |
| calls.jsonl: model, temperature, input, output, usage | calls.jsonl.gz request/response events with exact serialized body and original provider payload |
| hooks.jsonl | hooks.jsonl with every passive hook and arrival time |
| db.json: invoice status, vendor status/trust/risk, payment count | db.json, complete database.json, compressed SQLite snapshot |
| out.txt, COST_USD, duration, errors | out.txt/err.txt, episode.json: historical fixed mini-rate COST_USD estimate and separate ELIZA_COST_USD, authoritative billing ledger |
| guard blocks/block/reason/latency, three-vote majority | defender.json and per-vote guard-results receipts |
| guard prompt/view/calls/parse errors/spending | frozen source prompt, guard-calls.jsonl.gz, query identities, summary and ledger |
| v1/v2 boundary/orchestrator/final, facts-only boundary | original view-builder functions, unchanged, called on new hooks |
| FPR, harm, flags, missing Payments, repeated steps | per-episode evidence, episodes.json/CSV, summary.json and REPORT.md |

Guard verdicts are **posthoc**, not live blocks. Conditional levels comparisons
use paid invoices as in the original method, while the 150-case FPR denominator
includes all valid ordinary honest submissions. `approved` without a transfer is
not a rejection. Raw status, actual completed simulated transfers and transfer
tool attempts are retained separately. The schema deliberately retains missing
data as unavailable; TTFT is not measured in this non-streaming protocol.

Original nano `COST_USD` estimates sometimes used fixed mini prices. These are
historical estimates, not authoritative billing. New cost comes from Eliza's
envelope; provider-reported cost and token-based comparisons remain separate.
`results/historical-reference.json` independently re-reads all 297 nano episodes
and 227 fully recorded mini episodes from the original archives, preserving their
archive hashes, statuses, transfer calls, stage flags, latency and `COST_USD`.
The mini archive has no Vera-seven subset. Historical model roles must not be
assumed identical: nano baseline has no external guard; the research guard code
selects mini. New executor and guard both use the same documented native DeepSeek alias; the declared version is checked before paid phases and at every checkpoint.

See `PROGRESS.md` for execution receipts and any rulings. `.runtime` is scratch
and excluded from Git. Paid results remain locally inspectable under `results/paid`.

FinBot's legacy `agent_chain[].reasoning` field contains its task-summary text and
heuristic cascade evidence. It is not the provider's `reasoning_content` or a
measurement of hidden reasoning tokens. The original field is retained, while
native thinking is disabled and unavailable API reasoning-token counters stay null.

Additional measured variant economics and workflow diagnostics are generated by
local postprocessors under `verification/` after each controller exits. These
postprocessors take the same exclusive controller lock; they cannot race with
inference. Input voting is one logical check but three model requests, so its
measured latency/cost are summed. Original conditional levels use paid
injection/fraud or amount>10000 as harm and paid legit amount<=5000 as honest;
overall bad43 metrics include all non-legit labels, including every policy case.
