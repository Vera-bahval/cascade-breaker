import asyncio
import tempfile
import unittest
import subprocess
import sys
from pathlib import Path

import httpx

from test_transport import envelope, native_fixture


class ParallelTest(unittest.TestCase):
    # Активные запросы допускаются одновременно с учётом всех резервов.
    def test_live_leases_and_reserves_share_cap(self):
        from transport import Ledger, RunStopped
        with tempfile.TemporaryDirectory() as tmp:
            ledger = Ledger(Path(tmp) / 'budget.db', cap=.025)
            with ledger.request_lease('one'), ledger.request_lease('two'):
                ledger.reserve('one', 'main', .01)
                ledger.reserve('two', 'main', .01)
                with self.assertRaises(RunStopped):
                    ledger.reserve('three', 'main', .01)
                ledger.complete('one', .001)
                ledger.complete('two', .001)
            self.assertEqual(ledger.state()['pending'], 0)

    # Освободившийся после падения процесса lease запрещает повторную генерацию.
    def test_orphan_reservation_halts(self):
        from transport import Ledger, RunStopped
        with tempfile.TemporaryDirectory() as tmp:
            ledger = Ledger(Path(tmp) / 'budget.db')
            with ledger.request_lease('one'):
                ledger.reserve('one', 'main', .01)
            with ledger.request_lease('two'):
                with self.assertRaises(RunStopped):
                    ledger.reserve('two', 'main', .01)

    # Ошибка одного активного запроса блокирует новые запросы других эпизодов.
    def test_unknown_live_request_and_halt_marker_block(self):
        from transport import Ledger, RunStopped, write_json
        with tempfile.TemporaryDirectory() as tmp:
            ledger = Ledger(Path(tmp) / 'budget.db')
            with ledger.request_lease('one'):
                ledger.reserve('one', 'main', .01)
                ledger.unknown('one', 'timeout')
                with self.assertRaises(RunStopped):
                    ledger.reserve('two', 'main', .01)
                ledger.reconcile('one', 0, Path(tmp) / 'budget.db')
            write_json(Path(tmp) / 'halt.json', {'reason': 'worker failed'})
            with self.assertRaises(RunStopped):
                ledger.reserve('three', 'main', .01)

    # Четыре HTTP-вызова действительно перекрываются, а журнал и бюджет сходятся.
    def test_four_transports_overlap(self):
        from transport import Ledger, RecordedTransport
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); ledger = Ledger(root / 'budget.db')
            active = 0; peak = 0
            async def backend(request):
                nonlocal active, peak
                active += 1; peak = max(peak, active)
                await asyncio.sleep(.04)
                active -= 1
                return httpx.Response(200, json=native_fixture(envelope()))
            async def call(index):
                tr = RecordedTransport(root / f'{index}.jsonl.gz', ledger,
                    {'phase': 'main', 'episode': str(index), 'role': 'executor'},
                    upstream=httpx.MockTransport(backend), token='fake')
                async with httpx.AsyncClient(transport=tr) as client:
                    await client.post('https://api.eliza.yandex.net/deepseek/responses',
                                      json={'input': 'OK'})
            async def run():
                await asyncio.gather(*(call(n) for n in range(4)))
            asyncio.run(run())
            self.assertEqual(peak, 4)
            self.assertEqual(ledger.state()['pending'], 0)
            self.assertAlmostEqual(ledger.state()['spent_usd'], .0008)

    # Повторы одного сценария попадают в разные волны, исключая двойную оплату cache miss.
    def test_waves_do_not_overlap_input_cache_keys(self):
        from experiment import matrix, waves
        jobs = matrix()
        result = list(waves(jobs, 4))
        self.assertEqual(sorted(j['episode'] for wave in result for j in wave),
                         sorted(j['episode'] for j in jobs))
        for wave in result:
            self.assertLessEqual(len(wave), 4)
            self.assertEqual(len(wave), len({(j['dataset'], j['scenario']['id']) for j in wave}))

    # Второй контроллер того же платного запуска не допускается.
    def test_controller_lock_is_exclusive(self):
        from experiment import controller_lock
        from transport import RunStopped
        with tempfile.TemporaryDirectory() as tmp:
            with controller_lock(Path(tmp)):
                with self.assertRaises(RunStopped):
                    with controller_lock(Path(tmp)):
                        pass

    # Worker удерживает controller lock даже после закрытия родительского дескриптора.
    def test_controller_lease_survives_parent_context(self):
        from experiment import controller_lock
        from transport import RunStopped
        with tempfile.TemporaryDirectory() as tmp:
            with controller_lock(Path(tmp)) as fd:
                child = subprocess.Popen([sys.executable, '-c',
                    'import sys; print("ready",flush=True); sys.stdin.read()'],
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, pass_fds=(fd,))
                self.assertEqual(child.stdout.readline().strip(), 'ready')
            try:
                with self.assertRaises(RunStopped):
                    with controller_lock(Path(tmp)):
                        pass
            finally:
                child.stdin.close(); child.wait(timeout=5); child.stdout.close()
            with controller_lock(Path(tmp)):
                pass

    # Частичный эпизод выявляется до запуска любой задачи из той же волны.
    def test_preflight_rejects_partial_episode(self):
        from experiment import preflight_job
        from transport import RunStopped
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            job = {'phase':'pilot','episode':'fpr/one'}
            dest = root/'pilot/episodes/fpr/one'; dest.mkdir(parents=True)
            (dest/'job.json').write_text('{}')
            with self.assertRaises(RunStopped):
                preflight_job(job, root)
