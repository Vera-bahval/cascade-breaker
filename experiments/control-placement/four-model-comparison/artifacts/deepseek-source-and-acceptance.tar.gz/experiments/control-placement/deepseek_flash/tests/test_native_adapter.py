import unittest


class NativeAdapterTest(unittest.TestCase):
    # Тексты, порядок и связи вызовов инструментов сохраняются при смене протокола.
    def test_full_tool_turn_preserves_content(self):
        from native_adapter import chat_request, as_responses
        request=chat_request({'input':[
            {'role':'system','content':'unchanged policy'},
            {'role':'user','content':'invoice text'},
            {'type':'message','role':'assistant','content':[{'type':'output_text','text':'checking'}]},
            {'type':'function_call','call_id':'call_A','name':'lookup','arguments':'{"id":6}'},
            {'type':'function_call','call_id':'call_B','name':'risk','arguments':'{}'},
            {'type':'function_call_output','call_id':'call_A','output':'{"amount":500}'},
            {'type':'function_call_output','call_id':'call_B','output':'low'},
        ],'tools':[{'type':'function','name':'lookup','description':'get invoice','strict':True,
                     'parameters':{'type':'object','properties':{}}}]})
        self.assertEqual(request['messages'][0],{'role':'system','content':'unchanged policy'})
        self.assertEqual(request['messages'][2]['content'],'checking')
        self.assertEqual([c['id'] for c in request['messages'][2]['tool_calls']],['call_A','call_B'])
        self.assertEqual(request['messages'][3],{'role':'tool','tool_call_id':'call_A','content':'{"amount":500}'})
        self.assertEqual(request['tools'][0]['function']['description'],'get invoice')
        self.assertNotIn('strict',request['tools'][0]['function'])
        native={'id':'n1','created':1,'model':'deepseek-flash','usage':{'prompt_tokens':100,'completion_tokens':5,
           'total_tokens':105,'prompt_cache_hit_tokens':80},'choices':[{'finish_reason':'tool_calls','message':
           {'role':'assistant','content':None,'tool_calls':[{'id':'call_C','type':'function',
             'function':{'name':'pay','arguments':'{"amount":500}'}}]}}]}
        response=as_responses(native)
        self.assertEqual(response['output'][0]['call_id'],'call_C')
        self.assertEqual(response['output'][0]['arguments'],'{"amount":500}')
        self.assertEqual(response['usage']['input_tokens_details']['cached_tokens'],80)

    # Неподдержанный параметр не исчезает незаметно из экспериментального запроса.
    def test_unsupported_feature_stops_before_send(self):
        from native_adapter import chat_request
        from transport import RunStopped
        with self.assertRaises(RunStopped):chat_request({'input':'x','previous_response_id':'old'})
        with self.assertRaises(RunStopped):chat_request({'input':[{'type':'image','image_url':'x'}]})

    # Изменение заявленной версии обновляемого API ID останавливает следующий пакет.
    def test_native_version_drift_stops(self):
        import httpx
        from unittest.mock import patch
        from experiment import native_version
        from transport import RunStopped
        response=httpx.Response(200,text='<table><td>MODEL VERSION</td><td>DeepSeek-V9-Flash-9999</td></table>',
            request=httpx.Request('GET','https://api-docs.deepseek.com/quick_start/pricing/'))
        with patch('httpx.get',return_value=response):
            with self.assertRaises(RunStopped):native_version()


if __name__=='__main__':unittest.main()
