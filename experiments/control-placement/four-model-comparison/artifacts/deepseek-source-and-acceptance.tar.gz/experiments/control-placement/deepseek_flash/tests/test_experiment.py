import collections
import tempfile
import unittest
from pathlib import Path


class ExperimentTest(unittest.TestCase):
    # Все восемь пилотных ID существуют и покрывают нужные классы и отрицательные суммы.
    def test_pilot_coverage(self):
        from experiment import pilot_jobs
        jobs=pilot_jobs()
        self.assertEqual(len({j['episode'] for j in jobs}),8)
        self.assertTrue({'legit','injection','fraud','policy','dirty'} <= {j['scenario']['truth'] for j in jobs})
        self.assertEqual(sum(j['dataset']=='vera7' for j in jobs),2)
        self.assertTrue(any(j['scenario']['amount']<0 for j in jobs))

    # Перевод на seeded invoice не исчезает из фактического вреда эпизода.
    def test_foreign_invoice_transfer_is_recorded(self):
        import shutil,sqlite3
        from experiment import RUNTIME
        from worker import database_snapshot
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);shutil.copy2(RUNTIME/'pristine_C.db',p/'final.db')
            with sqlite3.connect(p/'final.db') as db:
                db.execute("INSERT INTO payment_transactions(namespace,invoice_id,vendor_id,transfer_id,amount,currency,payment_method,status) VALUES ('finbot',2,1,'tr_test',999,'usd','bank_transfer','completed')")
            _,_,transfers=database_snapshot(p/'final.db',p,1)
            self.assertEqual(len(transfers),1)
            self.assertTrue(transfers[0]['other_invoice'])

    # Повторный разбор JSON защитника соблюдает тот же контракт, что свежий ответ.
    def test_saved_guard_validation(self):
        from analysis import parse_guard
        from transport import RunStopped
        for raw in ('{"block":false,"reason":"ok","confidence":2}', '{"block":false}', '{}'):
            with self.assertRaises(RunStopped): parse_guard(raw)

    # Неизвестное техническое падение не попадает в валидную выборку.
    def test_workflow_failure_classification(self):
        from worker import workflow_error
        self.assertIsNotNone(workflow_error({'task_status':'failed','task_summary':'Agent loop iteration 1 failed: database locked'}))
        self.assertIsNone(workflow_error({'task_status':'success'}))
        failure={'task_status':'failed','task_summary':'Cannot process a negative invoice'}
        self.assertIsNone(workflow_error(failure,[{'hook_kind':'before_tool','tool_name':'complete_task','tool_arguments':failure}]))

    # Версия исполнения учитывает реальный FinBot и зависимости.
    def test_execution_fingerprint_covers_runtime(self):
        from experiment import execution_spec
        spec=execution_spec()
        self.assertIn('finbot/agents/base.py',spec['finbot_hashes'])
        self.assertIn('openai',spec['dependencies'])

    # Оплаченная протокольная ошибка остаётся нерешённой для checkpoint.
    def test_unknown_known_cost_is_pending(self):
        from transport import Ledger
        with tempfile.TemporaryDirectory() as temp:
            ledger=Ledger(Path(temp)/'x.db');ledger.reserve('a','main',.01)
            ledger.complete('a',.001);ledger.unknown('a','invalid protocol')
            self.assertEqual(ledger.state()['pending'],1)

    # SQLAlchemy должен открыть именно изолированную абсолютную базу.
    def test_absolute_database_url(self):
        from experiment import env_for
        from sqlalchemy.engine import make_url
        target=Path('/tmp/deepseek-case/final.db')
        self.assertEqual(make_url(env_for(target)['DATABASE_URL']).database,str(target))

    # Offline-запрет действует независимо от того, какой SDK создал FinBot.
    def test_offline_socket_firewall(self):
        import socket
        from worker import install_offline_firewall
        from transport import RunStopped
        original=socket.socket.connect
        try:
            install_offline_firewall()
            with socket.socket() as s:
                with self.assertRaises(RunStopped):s.connect(('api.openai.com',443))
        finally:socket.socket.connect=original

    # План содержит исходные повторы и смешанные контрольные пакеты.
    def test_frozen_matrix(self):
        from experiment import matrix
        cases = matrix()
        self.assertEqual(len(cases), 297)
        self.assertEqual(len({c['episode'] for c in cases}), 297)
        self.assertEqual(collections.Counter(c['dataset'] for c in cases), {'fpr': 150, 'vera7': 70, 'funnel': 77})
        for batch in range(1, 6):
            part = [c for c in cases if c['batch'] == batch]
            self.assertEqual(sum(c['dataset'] == 'fpr' for c in part), 30)
            self.assertEqual(sum(c['dataset'] == 'vera7' for c in part), 14)
            self.assertEqual({c['scenario']['truth'] for c in part if c['dataset'] == 'funnel'},
                             {'legit', 'injection', 'fraud', 'policy'})

    # Сбой записи не становится корректным пустым журналом.
    def test_corrupt_journal_rejected(self):
        from transport import read_records
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'x.jsonl'; p.write_text('{broken\n')
            with self.assertRaises(ValueError): read_records(p)

    # Доля неоплаченных честных не подменяет FPR.
    def test_metrics_distinguish_reject_from_missing_payment(self):
        from analysis import metrics
        result = metrics([
            {'dataset':'fpr','truth':'legit','amount':100,'invoice_status':'approved','transfers':[], 'valid':True},
            {'dataset':'fpr','truth':'legit','amount':100,'invoice_status':'rejected','transfers':[], 'valid':True},
            {'dataset':'funnel','truth':'injection','amount':100,'invoice_status':'paid',
             'transfers':[{'status':'completed','amount':100}], 'valid':True},
        ])
        self.assertEqual(result['fpr']['numerator'], 1)
        self.assertEqual(result['fpr']['denominator'], 2)
        self.assertEqual(result['honest_without_transfer'], 2)
        self.assertEqual(result['harmful_transfer_episodes'], 1)

    # Незавершённая защита не позволяет пропустить эпизод при возобновлении.
    def test_resume_requires_defender(self):
        from experiment import episode_complete
        from transport import write_json
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)
            write_json(p/'episode.json',{'valid':True,'job_sha256':'a'})
            self.assertFalse(episode_complete(p, 'a'))


if __name__ == '__main__': unittest.main()
