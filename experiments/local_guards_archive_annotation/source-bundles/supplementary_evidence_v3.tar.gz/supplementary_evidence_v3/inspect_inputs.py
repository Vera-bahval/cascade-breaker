#!/usr/bin/env python3
"""Check bounded request inputs for nested tool declarations, excluding output fields."""
import gzip,hashlib,io,json,re,tarfile
from collections import Counter,defaultdict
from pathlib import Path
HERE=Path(__file__).resolve().parent;EXP=HERE.parent;BASE=EXP.parent/'local_guards_archive_comparison';ROOT=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report')
KEYS={'tools','functions','request_tools','tool_definitions','tool_schemas','callable_schemas','available_tools','function_definitions','mcp_config','namespace_config'}
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):
 b=(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();p.write_bytes(b);return sha(b)
def find(v,ptr=''):
 out=[]
 if isinstance(v,dict):
  for k,item in v.items():
   p=ptr+'/'+k.replace('~','~0').replace('/','~1')
   if k.lower() in KEYS:out.append({'pointer':p,'value':item})
   out.extend(find(item,p))
 elif isinstance(v,list):
  for i,item in enumerate(v):out.extend(find(item,ptr+'/'+str(i)))
 return out

def main():
 mapping={x['prefix_id']:x['annotation_id'] for x in json.loads((EXP/'custodian_manifest.json').read_text())['cases']};sources=defaultdict(list)
 with gzip.open(BASE/'data/split-metadata.jsonl.gz','rt') as f:
  for line in f:
   x=json.loads(line)
   if x['prefix_id'] in mapping and x['source'].endswith('.tar.gz'):sources[x['source']].append(x)
 for d in ('blind_inputs','custodian_records'): (HERE/d).mkdir(exist_ok=True)
 report=[]
 for source,rows in sources.items():
  p=Path(source);p=p if p.is_absolute() else ROOT/p;data=p.read_bytes();h=sha(data);assert all(not x.get('source_sha256') or x['source_sha256']==h for x in rows)
  with tarfile.open(fileobj=io.BytesIO(data)) as t:
   names={m.name:m for m in t if m.isfile()}
   for x in rows:
    aid=mapping[x['prefix_id']];hook=x['member'];hook=hook if hook.endswith('.jsonl') else hook+'hooks.jsonl';stem=hook.removesuffix('.hooks.jsonl');calls=stem+'.calls.jsonl';cut=x['source_event_index'];hraw=t.extractfile(names[hook]).read().splitlines();events=[json.loads(l) for l in hraw[:cut]];assert events[-1].get('hook_kind')=='before_tool' and events[-1].get('tool_name')=='finstripe__create_transfer'; models=[(i,e) for i,e in enumerate(events[:-1],1) if e.get('hook_kind')=='before_model'];matched=[];findings=[];reason='no_exact_sibling_calls_file';callhash=None
    if calls in names:
     raw=t.extractfile(names[calls]).read();callhash=sha(raw);records=raw.decode().splitlines();reason='all_available_before_model_ordinals_matched'
     for index,(hookline,e) in enumerate(models):
      if index>=len(records):reason='fewer_calls_than_precut_model_hooks';break
      # Only decode the input value; the adjacent output value is never deserialized.
      match=re.search(r'"input"\s*:\s*',records[index])
      if not match:reason='missing_input_field';break
      v,end=json.JSONDecoder().raw_decode(records[index],match.end());users=[item.get('content') for item in v if isinstance(item,dict) and item.get('role')=='user'] if isinstance(v,list) else []
      if e.get('user_message') not in users:reason='hook_input_ordinal_mismatch';break
      matched.append({'calls_line':index+1,'hook_before_model_line':hookline})
      for item in find(v):findings.append({'calls_line':index+1,'hook_before_model_line':hookline,**item})
    blind={'annotation_id':aid,'status':reason,'matched_pre_cut_requests':len(matched),'nested_declaration_fields':findings,'limitations':'Binding is ordinal plus exact user-message equality to preceding hooks; files have no request timestamps, so missing/dropped hooks could undermine strict timing. No output field was parsed. No declarations found does not establish unavailable.'}
    cust={'source':str(p),'source_sha256':h,'hook_member':hook,'p4_line':cut,'calls_member':calls if calls in names else None,'calls_sha256':callhash,'matched_indices':matched,'boundary':'Only the first N request inputs were decoded, where N is the count of before_model hooks before P4; matching stops at first user-message mismatch. This is a recorded-trace alignment, not a proof against omitted hooks.'}
    bh=write(HERE/'blind_inputs'/(aid+'.json'),blind);ch=write(HERE/'custodian_records'/(aid+'.json'),cust);report.append({'annotation_id':aid,'status':reason,'matched_count':len(matched),'declaration_count':len(findings),'blind_sha256':bh,'custodian_sha256':ch})
 report.sort(key=lambda x:x['annotation_id']);summary={'cases':report,'status_counts':dict(Counter(x['status'] for x in report)),'cases_with_nested_declarations':sum(bool(x['declaration_count']) for x in report)};write(HERE/'availability.json',summary);print(summary['status_counts'],'nested cases',summary['cases_with_nested_declarations'])
if __name__=='__main__':main()
