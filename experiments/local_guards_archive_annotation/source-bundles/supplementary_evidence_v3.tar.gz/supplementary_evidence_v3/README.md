# Nested request-input inspection

For all 382 tar cases with exact sibling `*.calls.jsonl`, the first N `input` values were decoded, where N is the number of saved `before_model` hooks before P4. The adjacent `output` values were not decoded. Each input was aligned in order with a saved hook by exact user-message equality; all 382 cases matched throughout. The decoded input objects were recursively searched for keys `tools`, `functions`, `request_tools`, `tool_definitions`, `tool_schemas`, `callable_schemas`, `available_tools`, `function_definitions`, `mcp_config`, and `namespace_config`. No such nested keys were found. String contents were not recursively decoded as JSON. This does not prove the tool was unavailable.

The old call format contains no request timestamps. The matching establishes consistency with the recorded hook sequence, but does not independently rule out omitted hook records. The remaining 112 tar cases do not have that exact sibling format; 39 of those have timestamp-bound request evidence in v2 and 73 have no enumerated sibling request artifact. This is a bounded search, not proof that no other raw artifacts exist.

`blind_inputs/` contains the per-case bounded findings; `custodian_records/` and `availability.json` contain source details and hashes and remain with the custodian. The earlier v1/v2 evidence remains unchanged.
