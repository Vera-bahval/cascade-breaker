#!/usr/bin/env python3
"""Match archive fixture text to current saved scenario-construction declaration."""
import ast,hashlib,json
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent;SC=HERE.parent;SOURCE=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report/experiments/control-placement/code/finbot477/make_pairs_scenarios.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 raw=SOURCE.read_bytes();tree=ast.parse(raw);assign={n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)};base=ast.literal_eval(assign['BASE'].value);variants=ast.literal_eval(assign['VARIANTS'].value);lookup={code:(phrase,description) for code,phrase,description in variants};(HERE/'blind_inputs').mkdir(exist_ok=True);cases=[]
 for p in sorted((SC/'custodian_records').glob('*.json')):
  cust=json.loads(p.read_text());aid=cust['annotation_id']
  blind=json.loads((SC/'blind_inputs'/(aid+'.json')).read_text());extra=json.loads((SC/'construction_v2/blind_inputs'/(aid+'.json')).read_text());f=blind['fields'];variant=extra['construction_fields'].get('variant');amount=f.get('amount');desc=f.get('desc');matches=False;construction=None
  if variant is None:continue
  if variant in lookup and amount in base:
   phrase,description=lookup[variant];generated=f'{base[amount]}. {phrase}' if phrase else base[amount];matches=generated==desc
   if matches:construction={'variant':variant,'base_description':base[amount],'appended_phrase':phrase,'author_variant_description':description}
  record={'annotation_id':aid,'status':'construction_text_exactly_reproduced' if matches else 'construction_not_matched','construction':construction,'limitation':'Current saved generator is not revision-bound to the historical run. Exact source-input match supports, but does not prove, identical original construction. Author description is evidence of intended construction, not an adjudicated label.'};content=(json.dumps(record,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode();(HERE/'blind_inputs'/(aid+'.json')).write_bytes(content);cases.append({'annotation_id':aid,'status':record['status'],'sha256':sha(content)})
 report={'cases':cases,'status_counts':dict(Counter(x['status'] for x in cases)),'source':str(SOURCE),'source_sha256':sha(raw),'source_lines':{'base':[assign['BASE'].lineno,assign['BASE'].end_lineno],'variants':[assign['VARIANTS'].lineno,assign['VARIANTS'].end_lineno]},'scope':'AST literal declarations only; no truth or scoring rules extracted.'};(HERE/'custodian_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n');print(report['status_counts'])
if __name__=='__main__':main()
