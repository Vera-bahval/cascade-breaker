#!/usr/bin/env python3
"""Inventory original fixture declarations and independently matched construction records."""
import ast,hashlib,json,tarfile
from collections import Counter
from functools import lru_cache
from pathlib import Path
HERE=Path(__file__).resolve().parent;SC=HERE.parent;CODE=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report/experiments/control-placement/code')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):
 b=(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();p.write_bytes(b);return sha(b)
@lru_cache(maxsize=None)
def member(source,name):
 with tarfile.open(source) as t:return t.extractfile(name).read()
def main():
 for d in ('blind_declarations','custodian_records'): (HERE/d).mkdir(exist_ok=True)
 sources={}
 for name in ('gen_testset_v5.py','gen_honest_v6.py','finbot477/make_pairs_scenarios.py','finbot477/make_custom_scenarios.py','finbot477/make_sweep_scenarios.py','testset_v5.py','testset_v5_generated.json','testset_v6_honest_generated.json'):
  p=CODE/name;b=p.read_bytes();sources[name]={'path':str(p),'sha256':sha(b),'binding':'current saved file, not cryptographically bound to historical run'}
 v5=json.loads((CODE/'testset_v5_generated.json').read_text());v6=json.loads((CODE/'testset_v6_honest_generated.json').read_text());idx={}
 for filename,doc,groups in [('testset_v5_generated.json',v5,('honest','attacks')),('testset_v6_honest_generated.json',v6,('honest',))]:
  for group in groups:
   for i,item in enumerate(doc.get(group,[])):
    if isinstance(item,dict) and 'amount' in item and 'description' in item:
     idx.setdefault((item['amount'],item['description']),[]).append({'source':filename,'pointer':f'/{group}/{i}','author_group':group,**({'technique':item['technique']} if 'technique' in item else {})})
 prompts={}
 for filename,names in [('gen_testset_v5.py',('HONEST_PROMPT','ATTACK_PROMPT')),('gen_honest_v6.py',('PROMPT',))]:
  tree=ast.parse((CODE/filename).read_text());mapping={n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
  for name in names:
   n=mapping[name];prompts[filename+':'+name]={'text':ast.literal_eval(n.value),'line':n.lineno,'end_line':n.end_lineno}
 write(HERE/'custodian_source_catalog.json',{'files':sources,'construction_prompts':prompts,'meaning_notes':{
 'pairs':'Saved pairs generator assigns truth by variant and amount: base/placebo are legit at or below 10000 and policy above 10000; other variants are injection. The amount-derived policy class is not an intent declaration.',
 'custom':'Saved custom generator uses the same variant/amount truth expression; verify actual fixture and construction match.',
 'v5':'Saved testset_v5 groups generated inputs into honest and attacks; generated attack labels are attributed by that source to the generator, not independent ground truth. fraud and policy are distinct manual categories, not automatically adversarial intent.',
 'v6':'Saved generator requests ordinary legitimate invoices and emits truth legit. Exact input matches to generated list are checked below.',
 'legacy':'The persisted initial injection and invoice fields are construction evidence, but no retained source here establishes the historical label field semantics. No author intent assigned.'}})
 cases=[]
 for path in sorted((SC/'custodian_records').glob('*.json')):
  c=json.loads(path.read_text());aid=c['annotation_id'];fields={};ptr={};gen=[];meaning='not_established';status='no_author_declaration_recovered'
  if c.get('source_member'):
   raw=member(c['source'],c['source_member']);assert sha(raw)==c['member_sha256'];doc=json.loads(raw);ref=next(iter(c['field_provenance'].values()),'').strip('/').split('/');obj=doc
   for part in ref[:-1]:obj=obj[int(part)] if isinstance(obj,list) else obj[part]
   root='/'+'/'.join(ref[:-1])
   for k in ('truth','kind','intent','attack_family','injection_profile','adversarial_objective','variant'):
    if k in obj:fields[k]=obj[k];ptr[k]=root+'/'+k
   origin=obj.get('src'); blind=json.loads((SC/'blind_inputs'/(aid+'.json')).read_text());f=blind['fields'];gen=idx.get((f.get('amount'),f.get('desc')),[])
   if origin=='pairs':meaning='pairs_generator_assigns_truth_from_variant_and_amount'
   elif origin=='custom':meaning='custom_sweep_generator_marks_amount_policy_category'
   elif origin=='v5':meaning='v5_testset_groups_generated_honest_and_attacks_and_separate_manual_categories'
   elif origin=='v6':meaning='v6_honest_generator_and_fixture_truth'
   else:meaning='fixture_truth_recorded_but_source_construction_semantics_not_verified'
   if fields:status='fixture_author_declaration_recorded'
  p=SC/'construction_v3/blind_inputs'/f'{aid}.json';construction=json.loads(p.read_text()) if p.exists() else None
  blind={'annotation_id':aid,'status':status,'fixture_construction_fields':fields,'source_field_meaning':meaning,'matched_generated_records':gen,'matching_construction':construction.get('construction') if construction and construction.get('status')=='construction_text_exactly_reproduced' else None,'interpretation':'Recorded author or generator declaration, not an independently established intent label or action verdict. policy and fraud are not automatically attack or benign.'}
  cust={'source':c['source'],'source_sha256':c['source_sha256'],'source_member':c.get('source_member'),'member_sha256':c.get('member_sha256'),'line':c.get('line'),'field_pointers':ptr,'generated_matches':gen,'limits':'Fixture bytes source-hash bound; independently matched current generator files and prompts are not cryptographically bound to this historical run. Source-intent metadata and execution outcomes were not used.'}
  bh=write(HERE/'blind_declarations'/(aid+'.json'),blind);ch=write(HERE/'custodian_records'/(aid+'.json'),cust);cases.append({'annotation_id':aid,'status':status,'source_field_meaning':meaning,'matched_generated_record_count':len(gen),'blind_sha256':bh,'custodian_sha256':ch})
 report={'cases':cases,'status_counts':dict(Counter(x['status'] for x in cases)),'field_meaning_counts':dict(Counter(x['source_field_meaning'] for x in cases)),'generated_text_matched_cases':sum(bool(x['matched_generated_record_count']) for x in cases),'definition':'Inventory of source declarations only; no new intent classifications.','excluded':'expected_pay, source_requires_stop, defender verdicts, execution outcomes, method predictions.'};write(HERE/'availability.json',report);print(report['status_counts'],report['field_meaning_counts'],'generated matches',report['generated_text_matched_cases'])
if __name__=='__main__':main()
