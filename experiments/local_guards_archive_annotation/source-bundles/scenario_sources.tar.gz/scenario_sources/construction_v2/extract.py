#!/usr/bin/env python3
"""Extract explicit construction attributes, never outcome or truth fields."""
import hashlib,io,json,tarfile
from collections import Counter
from pathlib import Path
from functools import lru_cache
HERE=Path(__file__).resolve().parent;SCENARIO=HERE.parent
FIELDS=('kind','type','attack_family','injection_profile','attacker_profile','adversarial_objective','variant')
def sha(b):return hashlib.sha256(b).hexdigest()
@lru_cache(maxsize=None)
def source_hash(path): return sha(Path(path).read_bytes())
@lru_cache(maxsize=None)
def member(path,name):
 with tarfile.open(path) as t:return t.extractfile(name).read()
def main():
 (HERE/'blind_inputs').mkdir(exist_ok=True);cases=[]
 for path in sorted((SCENARIO/'custodian_records').glob('*.json')):
  rec=json.loads(path.read_text());aid=rec['annotation_id'];fields={};status='not_checked_legacy_line_source'
  if rec.get('source_member'):
   source=Path(rec['source']);assert source_hash(str(source))==rec['source_sha256']
   raw=member(str(source),rec['source_member']);assert sha(raw)==rec['member_sha256'];doc=json.loads(raw)
   pointer=next(iter(rec['field_provenance'].values()),'');parts=pointer.strip('/').split('/'); obj=doc
   for part in parts[:-1]:obj=obj[int(part)] if isinstance(obj,list) else obj[part]
   fields={k:obj[k] for k in FIELDS if k in obj};status='explicit_construction_fields_present' if fields else 'no_allowlisted_construction_fields_in_checked_fixture'
  blind={'annotation_id':aid,'status':status,'construction_fields':fields,'interpretation':'Original scenario construction metadata; it is not a ground-truth intent verdict.'};b=(json.dumps(blind,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode();(HERE/'blind_inputs'/(aid+'.json')).write_bytes(b);cases.append({'annotation_id':aid,'status':status,'sha256':sha(b)})
 assert len(cases)==542
 report={'cases':cases,'status_counts':dict(Counter(x['status'] for x in cases)),'provenance':'Join by opaque annotation ID to scenario_sources/custodian_records; fields from same scenario object as referenced amount/desc. Legacy input injection already extracted separately.','excluded':['truth','expected_pay','source_intent','source_requires_stop','defender responses','outcomes']}
 (HERE/'availability.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(report['status_counts'])
if __name__=='__main__':main()
