#!/usr/bin/env python3
"""Bounded extraction of original scenario fields; never read outcome fields into output."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from collections import Counter,defaultdict
from pathlib import Path

HERE=Path(__file__).resolve().parent
EXP=HERE.parent
BASE=EXP.parent/'local_guards_archive_comparison'
ROOT=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report')
LEGACY=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/experiments/local_guards/data/archive')
INVENTORY=EXP.parent/'local_guards_v4/data/source-inventory.json'

def digest(b): return hashlib.sha256(b).hexdigest()
def jbytes(x): return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def write(path,x):
 b=jbytes(x);path.write_bytes(b);return digest(b)
def readgz(p):
 with gzip.open(p,'rt',encoding='utf-8') as f:
  for line in f:yield json.loads(line)
def main():
 cases=json.loads((EXP/'custodian_manifest.json').read_text())['cases'];mapping={x['prefix_id']:x for x in cases}
 meta=[x for x in readgz(BASE/'data/split-metadata.jsonl.gz') if x['prefix_id'] in mapping]
 assert len(meta)==542
 index=defaultdict(list)
 for x in meta:index[x['source']].append(x)
 inventory={}
 if INVENTORY.exists():
  for rec in json.loads(INVENTORY.read_text())['records']:
   for loc in rec['locations']:inventory[loc['path']]=rec
 out=HERE/'custodian_records';out.mkdir(exist_ok=True);blind=HERE/'blind_inputs';blind.mkdir(exist_ok=True);summaries=[]
 for source,rows in sorted(index.items()):
  p=Path(source); p=p if p.is_absolute() else ROOT/p
  if not p.is_file() and p.name=='shadow-main.jsonl.gz':p=LEGACY/p.name
  data=None; locator=str(p); problem=None
  if p.is_file():data=p.read_bytes()
  elif source in inventory:
   rec=inventory[source]
   try:
    data=subprocess.check_output(['git','cat-file','blob',rec['git_blob']],cwd=EXP,stderr=subprocess.DEVNULL)
    if digest(data)!=rec['sha256']:raise ValueError('inventory SHA mismatch')
    locator='git-blob:'+rec['git_blob']+':'+source
   except (subprocess.CalledProcessError,KeyError):problem='source_missing_and_inventory_blob_unavailable'
  else:problem='source_missing_at_collector_locations'
  h=digest(data) if data is not None else None
  for x in rows:
   if h and x.get('source_sha256') and h!=x['source_sha256']:raise ValueError('source hash mismatch: '+source)
  if data is not None and source.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
    for x in rows:
     result={'annotation_id':mapping[x['prefix_id']]['annotation_id'],'source':locator,'source_sha256':h,
             'source_member':x.get('scenario_source'),'status':None,'fields':{},'field_provenance':{},'redactions':'Only scenario amount and description are retained; scenario identifiers, src, truth, variant, pair, repeat, and all other fields are omitted.'}
     member=x.get('scenario_source')
     if not member:result['status']='scenario_member_not_recorded'
     else:
      try:
       raw=t.extractfile(member).read(); obj=json.loads(raw);result['member_sha256']=digest(raw)
       if isinstance(obj,list):
        stem=Path(x['member']).name.removesuffix('.hooks.jsonl');bare=re.sub(r'-r\d+$','',stem)
        matches=[(i,o) for i,o in enumerate(obj) if isinstance(o,dict) and o.get('id') in (stem,bare)]
        if len(matches)!=1:result['status']='scenario_identifier_missing_or_ambiguous'
        else:i,sc=matches[0];ptr=f'/{i}'
       elif isinstance(obj,dict) and isinstance(obj.get('scenario'),dict):sc=obj['scenario'];ptr='/scenario'
       else:result['status']='unsupported_scenario_member_structure'
       if result['status'] is None:
        for field in ('amount','desc'):
         if field in sc:result['fields'][field]=sc[field];result['field_provenance'][field]=ptr+'/'+field
        result['status']='extracted' if result['fields'] else 'permitted_construction_fields_not_present'
      except (KeyError,AttributeError):result['status']='scenario_member_missing_in_archive'
     summaries.append((result,write(out/(result['annotation_id']+'.json'),result)))
  elif data is not None:
   # Initial invoice and injected instructions were recorded before execution.
   runs={}
   for number,line in enumerate(gzip.decompress(data).splitlines(),1):
    if line.strip():
     obj=json.loads(line);rid=obj.get('run_id')
     if rid in runs:raise ValueError('duplicate legacy run id')
     runs[rid]=(number,obj)
   for x in rows:
    result={'annotation_id':mapping[x['prefix_id']]['annotation_id'],'source':locator,'source_sha256':h,'status':None,'fields':{},'field_provenance':{},'redactions':'Only initial invoice amount, description, due date offset and original injection fields retained; execution results, verdicts, labels, final state and other fields omitted.'}
    if x['member'] not in runs:result['status']='run_id_missing_in_checked_source'
    else:
     line,obj=runs[x['member']];result['line']=line
     for field in ('invoice','injection'):
      if field in obj:
       value=obj[field]
       if field=='invoice' and isinstance(value,dict): value={k:value[k] for k in ('amount','description','due_date_offset_days') if k in value}
       result['fields'][field]=value;result['field_provenance'][field]='/'+field
     result['status']='extracted' if result['fields'] else 'permitted_construction_fields_not_present'
    summaries.append((result,write(out/(result['annotation_id']+'.json'),result)))
  else:
   for x in rows:
    result={'annotation_id':mapping[x['prefix_id']]['annotation_id'],'source':locator,'source_sha256':None,'status':problem,'fields':{},'field_provenance':{}}
    summaries.append((result,write(out/(result['annotation_id']+'.json'),result)))
 assert len(summaries)==542 and len({r['annotation_id'] for r,_ in summaries})==542
 for result,_ in summaries:
  result['blind_input_sha256']=write(blind/(result['annotation_id']+'.json'),{'annotation_id':result['annotation_id'],'status':result['status'],'fields':result['fields']})
 report={'count':542,'status_counts':dict(Counter(r['status'] for r,_ in summaries)),
         'source_inventory_sha256':digest(INVENTORY.read_bytes()) if INVENTORY.exists() else None,
         'cases':[{'annotation_id':r['annotation_id'],'status':r['status'],'custodian_sha256':h,'blind_input_sha256':r['blind_input_sha256']} for r,h in sorted(summaries,key=lambda v:v[0]['annotation_id'])],
         'scope':'Scenario input evidence only. Extracted fields are not labels, and missing construction or intent remains unassessed. Do not distribute to action-only raters.',
         'limitations':'Tar scenarios retain amount/description, not executor system prompt or original orchestration instruction. Legacy records retain initial invoice/injection. No source binding or native tool availability is inferred.'}
 write(HERE/'availability.json',report)
 print(json.dumps({'count':542,'status_counts':report['status_counts']},indent=2))
if __name__=='__main__':main()
