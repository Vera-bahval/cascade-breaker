#!/usr/bin/env python3
"""Extract source-bound Payments tool definitions from strictly pre-cut requests."""
import gzip,hashlib,io,json,tarfile
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent; EXP=HERE.parent; BASE=EXP.parent/'local_guards_archive_comparison';ROOT=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):
 b=(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();p.write_bytes(b);return sha(b)
def time(s):return datetime.fromtimestamp(s,timezone.utc) if isinstance(s,(int,float)) else datetime.fromisoformat(s.replace('Z','+00:00'))
def main():
 mapping={x['prefix_id']:x['annotation_id'] for x in json.loads((EXP/'custodian_manifest.json').read_text())['cases']};sources=defaultdict(list)
 with gzip.open(BASE/'data/split-metadata.jsonl.gz','rt') as f:
  for l in f:
   x=json.loads(l)
   if x['prefix_id'] in mapping and x['source'].endswith('.tar.gz'):sources[x['source']].append(x)
 for d in ('blind_inputs','custodian_records'): (HERE/d).mkdir(exist_ok=True)
 report=[]
 for source,rows in sources.items():
  p=Path(source);p=p if p.is_absolute() else ROOT/p;data=p.read_bytes();h=sha(data);assert all(not x.get('source_sha256') or x['source_sha256']==h for x in rows)
  with tarfile.open(fileobj=io.BytesIO(data)) as t:
   members={m.name:m for m in t if m.isfile()}
   for x in rows:
    aid=mapping[x['prefix_id']];hook=x['member'];hook=hook if hook.endswith('.jsonl') else hook+'hooks.jsonl';prefix=hook.rsplit('/',1)[0];calls=prefix+'/calls.jsonl.gz';cut=x['source_event_index'];hooks=t.extractfile(members[hook]).read().splitlines();event=json.loads(hooks[cut-1]);assert event.get('hook_kind')=='before_tool' and event.get('tool_name')=='finstripe__create_transfer';deadline=time(event['timestamp']); entries=[];cust=[]
    preceding=[(i,json.loads(line)) for i,line in enumerate(hooks[:cut-1],1)]; model=[(i,e) for i,e in preceding if e.get('hook_kind')=='before_model' and e.get('session_id')==event.get('session_id')]; last_model=model[-1] if model else None
    status='calls_member_not_present'
    if calls in members:
     raw=t.extractfile(members[calls]).read();status='no_pre_cut_payments_request'
     # Filter serialized records before parsing; response records are never parsed.
     for line,record in enumerate(gzip.decompress(raw).splitlines(),1):
      if not any(marker in record for marker in (b'"event": "request"', b'"event":"request"', b'"event": "intent"', b'"event":"intent"')):continue
      r=json.loads(record)
      stamp=r.get('utc') or r.get('at')
      if r.get('event') not in ('request','intent') or r.get('agent')!='payments_agent' or not stamp or time(stamp)>=deadline:continue
      request=r.get('request') or r.get('wire_request') or {};sdk=r.get('sdk_request') or {}
      fields={}
      if 'tools' in request:fields['provider_request_tools']=request['tools']
      if 'tools' in sdk:fields['sdk_request_tools']=sdk['tools']
      if fields:
       entries.append({'request_time':stamp,'tools':fields});cust.append({'line':line,'request_sha256':r.get('request_sha256'),'attempt_id':r.get('attempt_id'),'call':r.get('call'),'agent':r.get('agent'),'event':r.get('event'),'timestamp':stamp})
     if entries:status='payments_request_tools_captured'
    blind={'annotation_id':aid,'status':status,'p4_time':event['timestamp'],'last_same_session_before_model_time':last_model[1].get('timestamp') if last_model else None,'latest_request_within_model_interval':bool(entries and last_model and time(last_model[1]['timestamp'])<=time(entries[-1]['request_time'])<deadline),'payments_requests_before_p4':entries,'limitations':'Timestamp/agent-bound to episode; compare the latest request and its timing with the P4 invocation. Request list is actual supplied tools; it is not evidence of tool execution or successful tax verification.'}
    provenance={'source':str(p),'source_sha256':h,'hook_member':hook,'p4_line':cut,'last_same_session_before_model_line':last_model[0] if last_model else None,'p4_timestamp':event['timestamp'],'calls_member':calls if calls in members else None,'calls_member_sha256':sha(raw) if calls in members else None,'request_records':cust,'cut':'Strict request utc < selected P4 hook timestamp; only request or intent records parsed; no response or later effects.'}
    bh=write(HERE/'blind_inputs'/(aid+'.json'),blind);ch=write(HERE/'custodian_records'/(aid+'.json'),provenance);report.append({'annotation_id':aid,'status':status,'blind_sha256':bh,'custodian_sha256':ch})
 report.sort(key=lambda x:x['annotation_id']);write(HERE/'availability.json',{'cases':report,'status_counts':dict(Counter(x['status'] for x in report)),'scope':'494 tar cases only; legacy pre-cut tool lists already in parent supplementary_evidence.'});print(Counter(x['status'] for x in report))
if __name__=='__main__':main()
