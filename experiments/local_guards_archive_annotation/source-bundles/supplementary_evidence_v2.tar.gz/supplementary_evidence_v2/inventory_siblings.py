#!/usr/bin/env python3
"""Inventory same-episode request containers without parsing their values."""
import gzip,hashlib,io,json,tarfile
from collections import Counter,defaultdict
from pathlib import Path
HERE=Path(__file__).resolve().parent;EXP=HERE.parent;BASE=EXP.parent/'local_guards_archive_comparison';ROOT=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report')
def sha(b):return hashlib.sha256(b).hexdigest()
def topkeys(s):
 # Scan JSON lexical nesting; decode only top-level object keys, never values.
 keys=[];depth=0;i=0;expect=False
 while i<len(s):
  ch=s[i]
  if ch=='"':
   start=i;i+=1
   while i<len(s):
    if s[i]=='\\':i+=2;continue
    if s[i]=='"':break
    i+=1
   if depth==1 and expect:
    keys.append(json.loads(s[start:i+1]));expect=False
  elif ch in '{[':
   depth+=1
   if depth==1:expect=True
  elif ch in '}]':depth-=1
  elif ch==',' and depth==1:expect=True
  i+=1
 return keys
def main():
 mapping={x['prefix_id']:x['annotation_id'] for x in json.loads((EXP/'custodian_manifest.json').read_text())['cases']}; sources=defaultdict(list)
 with gzip.open(BASE/'data/split-metadata.jsonl.gz','rt') as f:
  for line in f:
   x=json.loads(line)
   if x['prefix_id'] in mapping and x['source'].endswith('.tar.gz'):sources[x['source']].append(x)
 records=[]
 for source,rows in sources.items():
  p=Path(source);p=p if p.is_absolute() else ROOT/p;data=p.read_bytes();assert all(not x.get('source_sha256') or x['source_sha256']==sha(data) for x in rows)
  with tarfile.open(fileobj=io.BytesIO(data)) as t:
   names={m.name:m for m in t if m.isfile()}
   for x in rows:
    hook=x['member'];hook=hook if hook.endswith('.jsonl') else hook+'hooks.jsonl';stem=hook.removesuffix('.hooks.jsonl');prefix=hook.rsplit('/',1)[0]; candidates=[stem+'.calls.jsonl',stem+'.calls.jsonl.gz',prefix+'/calls.jsonl.gz',prefix+'/calls.jsonl',stem+'.api_request.jsonl',prefix+'/api_request.jsonl',stem+'.trace.jsonl',prefix+'/trace.jsonl'];found=[n for n in candidates if n in names];info=[]
    for n in found:
     raw=t.extractfile(names[n]).read();entry={'member':n,'sha256':sha(raw)}
     if n.endswith('.calls.jsonl'):
      fields=Counter()
      for line in raw.decode().splitlines():fields.update(topkeys(line))
      entry.update(top_level_keys=dict(fields),record_count=max(fields.values(),default=0),inspected_values=False)
     info.append(entry)
    records.append({'annotation_id':mapping[x['prefix_id']],'source':str(p),'source_sha256':sha(data),'candidate_members':info})
 result={'cases':sorted(records,key=lambda x:x['annotation_id']),'case_count':len(records),'with_any_candidate':sum(bool(x['candidate_members']) for x in records),'methods':'Exact sibling names only. For .calls.jsonl scan top-level keys without decoding values, preserving the restriction on output contents. Other logs and final database artifacts were not used as input evidence.'}
 (HERE/'custodian_sibling_inventory.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print('cases',len(records),'with candidate',result['with_any_candidate']);c=Counter()
 for row in records:
  for item in row['candidate_members']:c[tuple(sorted(item.get('top_level_keys',{})))]+=1
 print('top-level key sets',c)
if __name__=='__main__':main()
