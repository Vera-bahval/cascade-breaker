#!/usr/bin/env python3
"""Extract bounded pre-P4 callable evidence and root task, never post-cut effects."""
import gzip,hashlib,io,json,subprocess,tarfile
from collections import Counter,defaultdict
from pathlib import Path
HERE=Path(__file__).resolve().parent; EXP=HERE.parent; BASE=EXP.parent/'local_guards_archive_comparison'
ROOT=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/research/finbot-four-model-report'); LEGACY=Path('/Users/proskurin-dmi/Documents/hw-itmo/cascades/experiments/local_guards/data/archive'); INV=EXP.parent/'local_guards_v4/data/source-inventory.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):
 b=(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();p.write_bytes(b);return sha(b)
def readgz(p):
 with gzip.open(p,'rt') as f:
  for line in f:yield json.loads(line)
def main():
 cases=json.loads((EXP/'custodian_manifest.json').read_text())['cases']; mapping={x['prefix_id']:x for x in cases}; meta=[x for x in readgz(BASE/'data/split-metadata.jsonl.gz') if x['prefix_id'] in mapping];assert len(meta)==542
 inventory={loc['path']:r for r in json.loads(INV.read_text())['records'] for loc in r['locations']};sources=defaultdict(list)
 for x in meta:sources[x['source']].append(x)
 for d in ('blind_inputs','custodian_records','root_requests_blind'): (HERE/d).mkdir(exist_ok=True)
 statuses=[]; per_source=[]
 for source,rows in sorted(sources.items()):
  p=Path(source);p=p if p.is_absolute() else ROOT/p
  if not p.is_file() and p.name=='shadow-main.jsonl.gz':p=LEGACY/p.name
  loc=str(p);data=None
  if p.is_file():data=p.read_bytes()
  elif source in inventory:
   rec=inventory[source];data=subprocess.check_output(['git','cat-file','blob',rec['git_blob']],cwd=EXP);assert sha(data)==rec['sha256'];loc='git-blob:'+rec['git_blob']+':'+source
  if data is None:raise ValueError('Source unresolved: '+source)
  h=sha(data);assert all(not x.get('source_sha256') or x['source_sha256']==h for x in rows)
  if source.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
    names=[m.name for m in t if m.isfile() and ('config' in m.name.lower() or 'manifest' in m.name.lower() or m.name.endswith(('.yaml','.yml','.toml','.py')))]; per_source.append({'source':loc,'sha256':h,'config_source_candidates':names,'note':'Names inventoried, not presumed effective per episode.'})
    for x in rows:
     aid=mapping[x['prefix_id']]['annotation_id'];name=x['member'];name=name if name.endswith('.jsonl') else name+'hooks.jsonl'; raw=t.extractfile(name).read();lines=raw.splitlines();cut=x['source_event_index'];assert 0<cut<=len(lines)
     # Never deserialize lines after the selected P4 hook.
     ev=[json.loads(l) for l in lines[:cut]];last=ev[-1];assert last.get('hook_kind')=='before_tool' and last.get('tool_name')=='finstripe__create_transfer'
     session=last.get('session_id'); entries=[];tax=[];root=None;rootref=None
     for i,e in enumerate(ev,1):
      if root is None and e.get('hook_kind')=='before_model' and e.get('user_message') is not None:root=e['user_message'];rootref=f'#L{i}/user_message'
      if e.get('hook_kind')=='before_tool' and str(e.get('tool_name','')).lower().startswith('taxcalc'):tax.append({'line':i,'tool_name':e['tool_name'],'same_session_as_p4':e.get('session_id')==session})
      if e.get('hook_kind')=='before_model':
       present={k:e[k] for k in ('request_tools','request_tool_schemas','tools','tool_definitions','mcp_config','namespace_config') if e.get(k) is not None}
       if present:entries.append({'line':i,'same_session_as_p4':e.get('session_id')==session,'fields':present})
     blind={'annotation_id':aid,'captured_before_model_tool_fields':entries,'precut_taxcalc_calls':tax,'availability':'captured_fields_present' if entries else 'unknown_no_callable_list_in_precut_hooks','limitations':'A pre-cut call in a different session does not establish tools available to Payments. No inference from prompt or attempt to load a tool.'}
     cust={'source':loc,'source_sha256':h,'member':name,'member_sha256':sha(raw),'cut_line':cut,'searched':'every hook line through and including pre-effect P4; before_model callable/config fields and earlier before_tool TaxCalc names','root_request_pointer':rootref,'additional_config_candidates':names,'candidates_are_bound':False}
     rh=write(HERE/'root_requests_blind'/(aid+'.json'),{'annotation_id':aid,'initial_user_message':root,'status':'captured' if root is not None else 'not_captured_in_precut_hooks'})
     bh=write(HERE/'blind_inputs'/(aid+'.json'),blind);ch=write(HERE/'custodian_records'/(aid+'.json'),cust);statuses.append({'annotation_id':aid,'status':blind['availability'],'blind_sha256':bh,'custodian_sha256':ch,'root_request_sha256':rh})
  else:
   runs={}
   for line,raw in enumerate(gzip.decompress(data).splitlines(),1):
    if raw.strip():
     r=json.loads(raw);runs[r.get('run_id')]=(line,r)
   per_source.append({'source':loc,'sha256':h,'config_source_candidates':['/steps/*/tools','/steps/*/tools_sha','/tool_defs'],'note':'Use only pre-cut step-linked definitions.'})
   for x in rows:
    aid=mapping[x['prefix_id']]['annotation_id'];line,r=runs[x['member']];cut=x['source_event_index'];steps=r.get('steps',[]);prior=[(i,s) for i,s in enumerate(steps) if s.get('seq',10**20)<cut]; entries=[];tax=[];root=None;rootptr=None
    for i,s in prior:
     if s.get('kind')=='llm' and not str(s.get('agent','')).startswith('verifier'):
      if root is None:
       messages=[(j,m.get('content')) for j,m in enumerate(s.get('messages',[])) if m.get('role')=='user']
       if messages: j,root=messages[0];rootptr=f'/steps/{i}/messages/{j}/content'
      if str(s.get('agent','')).removesuffix('_agent')=='payments':
       key=s.get('tools_sha');entries.append({'step_seq':s['seq'],'agent':s.get('agent'),'tools':s.get('tools'),'tool_schemas':r.get('tool_defs',{}).get(key),'tools_sha':key})
     if s.get('kind')=='tool' and str(s.get('name','')).lower().startswith('taxcalc'):tax.append({'step_seq':s['seq'],'agent':s.get('agent'),'tool_name':s['name']})
    blind={'annotation_id':aid,'payments_precut_llm_tool_requests':entries,'precut_taxcalc_calls':tax,'availability':'captured_payments_tool_request' if entries else 'unknown_no_precut_payments_tool_request','limitations':'Recorded pre-cut request lists are shown with their own step sequence; check applicability to the specific P4 call.'}
    cust={'source':loc,'source_sha256':h,'line':line,'cut_step_seq':cut,'searched':'pre-cut non-verifier LLM requests for Payments and earlier TaxCalc tool calls; tool_defs only when linked by tools_sha','root_request_pointer':rootptr}
    rh=write(HERE/'root_requests_blind'/(aid+'.json'),{'annotation_id':aid,'initial_user_message':root,'status':'captured' if root is not None else 'not_captured_in_precut_steps'});bh=write(HERE/'blind_inputs'/(aid+'.json'),blind);ch=write(HERE/'custodian_records'/(aid+'.json'),cust);statuses.append({'annotation_id':aid,'status':blind['availability'],'blind_sha256':bh,'custodian_sha256':ch,'root_request_sha256':rh})
 assert len(statuses)==len({x['annotation_id'] for x in statuses})==542
 report={'cases':sorted(statuses,key=lambda x:x['annotation_id']),'status_counts':dict(Counter(x['status'] for x in statuses)),'sources':per_source,'disclosure':'blind_inputs to both action raters; root_requests_blind to scenario-intent raters only; custodian_records and source paths withheld from blind raters'}
 write(HERE/'availability.json',report);print(json.dumps(report['status_counts']))
if __name__=='__main__':main()
